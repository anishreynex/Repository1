$(document).ready(function(){
						   
	$("#add_menu_form").validate({
		rules : {
			menu_name	: "required",
			menu_url	: "required"
	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			menu_name	: "The Name field is required",
			menu_url	: "The Url field is required"
		}					 
	});
	
	$("#menu_group_form").validate({
		rules : {
			menu		: "required",
			menu_group  : "required",
			module		: "required"
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			menu		: "The Menu field is required",
			menu_group	: "The Menu Group field is required",
			module		: "The Module field is required"
		}					 
	});
	
	$("#sub_menu_form").validate({
		rules : {
			menu		: "required",
			menu_group	: "required",
			submenu 	: "required",
			submenu_url : "required"
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			menu		: "The Menu field is required",
			menu_group	: "The Menu Group field is required",
			submenu		: "The Sub Menu field is required",
			submenu_url : "The Sub Menu Url field is required"
		}					 
	});
});