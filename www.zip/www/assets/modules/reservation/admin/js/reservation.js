$(document).ready(function(){
						   
	$("#reservation_category_form").validate({
		rules : {
			reservation_category	: "required"	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td"));
		},		

		messages: {
			reservation_category	: "The Reservation Category field is required"
		}					 
	});
	
	$("#reservation_roomtype_form").validate({
		rules : {
			room_type	: "required"	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td"));
		},		

		messages: {
			room_type	: "The Room Type field is required"
		}					 
	});
	
});