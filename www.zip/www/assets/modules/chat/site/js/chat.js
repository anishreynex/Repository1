/**
 * Chat script
 * @author Abin V Paul
 *
 * 
**/
$(function(){
		   
	var base_url			= '/base_app_v2/';
	var chat_window_width	= 230;
	var chat_boxes			= new Array();
	var ping_interval		= 2;
	

	$(window).focus(function() {
	window_focus = true;
	})
	.blur(function() {
	window_focus = false;
	});


	// Restore chat_boxes
	restore_chat_boxes();
	recieve_chat();

	// Create chat window
	$("#chat_friends li a").click(function(){
		var chat_user		= $(this).attr('id');
		var chat_box_title	= $(this).text();
		
		create_chat_window(chat_user, chat_box_title);
		update_chat_boxes_cookie();
	});
	
	// Close chat window
	$(".close_chat_window").live("click", function(){
		var close_chat_user		= $(this).parent("div").parent("div").attr("id");
		close_chat_window(close_chat_user);	
		
		update_chat_boxes_cookie();

	});
	
	// Minimize and Maximize chat boxes
	$( ".portlet-header .ui-icon-minusthick, .portlet-header .ui-icon-plusthick" ).live('click', function() { 
		$( this ).toggleClass( "ui-icon-minusthick" ).toggleClass( "ui-icon-plusthick" );
		$( this ).parents( ".portlet:first" ).find( ".portlet-content" ).toggle();
	});
	
	// Send chat
	$(".chat_message_box").live('keypress', function(e) {
		if(e.which == 13) {
			e.preventDefault();
			
			// The user to chat with
			var user				= $(this).attr("id");
			var message				= $(this).val();
			
			var current_discussions	= '';
			
			
			if(message != "") {
				$("#"+user+"_chat").find(".chat_messages").append('<p><strong>me : </strong>'+message+'</p>');
				$(this).val('');
				
				current_discussions	= $("#"+user+"_chat").find(".chat_messages").html();
			}
			
			// send chat
			send_chat(message, user);
			
			scroll_down_chat();
			
			// Save the current conversation to local storage
			store_current_chats(user, current_discussions);
		}
	});
	
	/**
	 * function create_chat_window
	 * accepts chat_user name and creates chat box using that id
	 * also skins the chatbox
	**/
	function create_chat_window(chat_user, chat_box_title){
		
		// Check if the box is already visible. If not generate
		if(!$('#'+chat_user+'_chat').is(":visible")) {
			
			if($('#'+chat_user+'_chat').length > 0){
				
				$('#'+chat_user+'_chat').css('display', 'block');
				
				// Update chat_boxes array
				chat_boxes.push(chat_user+'_chat');
				reconstruct_chat_boxes();
				
			} else {
		
				var window_html	 = 	'<div class="portlet" id="'+chat_user+'_chat">';
				window_html		+=	'<div class="portlet-header">'+chat_box_title+'</div>';
				window_html		+=	'<div class="portlet-content">';
				window_html		+=	'<div class="chat_messages"></div>';
				window_html		+=	'<textarea id="'+chat_user+'" class="chat_message_box"></textarea>';
				window_html		+=	'</div>';
				window_html		+=	'</div>';
				
				// Create chat window
				$("#chat_holder").append(window_html);
				
		
				
				// Update chat_boxes array
				chat_boxes.push(chat_user+'_chat');
				
				
				// Skin Chat window
				$( '#'+chat_user+'_chat' ).css("width", chat_window_width+"px").addClass( "ci_chat_app ui-widget ui-widget-content ui-helper-clearfix ui-corner-all" )
					.find( ".portlet-header" )
						.addClass( "ui-widget-header ui-corner-all" )
						.prepend( "<span class='ui-icon ui-icon-minusthick'></span>")
						.prepend( "<span class='ui-icon ui-icon-closethick close_chat_window'></span>")
						.end()
					.find( ".portlet-content" );
				
				// Adjust textarea width in chat window
				$( '#'+chat_user+'_chat textarea' ).css('width', chat_window_width-22);
				
				reconstruct_chat_boxes();
			}
			
		} else {
		$('#'+chat_user+'_chat').effect( 'highlight' );	
		$('#'+chat_user+'_chat').find('textarea').focus()
		}
		

		// Restore the messages if the user already had a chat session
		restore_messages(chat_user);
		scroll_down_chat();
		
	}
	
	/**
	 * function send_chat
	 * sends the user chat
	**/
	function send_chat(Message, User) {
		$.ajax({
		  type: "POST",
		  url: base_url+"chat/send",
		  data: { user: User, message: Message }
		});
	}
	
	/**
	 * function send_chat
	 * sends the user chat
	**/
	function recieve_chat(User) {
		$.ajax({
		  type: "POST",
		  url: base_url+"chat/recieve",
		  data: { user: User }
		}).done(function( msgs ) {
			
		update_new_messages(msgs);
			
		// recall the function again
		setTimeout(function(){
		  recieve_chat(User);
		}, ping_interval*2000);

		});
	}
	
	
	/**
	 * function update_new_messages
	 * accepts the new message json and add to the chat boxes
	**/
	function update_new_messages(msgs){
		
		// Check the chat boxes in cookie	
		var new_msgs = jQuery.parseJSON(msgs);
		
		if(new_msgs != null) {
			
			$.each(new_msgs, function(key, value) {
					
					//alert(value.title);
					create_chat_window(value.name, value.title);
					
					// restore if there is any messages in this session
					restore_messages(value.name);
					
					$("#"+value.name+"_chat .chat_messages").append('<p><strong>'+value.name+' : </strong>'+value.message+'</p>');
					scroll_down_chat();
					update_chat_boxes_cookie();
					
					current_discussions	= $("#"+value.name+"_chat").find(".chat_messages").html();
		
					// Save the current conversation to local storage
					store_current_chats(value.name, current_discussions);
					
					if(window_focus==false)
					$("title").text(value.name+' says...');
			}); 
		}
	}
	
	
	/**
	 * function close_chat_window
	 * accepts chat_user id and closes chat box using that id
	**/
	function close_chat_window(close_chat_user){
		
		$("#"+close_chat_user).hide();
		
		// Remove the chat_box name from the chat boxes array
		removeByElement(chat_boxes, close_chat_user);
		
		reconstruct_chat_boxes();

	}
	
	/**
	 * function removeByElement
	 * custom function to remove element from an array
	**/
	function removeByElement(arrayName,arrayElement){
		for(var i=0; i<arrayName.length;i++ )
		{ 
			if(arrayName[i]==arrayElement)
			arrayName.splice(i,1); 
		} 
	}
	
	/**
	 * function reconstruct_chat_boxes
	 * when user closes or adds chat boxes, this function will set positioning
	**/
	function reconstruct_chat_boxes()
	{
		for(var i=0; i<chat_boxes.length;i++ )
		{ 
			$("#"+chat_boxes[i]).css("right", (chat_window_width*i)+20*i);	
		}		
	}
	
	
	/**
	 * function restore_chat_boxes
	 * This function checks for the saved chat boxes in cookie and if found, it will be restored
	**/
	function restore_chat_boxes(){
		
		// Check the chat boxes in cookie	
		var stored_chat_boxes = jQuery.parseJSON($.cookie('chat_boxes_cookie'));
		
		if(stored_chat_boxes != null) {
			
			$.each(stored_chat_boxes, function(key, value) {
					
					create_chat_window(value.name, value.title);
					
					// restore if there is any messages in this session
					restore_messages(value.name);
					scroll_down_chat();
			}); 
		}
	}
	
	/**
	 * function restore_messages
	 * This function checks for the saved chat messages in the current session and if found, restores the messages
	**/
	function restore_messages(user){
		
		var user_stored_messages	= localStorage.getItem(user+'_discussions');
		if(user_stored_messages != null){
			$("#"+user+'_chat').find('.chat_messages').html(user_stored_messages);	
								

		}
		
	}
	
	// updates the currently active chat boxes to cookie
	function update_chat_boxes_cookie(){
		
		//Clear previously set cookie
		$.cookie('chat_boxes_cookie' , null);
		
		chat_boxes_cookie	= [];
		
		
		// Get currently visible chat boxes
		var active_chat_boxes	= $("#chat_holder .ci_chat_app");
		
		$(active_chat_boxes).each(function(index) {
			
				var user			= $(this).attr("id");
				var chat_box_user	= get_user_name($(this).attr("id"));
				var chat_box_title	= $(this).find(".portlet-header").text();
				
				// Update the visible chat boxes
				if($("#"+user).is(":visible")) {	
				chat_boxes_cookie.push({'name':chat_box_user, 'title':chat_box_title});	
				}
			
		});
		
		$.cookie('chat_boxes_cookie' , JSON.stringify(chat_boxes_cookie));

	}
	
	function get_user_name(value){
			
		var username	= value.split("_");		
		var name	= '';
		
		for(i=0; i < username.length-1; i++) {
			name += username[i]+'_';
		}	
	
		return name.replace(/_+$/,'');
	
	};
	
	
	function scroll_down_chat(){
		$(".chat_messages").each( function() 
		{
		   // certain browsers have a bug such that scrollHeight is too small
		   // when content does not fill the client area of the element
		   var scrollHeight = Math.max(this.scrollHeight, this.clientHeight);
		   this.scrollTop = scrollHeight - this.clientHeight;
		});	
	}
	
	// stores the chat messages to local storage
	function store_current_chats(chat_user, current_discussions) {
		
		// Save the current chats to local storage
		if(typeof(Storage)!=="undefined")
		{
			var msg_user		= chat_user+'_discussions';
			localStorage.setItem(msg_user, current_discussions); 
			
		}
	}
	
});