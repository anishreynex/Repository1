$(document).ready(function(){
						   
	$("#create_news").validate	({
		rules : {
			title	: "required",
			content	: "required"
	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			title	: "The Title field is required",
			content	: "The Content field is required"
		}					 
	});
	
	$("#publish_on").datepicker({ dateFormat: 'yy-mm-dd' });
	
});