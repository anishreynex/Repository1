$(document).ready(function(){
						   
	$("#testimonials").validate	({
		rules : {
			your_name	: "required",
			email		: "required",
			content		: "required"
	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			your_name	: "The Your Name field is required",
			email		: "The Email Id field is required",
			content		: "The Testimonial content field is required"
		}					 
	});
		
});