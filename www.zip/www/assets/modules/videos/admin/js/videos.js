$(document).ready(function(){
						   
	$("#upload_video_form").validate({
		rules : {
			title			: "required",
			description		: "required",
			preview_image	: "required",
			upload_video	: "required"
	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			title			: "The Title field is required",
			description		: "The Description field is required",
			preview_image	: "The Preview Image field is required",
			upload_video	: "The Upload File field is required"
		}					 
	});
	
	$("#edit_video_form").validate({
		rules : {
			title			: "required",
			description		: "required"
	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			title			: "The Title field is required",
			description		: "The Description field is required"
		}					 
	});
	
	$("#embedded_video").validate({
		rules : {
			title			: "required",
			description		: "required",
			embedded_url	: "required"
	
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {
			title			: "The Title field is required",
			description		: "The Description field is required",
			embedded_url	: "The Embedded Url field is required"
		}					 
	});
	
	$("#embedded_video").submit(function(){
		var url			= $("#embedded_url").val();
		var thumb_url	= $.jYoutube(url,'small');
		$("#video_thumb").val(thumb_url);
		return true;
	});
		
});