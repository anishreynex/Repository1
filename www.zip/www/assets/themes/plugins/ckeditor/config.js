﻿/*
Copyright (c) 2003-2010, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	config.filebrowserBrowseUrl 	 = '/base_app_v2/assets/themes/plugins/ckfinder/ckfinder.html';
	config.filebrowserImageBrowseUrl = '/base_app_v2/assets/themes/plugins/ckfinder/ckfinder.html?Type=Images';
	config.filebrowserFlashBrowseUrl = '/base_app_v2/assets/themes/plugins/ckfinder/ckfinder.html?Type=Flash';
	config.filebrowserUploadUrl 	 = '/base_app_v2/assets/themes/plugins/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';
	config.filebrowserImageUploadUrl = '/base_app_v2/assets/themes/plugins/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';
	config.filebrowserFlashUploadUrl = '/base_app_v2/assets/themes/plugins/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash';		
	config.filebrowserWindowWidth = '800';
	config.filebrowserWindowHeight = '500';
	config.height = '200';
	
	config.toolbarCanCollapse = false;
    config.toolbar = 'Cms';
	
	config.extraPlugins = 'youtube';
	
    /*config.toolbar_Cms =
    [
        ['Source'],
        ['Cut','Copy','Paste','PasteText','PasteFromWord'],
        ['Undo','Redo','-','SelectAll','RemoveFormat'],
        '/',
        ['Bold','Italic','-','Subscript','Superscript'],
        ['NumberedList','BulletedList','-','Outdent','Indent','Blockquote'],
        ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
        ['Link','Unlink','Anchor'],
        ['Image','Table','SpecialChar'],
        '/',
        ['Styles','Format','FontSize'],
        ['TextColor'],
        ['Maximize', 'ShowBlocks']
    ];*/
	
	config.toolbar_Cms =
    [
        ['Source'],
		['Bold','Italic'],
        ['NumberedList','BulletedList','-','Outdent','Indent','Blockquote'],
        ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
        ['Link','Unlink','Anchor'],
        ['Image','Table','SpecialChar','Flash','Youtube'],
        '/',
        ['Styles','Format','FontSize'],
        ['TextColor'],
        ['Maximize', 'ShowBlocks']
    ];

};