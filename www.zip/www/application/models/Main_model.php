<?php 
/*
* Class Main_model contains the core interaction of data
* @author Perumal M
* Last Modified 24/5/10
*/
//Class starts here

class Main_model extends CI_Model
{
	
	/*
	* Function select_as_array 
	* @table_name Pass the table name  from where data to be get 
	* @where	Optional based on condition
	* @order_by	
	* @single Optional Set to TRUE if one row of data only needed
	* return type array
	* @author Perumal M
	*/
	//Definition starts here
	
	function select_as_array($table_name, $where='', $order_by='',$order='ASC', $single=FALSE,$limit='',$offset='')
	{
		 if($where)
		 $this->db->where($where); 
		 if($order_by)
		 $this->db->order_by($order_by,$order);
		 if($limit)
		 $this->db->limit($limit,$offset); 
		 $query = $this->db->get($table_name);
		 if($single)
		 {
			$result = $query->row_array();
			return $result ;
		 }
		 else
		 {
			 $result = $query->result_array(); 
			 return $result;
		 }
		 
	} //select_as_array ends here
	
	/*
	* Function select_as_object
	* @table_name Pass the table name  from where data to be get 
	* @where	Optional based on condition
	* @order_by	
	* @single Optional Set to TRUE if one row of data only needed
	* return type object
	* @author Perumal M
	*/
	//Definition starts here
	
	function select_as_object($table_name, $where='', $order_by='',$order='ASC', $single=FALSE,$limit='',$offset='', $where_not_in='',$where_not_field='')
	{
		
		if($where)
		 $this->db->where($where); 
		 if($where_not_in)
		 {
			$this->db->where_not_in($where_not_field, $where_not_in) ;
		 }
		 if($order_by)
		 $this->db->order_by($order_by,$order);
		 if($limit)
		 $this->db->limit($limit,$offset);
		 $query = $this->db->get($table_name);
		 
		 if($single)
		 {
			$result = $query->row();
			return $result ;
		 }
		 else
		 {
		     
			 $result = $query->result(); 
			 return $result;
		 }
		
		 
	} //select_as_object ends here
	
	// this function is used for GROUP BY
	function select_as_object_group($table_name, $where='',$group_by='', $order_by='',$order='ASC', $single=FALSE, $limit='',
	$offset='')
	{
		 if($where)
		 $this->db->where($where); 
		 if($group_by)
		 $this->db->group_by($group_by); 
		 if($order_by)
		 $this->db->order_by($order_by,$order);
		 if($limit)
		 $this->db->limit($limit,$offset);
		 $query = $this->db->get($table_name);
		 if($single)
		 {
			$result = $query->row();
			return $result ;
		 }
		 else
		 {
			 $result = $query->result(); 
			 return $result;
		 }
		 
	}
	//select_as_object_group ends here
	
	/*
	* Function check_exist
	* @table_name Pass the table name  from where data to be get 
	* @where	Optional based on condition
	* return The number of rows
	* @author Perumal M
	*/
	//Definition starts here

	function check_exist( $table_name, $where='' )
	{
		$this->db->select('*');
		$this->db->from($table_name);
		if($where)
		$this->db->where($where); 
		return $this->db->count_all_results();
	} //check_exist ends here
	
	/*
	* Function select_as_join
	* @table_name1 Pass the first table name  from where data to be get 
	* @table_name2 Pass the seconf table name  from where data to be get 
	* @field1	Joining Field 1
	* @field2	Joining Field 2
	* @where	Optional based on condition
	* @order_by	ASC OR DESC
	* @order   The Field to be sorted out	
	* @limit	
	* @offset	
	* @type left,right or null
	* return The result after joining
	* @author Perumal M
	*/
	//Definition starts here
	
	function select_as_join( $table_name1, $table_name2, $field1, $field2, $where='', $order_by='', $order='', $limit='', $offset='', $type='', $where_not_in='',$where_not_field='', $where_not_in1='',$where_not_field1='',$where_like='',$where_like_field='' ) 
	{
	
		$this->db->select('*') ;
		$this->db->from($table_name1) ;
		$this->db->join($table_name2, $table_name1.'.'.$field1 .'='. $table_name2.'.'.$field2,$type) ;
 		if($where)
		$this->db->where($where) ;
		if($where_not_in)
		{
		$this->db->where_not_in($where_not_field, $where_not_in) ;
		}
		if($where_not_in1)
		{
		$this->db->where_not_in($where_not_field1, $where_not_in1) ;
		}
		if($where_like_field)
		{
			$this->db->like($where_like_field, $where_like);
		}
		if($order_by)
		$this->db->order_by($order_by,$order);
		if($limit)
		$this->db->limit($limit,$offset);
		$query = $this->db->get() ;
		$result = $query->result_array() ; 
		return $result ;
	} //select_as_join ends here
	
	/*
	* Function select_as_join
	* @table_name1 Pass the first table name  from where data to be get 
	* @table_name2 Pass the seconf table name  from where data to be get 
	* @field1	Joining Field 1
	* @field2	Joining Field 2
	* @where	Optional based on condition
	* @order_by	ASC OR DESC
	* @order   The Field to be sorted out	
	* @limit	
	* @offset	
	* @type left,right or null
	* return The result after joining
	* @author Perumal M
	*/
	//Definition starts here
	
	function select_as_join_object( $table_name1, $table_name2, $field1, $field2, $where='', $order_by='', $order='', $limit='', $offset='', $type='', $where_not_in='', $where_not_field='', $where_in='',  $where_in_field='') 
	{ 
		$this->db->select('*') ;
		$this->db->from($table_name1) ;
		$this->db->join($table_name2, $table_name1.'.'.$field1 .'='. $table_name2.'.'.$field2,$type) ;
 		if($where)
		$this->db->where($where) ;
		if($where_not_in)
		{
		$this->db->where_not_in($where_not_field, $where_not_in) ;
		}
		if($where_in)
		{
			$this->db->where_in($where_in_field, $where_in) ;
		}
		if($order_by)
		$this->db->order_by($order_by,$order);
		if($limit)
		$this->db->limit($limit,$offset);
		$query = $this->db->get() ;
		$result = $query->result() ; 
		return $result ;
	} //select_as_join ends here
	
	function select_as_join_group( $table_name1, $table_name2, $field1, $field2, $where='', $group_by='',$order_by='', $order='', $limit='', $offset='', $type='', $where_not_in='',$where_not_field='' ) 
	{
		$this->db->select('*') ;
		$this->db->from($table_name1) ;
		$this->db->join($table_name2, $table_name1.'.'.$field1 .'='. $table_name2.'.'.$field2,$type) ;
 		if($where)
		$this->db->where($where) ;
		if($group_by)
		 $this->db->group_by($group_by); 
		if($where_not_in)
		{
		$this->db->where_not_in($where_not_field, $where_not_in) ;
		}
		if($order_by)
		$this->db->order_by($order_by,$order);
		if($limit)
		$this->db->limit($limit,$offset);
		$query = $this->db->get() ;
		$result = $query->result_array() ; 
		return $result ;
	} //select_as_join ends here
	
	function select_as_search_customers($table_name1, $table_name2,$field1='',$field2='',$type='',$order_by='', $order='',$limit='',$offset='',$search,$from)
	{
	
		$this->db->select('*') ;
		$this->db->from($table_name1) ;
		$this->db->join($table_name2, $table_name1.'.'.$field1 .'='. $table_name2.'.'.$field2,$type) ;
    	$where="(`first_name` LIKE '%".$search."%' OR `last_name` LIKE '%".$search."%'  ) ";
		$this->db->where($where) ; 
		$this->db->having('group_id', 2);
		if($order_by)
		$this->db->order_by($order_by,$order);
		if($limit)
		$this->db->limit($limit,$offset);
		$query = $this->db->get() ;

		$result = $query->result();
		return $result;

	}
	
	function get_user_fullname($id)
	{
		$this->db->select(array('first_name','last_name'));
		$this->db->from('meta');
		$this->db->where('user_id', $id);
		$query	= $this->db->get();
		$result	= $query->row();
		
		return $result->first_name.' '.$result->last_name;
	}
	
	function get_text($tablename,$field,$where_field,$where_value)
	{
		$this->db->select($field);
		$this->db->from($tablename);
		$this->db->where($where_field, $where_value);
		$query	= $this->db->get();
		$result	= $query->row();
		
		return $result->$field;
	}
	function get_user_name($id)
	{
		$this->db->select(array('username'));
		$this->db->from('users');
		$this->db->where('id', $id);
		$query	= $this->db->get();
		$result	= $query->row();
		
		return $result->username;
	}	
}
//Class ends here

