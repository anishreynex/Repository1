<?php
	
	function image_thumb($file_name)
	{
		$thumb	= explode('.',$file_name);
		return $thumb[0].'_thumb.'.$thumb[1];
	}
	
	function encrypt_id($id)
	{
		$encrypted_id	= base64_encode(base64_encode(base64_encode($id)));
		return $encrypted_id;
	}
	
	function decrypt_id($id)
	{
		$decrypted_id	= base64_decode(base64_decode(base64_decode($id)));
		return $decrypted_id;
	}
	
	function active_link($current_segment,$link)
	{
		if($current_segment==$link)
		{	$class = 'class="active"';	}
		else
		{	$class = '';	}
		return $class;
	}
 

       function getUploadPath($dir)
	{
		$y = date('Y');
		$m = date('m');
		$d = date('d');
		if(!file_exists($dir.'/'.$y)){
			mkdir($dir.'/'.$y, '777');
			@chmod($dir.'/'.$y, 0777);
		}
		
		if(!file_exists($dir.'/'.$y.'/'.$m)){
			mkdir($dir.'/'.$y.'/'.$m, '777');
			@chmod($dir.'/'.$y.'/'.$m, 0777);
		}
		
		if(!file_exists($dir.'/'.$y.'/'.$m.'/'.$d)){
			mkdir($dir.'/'.$y.'/'.$m.'/'.$d, '777');
			@chmod($dir.'/'.$y.'/'.$m.'/'.$d, 0777);
		}
		
		return $dir.'/'.$y.'/'.$m.'/'.$d.'/';
	}

        function getThumbUrl($file, $width, $height, $mode=2)
	{
		$url = site_url(); 
		$ci =& get_instance();
		$url = $ci->config->item('absolute_url');
		$file = str_replace('./uploads', '', $file);
		$file =  "uploads{$file}";
		return "{$url}/thumb/{$file}X{$width}X{$height}X{$mode}";
		
	}
