<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

/**
 * class Admin
 * Class to manage Administrator option of About
 *
 **/
class Admin extends CI_Controller {

	protected $common_view_path = 'templates/admin/';
	protected $module_view_path = 'facility/admin/';

	public function __construct() {
		parent::__construct();
		$this -> load -> library('session');
		if (!$this -> ion_auth -> logged_in()) {
			redirect('admin/auth');
		}
	}

	/**
	 * function index
	 *
	 *
	 **/
	public function add_facility($page = '') {
		$this -> load -> view($this -> common_view_path . 'header');
		$data['page_title'] = 'Add Facility Us';
		$data['facility'] = $this -> main_model -> select_as_object('facility', '', 'facility_id ', 'DESC', TRUE);

		$data['page'] = $page;

		$this -> load -> view($this -> module_view_path . 'add_facility', $data);
		$this -> load -> view($this -> common_view_path . 'footer');
	}

	public function add_facility_process() {

		$data['title'] = $this -> input -> post('txt_title');

		$data['posted_on'] = time();

		if ($this -> db -> update('facility', $data)) {
			$this -> session -> set_flashdata('message', success_message('Facility Updated Successfully'));
			redirect('admin/facility/add_facility');
		} else {
			$this -> session -> set_flashdata('message', error_message('Facility Updation Failed.'));
		}
	}

}
