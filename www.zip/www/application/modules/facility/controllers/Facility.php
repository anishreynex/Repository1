<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class About Us
* Class to manage About Us
*
**/
class Facility extends MX_Controller {
	
    protected $common_view_path	= 'templates/site/';
	protected $module_view_path	= 'facility/site/';

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function index
	 *
	 *
	 **/
	 public function index()
	 {
	 	$data['facility']= $this->main_model->select_as_object('facility',array('facility_id'=>3),'','',TRUE);
	 	$this->load->view($this->common_view_path.'inner_header');
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'inner_footer');
	 }
	 
	}
