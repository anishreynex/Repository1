<section class="seven-hills-about">
   <div class="seven-background"></div>
	<div class="container">
    <div class="row seven-row">
    <div class="col-md-12">
    <div class="seven-white">
    <h4 class="title-dist"><span class="span-padd"><img src="<?php echo base_url('assets/themes/site/images/side-inner-logo.png');?>"></span>Facility</h4>
    <?php echo $facility->title;?>
    
    
    
    </div>
    </div>
    </div>
    </div>
   </section>