 <section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
 <div class="pageHeadRow">
        <div class="pagetble-cell">
          <h3 data-toggle="tooltip"  title="Add Facility" class="page-subHead">
          	 	Facility
        </h3>
        </div>
        <div class="pagetble-cell text-right">
          <ol class="breadcrumb">
            <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
           <li class="active"> Facility</li>
          </ol>
        </div>
      </div>
<?php
$post_array =$this->session->userdata('postarray');
?>
<!-- content_holder starts -->
<div id="content_holder">


<?php if($facility){ $button = 'Save'; } else { $button = 'Save'; } ?>
    <!-- box_left starts -->
    <div id="box_left_big">
    <?php echo $this->session->flashdata('message'); ?>   
    
    
   
    
   <?php
		
    	echo  form_open_multipart('admin/facility/add_facility_process',array('id'=>'add_facility_form'));
	?>


    
    
    
    <table width="100%" border="0" cellspacing="0" cellpadding="5" >
    	
      <input type="hidden" name="facility_id" value="<?php if($facility): echo $facility->facility_id; endif; ?>" />
     
      
      	<tr>
        <td ><strong>Facilites<span class="form_error">*</span></strong> </td>
         
        </tr>
        <tr>
      <td><textarea class="ckeditor" id="txt_title" cols="100" rows="5" name="txt_title" ><?php echo $facility->title;?></textarea></td>
          
        </tr>
  
  		
        <tr>
            <td>
            	<input type="submit" name="facility_submit" id="facility_submit" value="<?=$button?>" class="btn btn-default" />
            	<?=anchor('admin/dashboard','[ Back To List ]')?>
            </td>
           
        </tr>
        
    </table>
    
    <?=form_close('')?>
	</div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
  
    <!-- box_right ends -->
</div>
<!-- content_holder ends -->
</div>
</div>
</section>
<script>
	$(document).ready(function(){
    	
    	$("#offer_submit").mousedown(function(){
	  for (var i in CKEDITOR.instances){
		CKEDITOR.instances[i].updateElement();
	  }
	});
});
</script>
    <?php
    $this->session->unset_userdata('postarray');
    ?>
    