<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class Master
* Class to manage master
*
**/
class Master extends CI_Controller {

	protected $common_view_path	= 'templates/site/';
	protected $module_view_path	= 'master/site/';
	
	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 
	 /**
	 * function index
	 * loads the site home page.
	 **/
	 public function index()
	 {
		$this->load->view($this->common_view_path.'header');
		$this->load->view($this->module_view_path.'index');
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 
}
