<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class Admin
* Class to manage Administrator option of master
*
**/
class Admin extends CI_Controller {


	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'master/admin/';
	
	 public function __construct()
	 {
	 	parent::__construct();
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	 }
	 
	public function change_password()
	{
		$this->load->view($this->common_view_path.'header');
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'change_password',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	function change_password_process()
	{		
	    $this->load->library('form_validation');
		$this->form_validation->set_rules('old', 'Old password', 'required');
	    $this->form_validation->set_rules('new_pwd', 'New Password', 'required|matches[new_repeat]');
	    $this->form_validation->set_rules('new_repeat', 'Repeat New Password', 'required');
	    $this->form_validation->set_error_delimiters('<span class="form_error">', '</span>');
		
	    if ($this->form_validation->run() == false)
	    {    	
			$this->change_password();			
	    }
	    else
	    {
	        $old = $this->input->post('old');
	        $new = $this->input->post('new_pwd');
	      
			$prof 	  = $this->ion_auth->user()->row();
	        $identity = $prof->username;
	      
	       // $change = $this->ion_auth->change_password($identity, $old, $new);
		   $change = $this->ion_auth_model->change_password($identity, $old, $new);
		
    		if ($change)
    		{
				$this->ion_auth->set_message_delimiters('<span>','</span>');
    			$this->session->set_flashdata('message',success_message($this->ion_auth->messages()));
				redirect('admin/master/change_password');
    		}
    		else
    		{
				$this->ion_auth->set_error_delimiters('<span>','</span>');
				$this->session->set_flashdata('message',error_message($this->ion_auth->errors()));
				redirect('admin/master/change_password');	
    		}
	    }
	}
	
	public function update_email()
	{			
		$this->load->view($this->common_view_path.'header');
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'update_email',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	public function update_email_process()
	{
		$prof  = $this->ion_auth->user()->row();
		$email = $this->input->post('email_id');
		
		$count = count($this->main_model->select_as_object('users',array('id !='=>$prof->id,'email'=>$email),'','',FALSE));
		if($count==0)
		{
			$data['email'] = $email;
			
			$this->db->where('id',$prof->id);
			if($this->db->update('users',$data))
			{	$this->session->set_flashdata('message',success_message('Email id updated successfully.'));	}
			else
			{	$this->session->set_flashdata('message',error_message('Email id updation failed.'));	}
			redirect('admin/master/update_email');
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Email id already exist! Please try another.'));
			redirect('admin/master/update_email');
		}
	}
}
