<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class master_model
* Model Class to manage Administrator option of master
*
**/
class Master_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function any_function
	 *
	 *
	 **/
	 public function any_function()
	 {
	 	//index
	 }
}
