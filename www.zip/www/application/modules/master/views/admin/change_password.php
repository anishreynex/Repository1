<div id="content_holder">

<h1>Change Password</h1>

<?=$this->session->flashdata('message')?>

	<!-- box_left starts -->
    <div id="box_left_big">
    	<?php echo form_open('admin/master/change_password_process',array('id'=>'change_password_form'))?>

        <table width="100%" border="0" cellspacing="0" cellpadding="6" align="left" class="grid">
            <tr>
                <td colspan="2"><strong>Old Password <span class="form_error">*</span></strong></td>
            </tr>
            <tr>
                <td width="68%"><input name="old" type="password" class="input textbox" id="old" value="<?=set_value('old')?>" /></td>
				<td width="32%"><?=form_error('old')?></td>
          </tr>
            <tr>
                <td colspan="2"><strong>New Password <span class="form_error">*</span></strong></td>
            </tr>
            <tr>
                <td><input name="new_pwd" type="password" class="input textbox" id="new_pwd" value="<?=set_value('new')?>" /></td>
				<td><?=form_error('new')?></td>
            </tr>
            <tr>
                <td colspan="2"><strong>Confirm Password <span class="form_error">*</span></strong></td>
            </tr>
            <tr>
                <td><input name="new_repeat" type="password" class="input textbox" id="new_repeat" value="<?=set_value('new_repeat')?>" /></td>
				<td><?=form_error('new_repeat')?></td>
            </tr>
            <tr>
                <td colspan="2">
                <?php	$prof = $this->ion_auth->user()->row();  ?>
                <input type="hidden" name="prof_id" value=<?=$prof->id?> /> 
                <input type="submit" value="Change Password" class="button" />
                </td>
            </tr>
        </table>
        
        <?=form_close('')?>
    </div>
    <!-- box_left ends -->

	<!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
    
</div>

<script language="javascript">
$(document).ready(function(){
$("#change_password_form").validate({	
		rules : {
			old			: "required",
			new_pwd		: "required",
			new_repeat	: {	required: true, equalTo: "#new_pwd" }
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td"));
		},		

		messages: {
			old			: "The Old Password field is required",
			new_pwd		: "The New Password field is required",
			new_repeat	: {  required:"The Confirm Password field is required", equalTo:"The Confirm password & New password field should be same" }
		}
	});
});
</script>