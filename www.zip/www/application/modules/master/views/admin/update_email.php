<div id="content_holder">

<h1>Update Email</h1>

<?=$this->session->flashdata('message')?>

	<!-- box_left starts -->
    <div id="box_left_big">
    	<?php
			echo form_open('admin/master/update_email_process',array('id'=>'update_email_form')); 
			$prof = $this->ion_auth->user()->row();
		?>

        <table width="100%" border="0" cellspacing="0" cellpadding="6" align="left" class="grid">
            <tr>
                <td colspan="2"><strong>Email Id <span class="form_error">*</span></strong></td>
            </tr>
            <tr>
           	  <td width="63%"><input type="text" name="email_id" id="email_id" class="input textbox" value="<?=$prof->email?>" /></td>
              <td width="37%">&nbsp;</td>
          </tr>
            
            <tr>
                <td colspan="2">
                	<input type="submit" value="Edit" class="button" />
                </td>
            </tr>
        </table>
        
        <?=form_close('')?>
    </div>
    <!-- box_left ends -->

	<!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
    
</div>

<script language="javascript">
$(document).ready(function(){
$("#update_email_form").validate({	
		rules : {
			email_id	: { required:true, email:true }
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td"));
		},		

		messages: {
			email_id	: { required:"The email field is required", email:"Please enter a valid email id" }
		}
	});
});
</script>