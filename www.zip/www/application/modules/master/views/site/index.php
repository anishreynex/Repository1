
  
  <!-- PRELOADER >--
	<div class="page-loader">
		<div class="loader">Loading...</div>
	</div>
	<!-- END PRELOADER -->
    
  <!-- Modal -->
  <?php $data1=$this->main_model->select_as_object('services',array('services_id'=>42),'services_id','DESC',TRUE);?>
   <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
     <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $data1->title;?></h4>
      </div>
      
      <div class="modal-body">
        <div>
        <img src="<?php echo base_url();?>assets/themes/site/images/restaurant.jpg" class="img-responsive">
        </div>
        
        <div>
       <h4> <?php echo $data1->name;?></h4>
       <p> <?php echo $data1->description;?></p>
        </div>
      </div>
      
      <div class="modal-footer">
     <!--   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>-->
      </div>
      
    </div>
  </div>
</div>
 <?php $data2=$this->main_model->select_as_object('services',array('services_id'=>41),'services_id','DESC',TRUE);?>
  <div class="modal fade bs-example-modal-md1" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
     <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $data2->title;?></h4>
      </div>
      
      <div class="modal-body">
        <div>
        <img src="<?php echo base_url();?>assets/themes/site/images/spa.jpg" class="img-responsive">
        </div>
        
        <div>
       <h4> <?php echo $data2->name;?></h4>
       <p> <?php echo $data2->description;?></p>
        </div>
      </div>
      
      <div class="modal-footer">
     <!--   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>-->
      </div>
      
    </div>
  </div>
</div>
 <?php $data3=$this->main_model->select_as_object('services',array('services_id'=>40),'services_id','DESC',TRUE);?>
  <div class="modal fade bs-example-modal-md2" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
     <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $data3->title;?></h4>
      </div>
      
      <div class="modal-body">
        <div>
        <img src="<?php echo base_url();?>assets/themes/site/images/swimming.jpg" class="img-responsive">
        </div>
        
        <div>
       <h4> <?php echo $data3->name;?></h4>
       <p> <?php echo $data3->description;?></p>
        </div>
      </div>
      
      <div class="modal-footer">
     <!--   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>-->
      </div>
      
    </div>
  </div>
</div>
 <?php $data4=$this->main_model->select_as_object('services',array('services_id'=>39),'services_id','DESC',TRUE);?>
  <div class="modal fade bs-example-modal-md3" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
     <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel"><?php echo $data4->title;?></h4>
      </div>
      
      <div class="modal-body">
        <div>
        <img src="<?php echo base_url();?>assets/themes/site/images/parking.jpg" class="img-responsive">
        </div>
        
        <div>
       <h4> <?php echo $data4->name;?></h4>
       <p> <?php echo $data4->description;?></p>
        </div>
      </div>
      
      <div class="modal-footer">
     <!--   <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>-->
      </div>
      
    </div>
  </div>
</div>

  <!-- Modal End -->
    
    
    
    
    <section class="slider-section">
    
    
    
    
    <div class="header-section">
    <div class="container">
    <nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><img src="<?php echo base_url();?>assets/themes/site/images/logo.png"></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav ul-margin-left">
        <li><a href="<?php echo base_url();?>">HOME <span class="sr-only">(current)</span></a></li>
        <li><a href="<?php echo base_url();?>about">ABOUT US</a></li>
        <li><a href="<?php echo base_url();?>rooms">ROOMS</a></li>
      </ul>
      
      <ul class="nav navbar-nav navbar-right ul-margin-right">
        <li><a href="<?php echo base_url();?>spa">SPA</a></li>
        <li><a href="<?php echo base_url();?>facility">FACILITY</a></li>
        <li><a href="<?php echo base_url();?>contact_us">CONTACT</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
    </div>
    </div>
    
    
    <div class="wrapper">

		<!-- HERO -->
		<div id="home" class="flexslider fullheight color-white">
			<ul class="slides">

				<!-- SLIDE 1 -->
				<li class="bg-black-alfa-40" style="background-image:url(<?php echo base_url();?>assets/themes/site/images/slider-01.jpg)">
					<!-- HERO TEXT -->
					<div class="hero-caption">
						<div class="hero-text">

							<div class="container">

								<div class="row">
									<div class="col-sm-12 text-center">
										<h5 class="cap-01">Your one Stop Destination</h5>
    <h3 class="cap-02">Great HolidAY DEALS</h3>
    <h5 class="cap-03">GET speCIAL OFFER FROM Seven Hills. DON’T MISS IT!!!</h5>
										
									</div>
								</div>

							</div>

						</div>
					</div>
					<!-- END HERO TEXT -->
				</li>
				<!-- END SLIDE 1 -->

				<!-- SLIDE 2  -->
				<li class="bg-black-alfa-40" style="background-image:url(<?php echo base_url();?>assets/themes/site/images/slider-02.jpg)">
					<!-- HERO TEXT -->
					<div class="hero-caption">
						<div class="hero-text">

							<div class="container">

								<div class="row">
									<div class="col-sm-12 text-center">
										<h5 class="cap-01">Your one Stop Destination</h5>
    <h3 class="cap-02">Great HolidAY DEALS</h3>
    <h5 class="cap-03">GET speCIAL OFFER FROM Seven Hills. DON’T MISS IT!!!</h5>
									</div>
								</div>

							</div>

						</div>
					</div>
					<!-- END HERO TEXT -->
				</li>
				<!-- END SLIDE 2 -->

				<!-- SLIDE 3 -->
				<li class="bg-black-alfa-30" style="background-image:url(<?php echo base_url();?>assets/themes/site/images/slider-04.jpg)">
					<!-- HERO TEXT -->
					<div class="hero-caption">
						<div class="hero-text">

							<div class="container">

								<div class="row">
									<div class="col-sm-12 text-center">
										<h5 class="cap-01">Your one Stop Destination</h5>
    <h3 class="cap-02">Great HolidAY DEALS</h3>
    <h5 class="cap-03">GET speCIAL OFFER FROM Seven Hills. DON’T MISS IT!!!</h5>
										
									</div>
								</div>

							</div>

						</div>
					</div>
					<!-- END HERO TEXT -->
				</li>
				<!-- END SLIDE 3 -->
                
                
                <!-- SLIDE 3 -->
				<li class="bg-black-alfa-30" style="background-image:url(<?php echo base_url();?>assets/themes/site/images/slider-05.jpg)">
					<!-- HERO TEXT -->
					<div class="hero-caption">
						<div class="hero-text">

							<div class="container">

								<div class="row">
									<div class="col-sm-12 text-center">
										<h5 class="cap-01">Your one Stop Destination</h5>
    <h3 class="cap-02">Great HolidAY DEALS</h3>
    <h5 class="cap-03">GET speCIAL OFFER FROM Seven Hills. DON’T MISS IT!!!</h5>
										
									</div>
								</div>

							</div>

						</div>
					</div>
					<!-- END HERO TEXT -->
				</li>
				<!-- END SLIDE 3 -->
			</ul>
		</div>
		<!-- END HERO -->



	</div>
    
    
    
    
    </section>
    
    <div class="clearfix"></div>
    
    
    <section class="room-section">
    <div class="container">
    <div class="row">
    <div class="col-md-12">
    <?php $room1 = $this->main_model->select_as_object('room',array('room_id'=>39),'room_id','DESC',TRUE);?>
    <div class="room-skin">
    <div class="row room-wrap animate"  data-animate="fadeInDown" data-duration="1.0s" data-delay="0.1s" data-iteration="1">
    <div class="col-md-4 col-sm-4 col-xs-4">
    <a href="<?php echo base_url();?>rooms">
    <div class="black-room-skin hover01">
    <div class="hover-room">
    <div class="room-info">
    <h3><?php echo $room1->title;?></h3>
	<p>click to room</p>
    </div>
    <div class="sg_hover_effects"></div>
    </div>
    
    <div class="black-room">
    <h6><?php echo $room1->title;?></h6>
    </div>
    <figure>
    <img src="<?php echo base_url();?>assets/themes/site/images/room-frnt-01.jpg" class="img-responsive">
    </figure>
    </div>
    </a>
    </div>
      <?php $room2 = $this->main_model->select_as_object('room',array('room_id'=>40),'room_id','DESC',TRUE);?>
    <div class="col-md-4 col-sm-4 col-xs-4">
    <a href="<?php echo base_url();?>rooms">
    <div class="black-room-skin hover01">
    <div class="hover-room">
    <div class="room-info">
    <h3><?php echo $room2->title;?></h3>
	<p>click to room</p>
    </div>
    <div class="sg_hover_effects"></div>
    </div>
    
    <div class="black-room">
    <h6><?php echo $room2->title;?></h6>
    </div>
    <figure>
    <img src="<?php echo base_url();?>assets/themes/site/images/room-frnt-02.jpg" class="img-responsive">
    </figure>
    </div>
    </a>
    </div>
      <?php $room3 = $this->main_model->select_as_object('room',array('room_id'=>41),'room_id','DESC',TRUE);?>
    <div class="col-md-4 col-sm-4 col-xs-4 col-margin-4">
    <a href="<?php echo base_url();?>rooms">
    <div class="black-room-skin hover01">
    
    <div class="hover-room">
    <div class="room-info">
    <h3><?php echo $room3->title;?></h3>
	<p>click to room</p>
    </div>
       <div class="sg_hover_effects">
    </div>
    </div>
    
    <div class="black-room">
    <h6><?php echo $room3->title;?></h6>
    </div>
    <figure>
    <img src="<?php echo base_url();?>assets/themes/site/images/room-frnt-03.jpg" class="img-responsive">
    </figure>
    </div>
    </a>
    </div>
    
    <div class="clearfix"></div>
    </div>
    </div>
    </div>
    </div>
    </div><div class="clearfix"></div>
    </section>
     
    
    
    <section class="ourservice-section">
    <div class="container">
    <div class="row">
    <div class="col-md-12">
    <div class="awasome-wrap">
    <h4 class="awasome-services animate"  data-animate="fadeInDown" data-duration="1.0s" data-delay="0.1s" data-iteration="1">OUR AWESOME SERVICES</h4>
    </div>
    </div>
    </div>
    
    <div class="row">
        <div class="col-md-12 col-sm-11 col-xs-11 bhoechie-tab-container">
            
            <div class="col-lg-6 col-md-6 col-sm-7 col-xs-12 bhoechie-tab animate"  data-animate="fadeInLeft" data-duration="1.0s" data-delay="0.1s" data-iteration="1">
                <!-- flight section -->
                <div class="bhoechie-tab-content active">
                    <center>
                      <img src="<?php echo base_url();?>assets/themes/site/images/restaurant.jpg" class="img-responsive">
                    </center>
                </div>
                <!-- train section -->
                <div class="bhoechie-tab-content">
                    <center>
                      <img src="<?php echo base_url();?>assets/themes/site/images/spa.jpg" class="img-responsive">
                    </center>
                </div>
    
                <!-- hotel search -->
                <div class="bhoechie-tab-content">
                    <center>
                      <img src="<?php echo base_url();?>assets/themes/site/images/swimming.jpg" class="img-responsive">
                    </center>
                </div>
                <div class="bhoechie-tab-content">
                    <center>
                      <img src="<?php echo base_url();?>assets/themes/site/images/parking.jpg" class="img-responsive">
                    </center>
                </div>
                
            </div>
            
            
            
            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 bhoechie-tab-menu animate"  data-animate="fadeInRight" data-duration="1.0s" data-delay="0.1s" data-iteration="1">
            
            

              <div class="list-group">
              
                <a href="#" class="list-group-item active" data-toggle="modal" data-target=".bs-example-modal-md">
                 <div class="table-wrap">
                 <div class="table-wrap-row">
                 <div class="table-wrap-col">
                 <img src="<?php echo base_url();?>assets/themes/site/images/restaurant-icon.png" class="gang-icon">
                 </div>
                 
                 <div class="table-wrap-col01">
                 <h4><?php echo $data1->title;?></h4>
                 <p><?php echo substr($data1->description,0,130);?></p>
                 </div>
                 
                 
                 </div>
                 </div>
                 <div class="clearfix"></div>
                </a>
                <a href="#" class="list-group-item"  data-toggle="modal" data-target=".bs-example-modal-md1">
                  <div class="table-wrap">
                 <div class="table-wrap-row">
                 <div class="table-wrap-col">
                 <img src="<?php echo base_url();?>assets/themes/site/images/spa-icon.png" class="gang-icon">
                 </div>
                 
                 <div class="table-wrap-col01">
                 <h4><?php echo $data2->title;?></h4>
                 <p><?php echo substr($data2->description,0,130);?></p>
                 </div>
                 
                 </div>
                 </div>
                 <div class="clearfix"></div>
                </a>
                <a href="#" class="list-group-item"  data-toggle="modal" data-target=".bs-example-modal-md2">
                  <div class="table-wrap">
                 <div class="table-wrap-row">
                 <div class="table-wrap-col">
                 <img src="<?php echo base_url();?>assets/themes/site/images/conference-icon.png">
                 </div>
                 
                 <div class="table-wrap-col01">
                 <h4><?php echo $data3->title;?></h4>
                 <p><?php echo substr($data3->description,0,130);?> </p>
                 </div>
                 
                 </div>
                 </div>
                 <div class="clearfix"></div>
                </a>
                <a href="#" class="list-group-item"  data-toggle="modal" data-target=".bs-example-modal-md3">
                  <div class="table-wrap">
                 <div class="table-wrap-row">
                 <div class="table-wrap-col">
                 <img src="<?php echo base_url();?>assets/themes/site/images/parking-icon.png">
                 </div>
                 
                 <div class="table-wrap-col01">
                 <h4><?php echo $data4->title;?></h4>
                 <p><?php echo substr($data4->description,0,130);?> </p>
                 </div>
                 
                 </div>
                 </div>
                 <div class="clearfix"></div>
                </a>
                
              </div>
            </div>
            
        </div>
  </div>
  
    </div>
    </section>
    
    
    
    <section class="about-front">
    <div class="container">
    <div class="row ab-row">
    <div class="col-md-4 ab-left animate"  data-animate="fadeInUp" data-duration="1.0s" data-delay="0.1s" data-iteration="1">
    <div class="ab-left-inner">
    <img src="<?php echo base_url();?>assets/themes/site/images/about-img.jpg" class="img-responsive">
    </div>
    </div>
    
    <div class="col-md-8 ab-right">
    <div class="about-front-text-skin animate"  data-animate="bounceInRight" data-duration="1.0s" data-delay="0.1s" data-iteration="1">
    <div class="ab-text-wrap">
    <h3><span><img src="<?php echo base_url();?>assets/themes/site/images/side-logo.png"></span>ABOUT the seven hills HOTEL</h3>
    <?php $data=$this->main_model->select_as_object('about','','about_id','DESC',TRUE)?>
    <p><?php echo substr($data->title,0,430);?></p>
    <a href="<?php echo base_url();?>about"><button class="btn btn-default-read">Read More</button></a>
    </div>
    <div class="clearfix"></div>
    </div>
    </div>
    
    </div>
    </div>
    </section>
    
     <?php
$contact_detail=$this->main_model->select_as_object('general_info','','','ASC',TRUE);
?>
    <section class="second-footer">
    <div class="container">
    <div class="row">
    <div class="col-md-5">
    <div class="row">
    <div class="col-ms-12 footer-logo">
    <a href="index.html">
    <img src="<?php echo base_url();?>assets/themes/site/images/footer-logo.png" class="img-responsive">
    </a>
    </div>
    <div class="col-ms-12">
    <ul class="list-inline text-center social-icons-dist">
    <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->facebook; } ?>">
    <i class="fa fa-facebook" aria-hidden="true"></i>
    </a>
    </li>
    
     <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->twitter; } ?>">
    <i class="fa fa-twitter" aria-hidden="true"></i>
    </a>
    </li>
    
    
    
     <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->youtube; } ?>">
    <i class="fa fa-youtube" aria-hidden="true"></i>
    </a>
    </li>
    
    <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->googlepluse; } ?>">
    <i class="fa fa-google-plus" aria-hidden="true"></i>
    </a>
    </li>
    
    </ul>
    </div>
    </div>
    </div>
    
    <div class="col-md-3 col-sm-6">
    <div class="footer-link">
    
    <h4>Useful Links</h4>
    <ul>
    <li>
    <a href="<?php echo base_url();?>">
    Home
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>about">
    About Us
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>room">
    Rooms
    </a>
    </li>
      <li>
    <a href="<?php echo base_url();?>spa">
    Spa
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>facility">
    Facilities
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>contact_us">
    Contact Us
    </a>
    </li>
    
    </ul>
    </div>
    </div>
    
    
    
    <div class="col-md-4 col-sm-6">
    <div class="footer-address">
    <h4>contact us</h4>
    <ul class="list-unstyled">
    <li class="location"><span class="foot-icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
	<span class="foot-text"><?php echo $contact_detail->address;?></span></li>
	
	<li><span class="foot-icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
	<span class="foot-text">Phone: <?php  echo $contact_detail->phone;?></span></li>
	<li><span class="foot-icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
	<span class="foot-text">Email: <?php echo $contact_detail->c_email;?></span></li>
    </ul>
    </div>
    </div>
    
    
    </div>
    </div>
    </section>