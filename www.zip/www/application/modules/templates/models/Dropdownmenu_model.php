<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @ Author  		: Chaitra RS
 *
 * @ Created On  	: 09/27/2011
 * @ Modified On 	: 09/27/2011
 *
 * Class to manage the administrator menu section.
 *
**/
class Dropdownmenu_model extends CI_Model
{
	function get_menus()
	{
		$output  = '<ul id="nav" class="dropdown dropdown-horizontal">';
		
		$menus   = $this->main_model->select_as_object('admin_menus',array('menu_status'=>1),'admin_menu_id','ASC',FALSE);
		foreach ($menus as $menu)
		{
			$output .= '<li>'.anchor($menu->menu_url,$menu->menu_name);
			
			/* Start Menu Group */
			$groups = $this->main_model->select_as_object('admin_submenu_group',array('menu_id'=>$menu->admin_menu_id,'submenu_group_status'=>1),'submenu_group_id','ASC',FALSE);
			
			if($groups)
			{	$output .= '<ul>';	}
			else
			{	$output .= '</li>';	}
			
			foreach ($groups as $group)
			{                
                    $output .= '<li class="empty">'.$group->submenu_group_name.'</li>';
					
					/* Start sub menu */
					$submenus = $this->main_model->select_as_object('admin_submenus',array('menu_id'=>$menu->admin_menu_id,'group_id'=>$group->submenu_group_id,'submenu_status'=>1),'submenu_id','ASC',FALSE);
					
					foreach($submenus as $submenu)
					{
						$output .= '<li>'.anchor($submenu->submenu_url,$submenu->submenu_name).'</li>';
					}
					/* End sub menu */
                    
			}
			/* End Menu group */ 
            if($groups)
			{	$output .= '</ul></li>';	}
		}
		
		$output .= '</ul>';
		
		echo $output;
	}
}
