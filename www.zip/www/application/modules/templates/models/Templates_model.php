<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Templates Model
*
* Author:  Abin V Paul
* 		   abinvp@gmail.com
*
*
* Created:  26.09.2011
*
* Description:  Class to manage Templates, configuration etc.
*
* Requirements: PHP5 or above
*
*/


class Templates_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->model('promotion/promotion_model');
	}
	
	public function admin_right_panel($module_name)
	{
		$module				= $this->main_model->select_as_object('modules', array('module_name'=>$module_name), '', '', TRUE);
	
		$sub_menu_group		= $this->main_model->select_as_object('admin_submenu_group', array('module_id'=>$module->module_id), '', '', FALSE);

		if($sub_menu_group)
		{
			$i = 0;
			foreach($sub_menu_group as $group)
			{
				$sub_menus		= $this->main_model->select_as_object('admin_submenus', array('group_id'=>$group->submenu_group_id), 'submenu_id', 'ASC',FALSE);
				
				if($i==0)
				{	$html	= '<div class="portlet">';	}
				else
				{	$html	.= '<div class="portlet">';	}
				$html		.= '<div class="portlet-header">'.$group->submenu_group_name.'</div>';
				$html		.= '<div class="portlet-content">';
				$html		.= '<ul>';
				foreach($sub_menus as $sub_menu)
				{
					$html		.= '<li>'.anchor($sub_menu->submenu_url, $sub_menu->submenu_name).'</li>';
				}
				$html		.= '</ul>';
				$html		.= '</div>';
				$html		.= '</div>';
				
				$i++;
			}
			return $html;
		}
	}
	
	public function display_logo()
	{
		$logo_details 	= $this->main_model->select_as_object('admin_logo',array('logo_id'=>1),'','',TRUE);
		if($logo_details)
		{
			$src  			=  './uploads/admin_logo/'.$logo_details->logo_path;
					
			$logo_array 	= array('src'=>$src,'width'=>'324', 'height'=>'34', 'alt'=>'Super Admin Control Panel');
			$logo 			= img($logo_array);
			
			return $logo;
		}
	}
	
	public function load_assets($tab)
	{
		if($tab)
		{
			$html 	 = '';
			$get_js  = $this->main_model->select_as_object('assets_js',array('assets_js_flag'=>$tab),'assets_js_order_id','ASC',FALSE);
			if($get_js)
			{
				foreach ($get_js as $js)
				{
					$html .= "<script type=\"text/javascript\" src=\"".base_url().$js->assets_js_path."\"></script>\n";
				}
			}
			
			return $html;
		}
	}
	
	/**
	  * function headers
	  * loads the site meta details.
	 **/
	 public function meta_headers($segments)
	 {
		if($segments)
		{
			$total_segments = $this->uri->total_segments();
			if($total_segments==1)
			{
				$new_segment = $segments;
			}
			else
			{
				$segmentsE = explode('/',$segments);
				$new_segment= $segmentsE[0].'/'.$segmentsE[1];
			}
						
			$promotion_id = $this->onpage_promotion_id($new_segment);
			
			if($promotion_id)
			{
				$tag 	 = $this->generate_meta_tag($promotion_id);
				$title	 = $this->generate_meta_title($promotion_id);
				
				$html  = $title.' '.$tag;
				return $html;
			}
		}
		else
		{
			$promotion_id = $this->onpage_promotion_id();
			if($promotion_id)
			{
				$tag 	 = $this->generate_meta_tag($promotion_id);
				$title	 = $this->generate_meta_title($promotion_id);
				
				$html  = $title.' '.$tag;
				return $html;
			}
		}
	}
	
	/**
	  * function onpage_promotion_id
	  * fetch the onpage promotion id.
	 **/
	private function onpage_promotion_id($segment='')
	{
		if($segment)
		{	$this->db->like('onpage_url',$segment);	}
		else
		{	$this->db->where('onpage_url','');	}
		
		$query  = $this->db->get('onpage_promotion');
		$result = $query->row();
		if($result)
		{
			$promotion_id = $result->onpage_id;
			return $promotion_id; 
		}
	}
	
	/**
	  * function generate_meta_title
	  * generstes the meta tag title attribute value.
	 **/
	private function generate_meta_title($promotion_id)
	{
		$title = $this->main_model->select_as_object('onpage_promotion',array('onpage_id'=>$promotion_id),'','',TRUE);
		if($title)
		{
			$result_title = '<title>'.$title->onpage_title.'</title>';
			return $result_title;
		}
	}
	
	/**
	  * function generate_meta_tag
	  * generstes the meta tag description attribute value.
	 **/
	private function generate_meta_tag($promotion_id)
	{
		$tags = $this->main_model->select_as_object('onpage_promotion_details',array('onpage_promotion_id'=>$promotion_id),'onpage_detail_id','ASC',FALSE);
		if($tags)
		{
			$result_tag = '';
			foreach ($tags as $tag)
			{
				$result_tag .= '<meta name="'.$tag->onpage_meta_name.'" content="'.$tag->onpage_meta_content.'" />';
			}
			return $result_tag;	
		}
	}
}
