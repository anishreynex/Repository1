<!-- footer Starts Here ####-->

<footer id="footer" class="navbar-fixed-bottom">

	<div class="container">
		<div class="row">
			<p class="text-center">
				&copy; <?php echo date('Y'); ?> Reynex Software Pvt Ltd
			</p>
		</div>
	</div>
</footer>
<!-- footer Ends Here ####-->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins)  -->
<script src="<?php echo base_url('assets/themes/admin/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/themes/admin/js/jquery.validate.min.js'); ?>"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url('assets/themes/admin/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url();?>assets/themes/plugins/ckeditor/ckeditor.js"></script>

<script>
	$(document).ready(function() {
		$("#add_feedback_form").validate({
			rules : {
				txt_title : "required",
				txt_descriptions : "required"
			},
			messages : {
				txt_title : "The feedback by field is required",
				txt_descriptions : "The feedback is required"
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
		$("#edit_feedback_form").validate({
			rules : {
				txt_title : "required",

				txt_descriptions : "required"
			},
			messages : {
				txt_title : "The feedback by field is required",
				txt_descriptions : "The feedback is required"
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
	}); 
</script>
<script>

	$(document).ready(function() {
		
		$("#add_room_form").validate({
			rules : {
				txt_title : "required",
				txt_single : {required: true,digits: true},
				txt_double : {required: true,digits: true},
				txt_bed : {required: true,digits: true}
			},
			messages : {
				txt_title : "The room name field is required",
				txt_single : {required:"The single bed price field is required",digits:"Please enter a valid price"},
				txt_double : {required:"The double bed price field is required",digits:"Please enter a valid price"},
				txt_bed : {required:"The extra bed price field is required",digits:"Please enter a valid price"}
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
		$("#edit_room_form").validate({
			rules : {
				txt_title : "required",

				txt_single : {required: true,digits: true},
				txt_double : {required: true,digits: true},
				txt_bed : {required: true,digits: true}
			},
			messages : {
				txt_title : "The room name field is required",
				txt_single : {required:"The single bed price field is required",digits:"Please enter a valid price"},
				txt_double : {required:"The double bed price field is required",digits:"Please enter a valid price"},
				txt_bed : {required:"The extra bed price field is required",digits:"Please enter a valid price"}
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
	}); 
</script>
<script>

	$(document).ready(function() {
		
		$("#add_services_form").validate({
			rules : {
				txt_title : "required",
				txt_name : {required: true},
				txt_description : {required: true}
			},
			messages : {
				txt_title : "The services field is required",
				txt_name : {required:"The title field is required"},
				txt_description : {required:"The description field is required"}
				
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
		$("#edit_services_form").validate({
			rules : {
				txt_title : "required",

				txt_name : {required: true},
				txt_description : {required: true}
				
			},
			messages : {
				txt_title : "The services field is required",
				txt_name : {required:"The title field is required"},
				txt_description : {required:"The description field is required"}
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
	}); 
</script>
<script>
	$(document).ready(function() {
		$("#add_contact_detail").validate({
			rules : {
				txt_title : "required",
				txt_address : "required",
				txt_phn : {required: true,digits: true},
				txt_cemail : {required: true,email: true},
				txt_fax : "required",
				txt_name : "required",
				txt_email : {required: true,email: true},
				txt_cphn : {required: true,digits: true},
				txt_pname : "required",
				txt_pemail : {required: true,email: true},
				txt_pphn : {required: true,digits: true},
				txt_map : "required",
				
				txt_descriptions : "required"
			},
			messages : {
				txt_title : "The Title field is required",
				txt_address : "The Address is required",
				txt_phn : {required:"Please enter a valid phone number",email:"Please enter a valid phone number"},
				txt_cemail : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
				txt_fax : "The Fax is required",
				txt_name : "The Name is required",
				txt_email : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
				txt_cphn : {required:"Please enter a valid phone number",email:"Please enter a valid phone number"},
				txt_pname : "The Name is required",
				txt_pemail : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
				txt_pphn : {required:"Please enter a valid phone number",email:"Please enter a valid phone number"},
				txt_map : "The Map is required",
				
				
				txt_descriptions : "The Description is required"
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
		$("#edit_contact_detail").validate({
			rules : {
				txt_title : "required",
				txt_address : "required",
				txt_phn : {required: true,digits: true},
				txt_cemail : {required: true,email: true},
				txt_fax : "required",
				txt_name : "required",
				txt_email : {required: true,email: true},
				txt_cphn : {required: true,digits: true},
				txt_pname : "required",
				txt_pemail : {required: true,email: true},
				txt_pphn : {required: true,digits: true},
				txt_map : "required",
				
				txt_descriptions : "required"
			},
			messages : {
				txt_title : "The Title field is required",
				txt_address : "The Address is required",
				txt_phn : {required:"Please enter a valid phone number",email:"Please enter a valid phone number"},
				txt_cemail : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
				txt_fax : "The Fax is required",
				txt_name : "The Name is required",
				txt_email : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
				txt_cphn : {required:"Please enter a valid phone number",email:"Please enter a valid phone number"},
				txt_pname : "The Name is required",
				txt_pemail : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
				txt_pphn : {required:"Please enter a valid phone number",email:"Please enter a valid phone number"},
				txt_map : "The Map is required",
				
				txt_descriptions : "The Description is required"
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});
	}); 
</script>

<script>
	$(document).ready(function() {
		$("#add_about_form").validate({

			rules : {
				txt_title : "required",
				txt_quotes : "required",
				userfile1 : {
					required : true,
					accept : 'jpg|gif|png|jpeg'
				}
			},
			messages : {
				txt_title : "The who we are is required",
				txt_quotes : "The Quotes field is required",
				userfile : {
					required : "You did not select a file to upload",
					accept : "Please select a file with valid extension."
				}
			},
			errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.insertAfter(element).wrap('<td/>');
			}
		});

	});

</script>
<script>
	$(document).ready(function() {
		$("#change_password_form").validate({

			rules : {
				old : "required",
				new_pwd : {
					required : true,
					minlength : 5
				},
				new_repeat : {
					required : true,
					minlength : 5,
					equalTo : "#new_pwd"
				}
			},
			messages : {
				old : "The Title field is required",
				new_pwd : {
					required : "Please provide a password",
					minlength : "Your password must be at least 5 characters long"
				},
				new_repeat : {
					required : "Please provide a password",
					minlength : "Your password must be at least 5 characters long",
					equalTo : "Please enter the same password as above"
				}
			},
			//errorElement : "span",
			errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.appendTo( element.parent(".input-group").next(".ak_esclii"));
			}
		});
	}); 
</script>

<script>
	$(document).ready(function() {
		$("#update_email_form").validate({
			
			rules : {
				email_id : {required: true,email: true}				
			},
			messages : {
				email : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
				
			},
				errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.appendTo( element.parent(".input-group").next(".ak_escli"));
			}
			});
		});
</script>
<script>
	$(document).ready(function() {
		$("#add_facility_form").validate({
			
			rules : {
				txt_title : {required: true}				
			},
			messages : {
				txt_title : {required:"The faclity field is required"},
				
			},
				errorPlacement : function(error, element) {
				// error.appendTo( element.parent("td").next("td") );
				error.appendTo( element.parent(".input-group").next(".ak_escli"));
			}
			});
		});
</script>

<script>
	$(document).ready(function(e) {

		$('#contentwrap').height($(window).height() - $('#header').height());

		$(window).resize(function() {
			$("#contentwrap").height($(window).height());
		});

	}); 
</script>

<script>
	$(document).ready(function() {
		$('[data-toggle="tooltip"]').tooltip();
	});

</script>

</body>
</html>