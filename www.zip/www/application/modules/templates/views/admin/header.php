<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>::Admin::</title>

<!-- Bootstrap -->
<?php echo link_tag('assets/themes/admin/css/bootstrap.min.css')?>

<?php echo link_tag('assets/themes/admin/css/style.css')?>

<?php echo link_tag('assets/themes/admin/css/animate.css')?>

<?php echo link_tag('assets/themes/admin/font-awesome/css/font-awesome.min.css')?>

<?php echo link_tag('assets/themes/admin/css/extra.css')?>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>

<div id="header" class="navbar-default navbar-fixed-top">
  <div class="container">
    <div id="logo">
      <h2 class="extra_link">
      <a title="Go To Seven Hills Admin Control Panel" data-toggle="tooltip"  data-placement="bottom" href="<?php echo base_url('admin/dashboard');?>">Seven Hills</a> | 
      <a title="Go To Seven Hills Admin Control Panel" data-toggle="tooltip"  data-placement="bottom" href="<?php echo base_url('admin/dashboard');?>"><span class="glyphicon glyphicon-th"></span></a> | 
      <a title="Go To Seven Hills website" data-toggle="tooltip"  data-placement="bottom" href="<?php echo base_url('');?>"><span class="glyphicon glyphicon-globe"></span></a>
      </h2>
    </div>
    <ul class="nav navbar-nav navbar-right top-menu">
 	<?php
   $user = $this->ion_auth->user()->row();
   $user_id=$user->id;
  $user= $this->main_model->get_user_name($user_id);
    ?>
      <li class="dropdown navbar-user"> <a href="" class="dropdown-toggle" data-toggle="dropdown"> <img src="<?php echo base_url();?>assets/themes/admin/images/user.png" alt="user"> <span class="hidden-xs"><?php echo $user;?></span> <b class="caret"></b> </a> 
      
      <ul class="dropdown-menu animated fadeInLeft">
		<li class="arrow"></li>
		<li><a href="<?php echo base_url('settings/change_password');?>">Change Settings</a></li>
		<li class="divider"></li>
		<li><a data-ui-sref="login" href="<?php echo base_url('admin/auth/logout');?>">
<i class="fa fa-sign-out"></i>Log Out</a></li>

						</ul>
      </li>
    </ul>
  </div>
</div> Ends Here ####-->