<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>::- the sevenhills hotel -::</title>
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url('assets/themes/site/');?>images/favicon.ico">
    <!-- Bootstrap -->
    <link href="<?php echo base_url();?>assets/themes/site/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url();?>assets/themes/site/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/themes/site/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet"> 
	<link href="<?php echo base_url();?>assets/themes/site/css/template.css" rel="stylesheet">
    
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="body-inner">
  
   <!-- PRELOADER >--
	<div class="page-loader">
		<div class="loader">Loading...</div>
	</div>
	<!-- END PRELOADER -->
  
 <header class="inner-herader">
 <div class="container">
 <nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?php echo base_url();?>"><img src="<?php echo base_url();?>assets/themes/site/images/inner-logo.png" class="img-responsive">
      </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      
      
      <ul class="nav navbar-nav navbar-right">
        <li><a href="<?php echo base_url();?>">HOME</a></li>
        <li><a href="<?php echo base_url();?>about">ABOUT US</a></li>
        <li><a href="<?php echo base_url();?>rooms">ROOMS</a></li>
        <li><a href="<?php echo base_url();?>spa">SPA</a></li>
        <li><a href="<?php echo base_url();?>facility">FACILITY</a></li>
        <li><a href="<?php echo base_url();?>contact_us">CONTACT</a></li>
       </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
 </div>
 </header>
