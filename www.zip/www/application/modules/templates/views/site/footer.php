  
    <footer class="footer-dist">
    <div class="container">
    <div class="row">
    <div class="col-md-6 footer-left"><h4>Copyright 2017. All Rights Reserved.</h4></div>
    <div class="col-md-6 footer-right"><h4>Design & Developed By <span><a href="https://www.reynex.net">Reynex software pvt ltd</a></span></h4></div>
    </div>
    </div>
    </footer>
    


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url();?>assets/themes/site/js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url();?>assets/themes/site/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/themes/site/js/plugins.min.js"></script>
	<script src="<?php echo base_url();?>assets/themes/site/js/custom.min.js"></script>
    
    <script>
    $(document).ready(function() {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
});
    </script>

 <!-- <script>
    $(window).resize(function(){
  $('#carousel-example-generic').height($(window).height());
  
 });
    </script>  -->
    
    <script>
jQuery("document").ready(function($){
	
	var nav = $('.header-section');
	
	$(window).scroll(function () {
		if ($(this).scrollTop() > 100) {
			nav.addClass("fixed-nav");
		} else {
			nav.removeClass("fixed-nav");
		}
	});
 
});
</script>


<script>
$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 100) {
        $(".header-section").fadeIn(500).addClass("shrink");
    } else {
        $(".header-section").removeClass("shrink");
    }
});

</script>


<script>
if (navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('') == -1) {
    //alert('Its Safari');
    $('.flexslider').css('height', '700px');
}
</script>

<script src="<?php echo base_url();?>assets/themes/site/js/scrolla.jquery.min.js"></script>

	<script>
		
	$('.animate').scrolla({
		mobile: false,
		once: false
	});

	</script>


    
  </body>
</html>