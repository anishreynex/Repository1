 <?php
$contact_detail=$this->main_model->select_as_object('general_info','','','ASC',TRUE);
?>
  <section class="second-footer">
    <div class="container">
    <div class="row">
    <div class="col-md-5">
    <div class="row">
    <div class="col-ms-12 footer-logo">
    <a href="<?php echo base_url();?>">
    <img src="<?php echo base_url();?>assets/themes/site/images/footer-logo.png" class="img-responsive">
    </a>
    </div>
    <div class="col-ms-12">
    <ul class="list-inline text-center social-icons-dist">
    <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->facebook; } ?>">
    <i class="fa fa-facebook" aria-hidden="true"></i>
    </a>
    </li>
    
     <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->twitter; } ?>">
    <i class="fa fa-twitter" aria-hidden="true"></i>
    </a>
    </li>
    
    
    
     <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->youtube; } ?>">
    <i class="fa fa-youtube" aria-hidden="true"></i>
    </a>
    </li>
    
    <li>
    <a href="<?php if($contact_detail) { echo $contact_detail->googlepluse; } ?>#">
    <i class="fa fa-google-plus" aria-hidden="true"></i>
    </a>
    </li>
    
    </ul>
    </div>
    </div>
    </div>
    
    <div class="col-md-3 col-sm-6">
    <div class="footer-link">
    
    <h4>Useful Links</h4>
    <ul>
    <li>
    <a href="<?php echo base_url();?>">
    Home
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>about">
    About Us
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>rooms">
    Rooms
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>spa">
    Spa
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>facility">
    Facilities
    </a>
    </li>
    
    <li>
    <a href="<?php echo base_url();?>contact_us">
    Contact Us
    </a>
    </li>
    
    </ul>
    </div>
    </div>
    
    <div class="col-md-4 col-sm-6">
    <div class="footer-address">
    <h4>contact us</h4>
    <ul class="list-unstyled">
    <li class="location"><span class="foot-icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
	<span class="foot-text"><?php echo $contact_detail->address;?></span></li>
	
	<li><span class="foot-icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
	<span class="foot-text">Phone: <?php  echo $contact_detail->phone;?></span></li>
	<li><span class="foot-icon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
	<span class="foot-text">Email: <?php echo $contact_detail->c_email;?></span></li>
    </ul>
    </div>
    </div>
    
    
    </div>
    </div>
    </section>
<footer class="footer-dist">
	<div class="container">
		<div class="row">
			<div class="col-md-6 footer-left">
				<h4>Copyright 2017. All Rights Reserved.</h4>
			</div>
			<div class="col-md-6 footer-right">
				<h4>Design & Developed By <span><a href="https://www.reynex.net">Reynex software pvt ltd</a></span></h4>
			</div>
		</div>
	</div>
</footer>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url(); ?>assets/themes/site/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url(); ?>assets/themes/site/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/themes/site/js/jquery.validate.min.js"></script>

<script>
	jQuery("document").ready(function($) {

		var nav = $('.inner-herader');

		$(window).scroll(function() {
			if ($(this).scrollTop() > 100) {
				nav.addClass("fixed-inner-nav");
			} else {
				nav.removeClass("fixed-inner-nav");
			}
		});

	}); 
</script>
<script src="js/custom.min.js"></script>

<script>
	$(window).scroll(function() {
		var scroll = $(window).scrollTop();

		if (scroll >= 100) {
			$("body").fadeIn(500).addClass("bd-scroll");
		} else {
			$("body").removeClass("bd-scroll");
		}
	});

</script>

<script>
	$(window).scroll(function() {
		var scroll = $(window).scrollTop();

		if (scroll >= 100) {
			$(".inner-herader ").fadeIn(500).addClass("shrink");
		} else {
			$(".inner-herader ").removeClass("shrink");
		}
	});

</script>
<script>
	$(document).ready(function(){

$("#contactsweb_form").validate({

rules: {
name		: {required: true},
email       : {required: true,email: true},
phone      : {required: true,digits: true},
captcha	    : {required:true, remote:{url: "<?php echo base_url('contact_us/captcha_code'); ?>
	",type:"post"}},
	message     : {required: true}
	},
	// errorPlacement: function(error, element) {
	//},
	//errorClass: 'validation_error',
	messages: {
	name		: {required:"The name field is required"},
	email       : {required:"Please enter a valid email address",email:"Please enter a valid email address"},
	phone      : {required:"Please enter a valid phone number",digits:"Please enter a valid phone number"},
	captcha		: {required: "<br>The Verification Code field is required", remote: "<br>Code should match with the above image" },
	message     : {required:"The message field is required"}
	},

	});

	});

</script>

</body>
</html>