<?php
	/**
	 * template_helper.php
	 * contains simple functions for templates
	 *
	 * @authour Abin V Paul
	 **/
	 
	function notice_message($msg)
	{
		$html	 = '<div style="margin:4px 0; padding: 0 .7em;" class="ui-state-highlight ui-corner-all">';
		$html	.= '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-info"></span>';
		$html	.= '<strong>Note : </strong>'.$msg.'</p>';
		$html	.= '</div>';
		
		return $html;
	}
	
	function error_message($msg)
	{
		$html	 = '<div style="margin:4px 0; padding: 0 .7em;" class="ui-state-error ui-corner-all">';
		$html	.= '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-alert"></span>';
		$html	.= '<strong>Error : </strong>'.$msg.'</p>';
		$html	.= '</div>';
		
		return $html;
	}
	
	function success_message($msg)
	{
		$html	 = '<div style="margin:4px 0; padding: 0 .7em; background-color:#f4fcea; border:#8cce3b 1px solid;" class="ui-corner-all">';
		$html	.= '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-check"></span>';
		$html	.= '<strong>Success : </strong>'.$msg.'</p>';
		$html	.= '</div>';
		
		return $html;
	}