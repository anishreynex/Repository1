<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class Admin
 * Class to display dashboard
 *
 * @author Abin V Paul
 **/
class Admin extends CI_Controller {

	/**
	 * path to view folder
	 *
	 * @var string
	 **/
	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'modules/admin/';
	
	
	
	public function __construct()
	{
		parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	}
	
	/**
	 * function index
	 *
	 * loads the administrator modules page
	 *
	 **/
	public function index()
	{
		redirect('admin/modules/installed_modules');
	}
	
	/**
	 * function install_module
	 *
	 * Installs a module
	 * Modules to be installed mist be placed in addons folder in root
	 * as a zip file
	 *
	 * ZIP must contain two folders:
	 * 1) modules/module_name 2) assets/modules/module_name
	 *
	 * @authour Abin V Paul
	 **/
	function install_modules()
	{
		$this->load->view($this->common_view_path.'header');
		
		// Check permissions of addon folder
		if($this->modules_model->readable())
		$data['readable']		= TRUE;
		else
		$data['readable']		= FALSE;
		
		
		if($this->modules_model->writable())
		$data['writable']		= TRUE;
		else
		$data['writable']		= FALSE;
		
		// If folder permissions are set correctly, Get modules zips to install
		if($data['writable']==TRUE && $data['readable']==TRUE)
		{
			$data['zipped_modules']		= $this->modules_model->get_modules();
		}
		
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		
		$this->load->view($this->module_view_path.'install_modules', $data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
 	 * function install
	 *
	 * The function will extract the zip file passed and move the
	 * modular folders to modules directory and
	 * the dependencies to the assets folder
	 *
	 * @authour Abin V Paul
	 *
	 **/
	function install($zipped_module_name)
	{
		$installation_status	= $this->modules_model->install_module($zipped_module_name);
		if($installation_status === TRUE)
		{
			$this->session->set_flashdata('message', success_message('<strong>'.$this->modules_model->get_file_name($zipped_module_name).' module</strong> has been installed successfully.'));
		}
		else
		{
			$this->session->set_flashdata('message', error_message($installation_status));
		}

		redirect('admin/modules/install_modules');
	}
	
	/**
	 * function remove_zip
	 * removes the zipped module folder from addon directory
	 *
	 **/
	function remove_zip($zipped_module_name)
	{
		if($this->modules_model->remove_zip($zipped_module_name))
		$this->session->set_flashdata('message', success_message('The zipped module has been removed from addones directory'));
		else
		$this->session->set_flashdata('message', success_message('Could not remove the zipped module from addones directory'));
		
		redirect('admin/modules/install_modules');
	}
	
	/**
	 * function create_module()
	 * displays a form to set create module options
	 *
	 * create MVC folders, files and assets
	 **/
	function create_module()
	{		
		
		if($this->input->post('module_name'))
		{
			$module_name	= $this->input->post('module_name');
			if($this->modules_model->module_check($module_name))
			{				
				$this->modules_model->create_module($module_name);
				$this->session->set_flashdata('message', success_message(ucwords($module_name).' Module created'));
				redirect('admin/modules/configure/'.$this->db->insert_id());					
			}
			else
			{
				$this->session->set_flashdata('message', error_message('Module with same name already exists. Please try another name'));
				redirect('admin/modules/create_module');
			}

		}
		else
		{
			$this->load->view($this->common_view_path.'header');
			$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
			$this->load->view($this->module_view_path.'create_module', $data);
			$this->load->view($this->common_view_path.'footer');
		}
	}
	
	
	/**
	 * function installed_modules
	 * lists installed modules with configure buttona and othe options
	 *
	 **/	
	function installed_modules()
	{
		$this->load->view($this->common_view_path.'header');
		$data['modules']		= $this->main_model->select_as_object('modules', array('installation_status'=>1), 'module_name', 'ASC');
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'installed_modules', $data);
		$this->load->view($this->common_view_path.'footer');	
	}
	
	/**
	 * function installed_modules
	 * lists installed modules with configure buttona and othe options
	 *
	 **/	
	function uninstalled_modules()
	{
		$this->load->view($this->common_view_path.'header');
		$data['modules']		= $this->main_model->select_as_object('modules', array('installation_status'=>0), 'module_name', 'ASC');
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'uninstalled_modules', $data);
		$this->load->view($this->common_view_path.'footer');	
	}
	
	/**
	 * function uninstall()
	 * uninstalls a module
	 *
	 * @authour Abin V Paul
	 **/
	function uninstall($module_name)
	{
		$this->modules_model->uninstall($module_name);		
		$this->session->set_flashdata('message', success_message('Module '.ucwords($module_name).' uninstalled successfully'));
		redirect('admin/modules/uninstalled_modules');
	}
	
	/**
	 * function remove()
	 * accepts module_name
	 * removes the backup zip and all module related entries in database
	 * Other database tables should be removed manually
	 *
	 **/
	function remove($module_name)
	{
		$this->modules_model->remove_module($module_name);
		
		$this->session->set_flashdata('message', success_message('Module '.ucwords($module_name).' removed permanently'));
		redirect('admin/modules/uninstalled_modules');
	}
	
	/**
	 * function restore_module($module_name)
	 * accepts module_name
	 **/
	function restore_module($module_name)
	{
		if($this->modules_model->restore_module($module_name))
		{	$this->session->set_flashdata('message',success_message('Module '.ucwords($module_name).' restored successfully'));	}
		else
		{	$this->session->set_flashdata('message',success_message('Module '.ucwords($module_name).' restoring failed.'));	}
		redirect('admin/modules/uninstalled_modules');
	}
	
	/**
	 * function configure()
	 * accepts module_id
	 
	 * shows module folder structure
	 **/
	function configure($module_id)
	{
		$this->load->view($this->common_view_path.'header');
		$data['module']			= $this->main_model->select_as_object('modules', array('module_id'=>$module_id), '', '', TRUE);
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'configure', $data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	function file_tree()
	{
		$dir = urldecode($this->input->post('dir'));
		echo $this->modules_model->get_file_tree($dir);	
	}

	/* Start code by chaitra */
	
	public function manage_assets()
	{
		$this->load->view($this->common_view_path.'header');
		
		$data['admin_css']	  = $this->main_model->select_as_object('assets_css',array('assets_css_flag'=>'admin'),'assets_css_order_id','ASC',FALSE);
		$data['site_css']	  = $this->main_model->select_as_object('assets_css',array('assets_css_flag'=>'site'),'assets_css_order_id','ASC',FALSE);
		
		$data['admin_js']	  = $this->main_model->select_as_object('assets_js',array('assets_js_flag'=>'admin'),'assets_js_order_id','ASC',FALSE);
		$data['site_js']	  = $this->main_model->select_as_object('assets_js',array('assets_js_flag'=>'site'),'assets_js_order_id','ASC',FALSE);
		
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'manage_assets', $data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	public function add_csspath_process()
	{
		if($this->modules_model->add_css_path())
		{	$this->session->set_flashdata('message',success_message('Css path inserted successfully.'));	}
		else
		{	$this->session->set_flashdata('message',success_message('Css path insertion failed.'));	}
		redirect('admin/modules/manage_assets#tab');
	}
	
	public function add_jspath_process()
	{
		if($this->modules_model->add_js_path())
		{	$this->session->set_flashdata('message',success_message('Js path inserted successfully.'));	}
		else
		{	$this->session->set_flashdata('message',success_message('Js path insertion failed.'));	}
		redirect('admin/modules/manage_assets#tab');
	}
		
	public function js_sorting_process()
	{
		$this->modules_model->js_sorting_process();
		redirect('admin/modules/manage_assets#tab');
	}
	
	public function css_sorting_process()
	{
		$this->modules_model->css_sorting_process();
		redirect('admin/modules/manage_assets#tab');
	}
	
	public function delete_css_assets($css_id)
	{
		if($this->modules_model->delete_css_assets($css_id))
		{	$this->session->set_flashdata('message',success_message('Css deleted successfully.'));	}
		else
		{	$this->session->set_flashdata('message',success_message('Css deletion failed.'));	}
		redirect('admin/modules/manage_assets#tab');
	}
	
	public function delete_js_assets($js_id)
	{
		if($this->modules_model->delete_js_assets($js_id))
		{	$this->session->set_flashdata('message',success_message('Js deleted successfully.'));	}
		else
		{	$this->session->set_flashdata('message',success_message('Js deletion failed.'));	}
		redirect('admin/modules/manage_assets#tab');
	}
	
	public function create_global_css($tab)
	{
		if($tab)
		{
			if($this->modules_model->create_global_css($tab))
			{	$this->session->set_flashdata('message',success_message('global.css file created successfully.'));	}
			else
			{	$this->session->set_flashdata('message',error_message('global.css file creation failed.'));	}
			redirect('admin/modules/manage_assets#tab');
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error occured! Try again.'));
			redirect('admin/modules/manage_assets#tab');
		}
	}
}
