<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Name:  Modules Model
*
* Author:  Abin V Paul
* 		   abinvp@gmail.com
*
*
* Created:  26.09.2011
*
* Description:  Class to manage modules installation, configuration etc.
*
* Requirements: PHP5 or above
*
*/


class Modules_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('zip');
		$this->load->library('unzip');
	}
	/**
	 * location of addon dir
	 *
	 * string
	 **/
	protected $addon_dir	= './addones';
	
	
	/**
	 * function readable
	 * checks if the addones directory is readable
	 *
	 * return bool
	 **/
	function readable()
	{
		if(is_readable($this->addon_dir))
		return true;
		else
		return false;
	}
	
	/**
	 * function writable
	 * checks if the addones directory is writable
	 *
	 * return bool
	 **/
	function writable()
	{
		if(is_writable($this->addon_dir))
		return true;
		else
		return false;
	}
	
	/**
	 * function get_modules
	 * scans the addones directory and lists all zip files
	 *
	 **/	 
	function get_modules()
	{
		$modules		= scandir($this->addon_dir);
		
		$zip_modules	= array();
		if(!empty($modules))
		{
			foreach($modules as $module)
			{
				if($module == '.' || $module == '..')
				continue;
				
				// Skip folders
				if(is_dir($module))
				continue;
				
				// Skip all files other than zip
				if($this->get_extension($module) !='zip')
				continue;
				
				array_push($zip_modules, $module);
			}
		}
		return $zip_modules;
	}
	
	function install_module($zipped_module_name)
	{
		
		// Unzip the module to be installed
		$this->unzip->extract('addones/'.$zipped_module_name);
		
		// Get the module name from the zip file
		$module_name	= $this->get_file_name($zipped_module_name);
		
		$error			= '';
		
		if(file_exists('./addones/'.$module_name.'/'.$module_name))
		{
			// Copying module MVC and other files to the modules directory in application folder
			$this->copy_module('./addones/'.$module_name.'/'.$module_name, './application/modules/'.$module_name);
			// Setting folder permissions
			$this->chmodr('./application/modules/'.$module_name, 0777);
		}
		else
		{
			$error		.= 'Module directory not found in the zip file';
		}
		
		if(file_exists('./addones/'.$module_name.'/assets/'.$module_name))
		{
			// Copying assets of the module to applications assets folder
			$this->copy_module('./addones/'.$module_name.'/assets/'.$module_name, './assets/modules/'.$module_name);
			// Setting folder permissions
			$this->chmodr('./assets/modules/'.$module_name, 0777);
		}
		
		$this->deleteAll('./addones/'.$module_name);
		
		// Insert the currently installed module details to database
		$data['module_name']	= $module_name;
		$data['installed_on']	= time();
		$this->db->insert('modules', $data);
		
		if($error == '')
		return true;
		else
		return $error;		

	}
	
	function restore_module($module_name)
	{
		$module	= $this->main_model->select_as_object('modules', array('module_name' => $module_name), '', '', TRUE);
		
		if(count($module) > 0)
		{
			// Enable module
			$this->db->where('module_id', $module->module_id);
			$this->db->update('modules', array('installation_status'=>'1'));
				
			//Enable menu related to module
			$this->db->where('module_id', $module->module_id);
			$this->db->update('admin_submenu_group', array('submenu_group_status'=>'1'));
			return true;
		}
	}
	
	function zip_installation_status($zipped_module_name)
	{
		$module_name	= $this->get_file_name($zipped_module_name);
		
		$module			= $this->main_model->select_as_object('modules', array('module_name' => $module_name), '', '', TRUE);
		
		if (count($module) > 0)
		return true;
		else
		return false;
	}
	
	function module_check($module)
	{
		$module_name	= $this->get_file_name($module);		
		$module			= $this->main_model->select_as_object('modules', array('module_name' => $module_name), '', '', TRUE);
		
		if (count($module) > 0)
		return false;
		else
		return true;
	}
	
	function remove_zip($zipped_module_name)
	{
		if(unlink('./addones/'.$zipped_module_name))
		return true;
		else
		return false;
	}
	
	function create_module($module_name)
	{
		$error_html		= '';
		
		// Create a folder in assets directory with the module name
		if(!mkdir("./assets/modules/".$module_name, 0777))
		{
			$error_html		= '<ul>';
			// append error if not created
			$error_html += '<li>Could not <strong>/assets/modules/'.$module_name.'</strong></li>';
		}
		else
		{
			/**
			 * Creating required folders in admin directory
			 **/
			if(!mkdir("./assets/modules/".$module_name."/admin", 0777))
			{
				// append error if not created
				$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/admin</strong></li>';
			}
			else
			{
				// Creating assets/modules/module_name/admin/css
				if(!mkdir("./assets/modules/".$module_name."/admin/css", 0777))
				{
					$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/admin/css</strong></li>';
				}
				else
				{
					$file_handle = fopen('./assets/modules/'.$module_name.'/admin/css/'.$module_name.'.css', 'w+');
					fclose($file_handle);	
				}
				
				// Creating assets/modules/module_name/admin/images
				if(!mkdir("./assets/modules/".$module_name."/admin/images", 0777))
				{
					$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/admin/images</strong></li>';
				}
				
				// Creating assets/modules/module_name/admin/js
				if(!mkdir("./assets/modules/".$module_name."/admin/js", 0777))
				{
					$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/admin/js</strong></li>';
				}
				else
				{
					$file_handle = fopen('./assets/modules/'.$module_name.'/admin/js/'.$module_name.'.js', 'w+');
					fclose($file_handle);	
				}
			}
			
			/**
			 * Creating required folders in site directory
			 **/
			 
			if(!mkdir("./assets/modules/".$module_name."/site", 0777))
			{
				// append error if not created
				$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/site</strong></li>';
			}
			else
			{
				// Creating assets/modules/module_name/site/css
				if(!mkdir("./assets/modules/".$module_name."/site/css", 0777))
				{
					$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/admin/site</strong></li>';
				}
				else
				{
					$file_handle = fopen('./assets/modules/'.$module_name.'/site/css/'.$module_name.'.css', 'w+');
					fclose($file_handle);	
				}
				
				// Creating assets/modules/module_name/site/images
				if(!mkdir("./assets/modules/".$module_name."/site/images", 0777))
				{
					$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/admin/images</strong></li>';
				}
				
				// Creating assets/modules/module_name/site/js
				if(!mkdir("./assets/modules/".$module_name."/site/js", 0777))
				{
					$error_html += '<li>Could not create <strong>/assets/modules/'.$module_name.'/site/js</strong></li>';
				}
				else
				{
					$file_handle = fopen('./assets/modules/'.$module_name.'/site/js/'.$module_name.'.js', 'w+');
					fclose($file_handle);	
				}
			}
		}
		
		/**
		 * Creating folders in modules directory
		 *
		 **/
		if(!mkdir("./application/modules/".$module_name, 0777))
		{
			$error_html += '<li>Could not create <strong>/application/modules/'.$module_name.'</strong></li>';
		}
		else
		{
			// Creating controllers directory
			if(!mkdir("./application/modules/".$module_name.'/controllers', 0777))
			{
				$error_html += '<li>Could not create <strong>/application/modules/'.$module_name.'/controllers</strong></li>';
			}
			else
			{
					$file_handle = fopen("./application/modules/".$module_name.'/controllers/admin.php', 'w+');
					
						$code		= "<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');\n\n";
						
						$code		.="/**\n";
						$code		.="* class Admin\n";
						$code		.="* Class to manage Administrator option of $module_name\n";
						$code		.="*\n";
						$code		.="**/\n";
						$code		.="class Admin extends CI_Controller {\n\n";
						
						
						$code		.="\t public function __construct()\n";
						$code		.="\t {\n";
						$code		.="\t \tparent::__construct();\n";
						$code		.="\t }\n";
						
						$code		.="\t /**\n";
						$code		.="\t * function index\n";
						$code		.="\t *\n";
						$code		.="\t *\n";
						$code		.="\t **/\n";
						$code		.="\t public function index()\n";
						$code		.="\t {\n";
						$code		.="\t \t//index\n";
						$code		.="\t }\n";
						$code		.= "}\n";
					
					// Write $code to our opened file.
					if (fwrite($file_handle, $code) === FALSE) {
						$error_html += '<li>Could not write to application/modules/'.$module_name.'/controllers/admin.php</li>';
					}
					fclose($file_handle);	
					
					
					
					//Creating controller with module name
					$file_handle = fopen("./application/modules/".$module_name.'/controllers/'.$module_name.'.php', 'w+');
					
						$code		= "<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');\n\n";
						
						$code		.="/**\n";
						$code		.="* class ".ucwords($module_name)."\n";
						$code		.="* Class to manage $module_name\n";
						$code		.="*\n";
						$code		.="**/\n";
						$code		.="class ".ucwords($module_name)." extends CI_Controller {\n\n";
						
						
						$code		.="\t public function __construct()\n";
						$code		.="\t {\n";
						$code		.="\t \tparent::__construct();\n";
						$code		.="\t }\n";
						
						$code		.="\t /**\n";
						$code		.="\t * function index\n";
						$code		.="\t *\n";
						$code		.="\t *\n";
						$code		.="\t **/\n";
						$code		.="\t public function index()\n";
						$code		.="\t {\n";
						$code		.="\t \t//index\n";
						$code		.="\t }\n";
						$code		.= "}\n";
					
					// Write $code to our opened file.
					if (fwrite($file_handle, $code) === FALSE) {
						$error_html += '<li>Could not write to application/modules/'.$module_name.'/controllers/'.$module_name.'.php</li>';
					}
					fclose($file_handle);	

			}
			
			// Creating models directory
			if(!mkdir("./application/modules/".$module_name.'/models', 0777))
			{
				$error_html += '<li>Could not create <strong>/application/modules/'.$module_name.'/models</strong></li>';
			}
			else
			{
					$file_handle = fopen("./application/modules/".$module_name.'/models/'.$module_name.'_model.php', 'w+');
					
						$code		= "<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');\n\n";
						
						$code		.="/**\n";
						$code		.="* class ".$module_name."_model\n";
						$code		.="* Model Class to manage Administrator option of $module_name\n";
						$code		.="*\n";
						$code		.="**/\n";
						$code		.="class ".ucwords($module_name)."_model extends CI_Model {\n\n";
						
						
						$code		.="\t public function __construct()\n";
						$code		.="\t {\n";
						$code		.="\t \tparent::__construct();\n";
						$code		.="\t }\n";
						
						$code		.="\t /**\n";
						$code		.="\t * function any_function\n";
						$code		.="\t *\n";
						$code		.="\t *\n";
						$code		.="\t **/\n";
						$code		.="\t public function any_function()\n";
						$code		.="\t {\n";
						$code		.="\t \t//index\n";
						$code		.="\t }\n";
						$code		.= "}\n";
					
					// Write $code to our opened file.
					if (fwrite($file_handle, $code) === FALSE) {
						$error_html += '<li>Could not write to application/modules/'.$module_name.'/models/'.$module_name.'_model.php</li>';
					}
					fclose($file_handle);	
	
			}
			
			
			// Creating views directory
			if(!mkdir("./application/modules/".$module_name.'/views', 0777))
			{
				$error_html += '<li>Could not create <strong>/application/modules/'.$module_name.'/views</strong></li>';
			}
			$error_html += '</ul>';
			
		}
		
		// Insert the currently installed module details to database
		$data['module_name']	= $module_name;
		$data['installed_on']	= time();
		$this->db->insert('modules', $data);
		
		// Set permissions to folders just created
		$this->chmodr("./assets/modules/".$module_name, 0777);
		$this->chmodr("./application/modules/".$module_name, 0777);		
		$this->session->set_userdata('module_creation_errors', $error_html);
		
	}
	
	
	function uninstall($module_name)
	{
		/**
		 * Create a folder named the module_name and copy the contents to that folder
		 * MVC and assets
		 **/
		mkdir('./module_backups/'.$module_name);		
		mkdir('./module_backups/'.$module_name.'/'.$module_name);		
		mkdir('./module_backups/'.$module_name.'/assets');
		
		$this->copy_module('./application/modules/'.$module_name, './module_backups/'.$module_name.'/'.$module_name);
		$this->copy_module('./assets/modules/'.$module_name, './module_backups/'.$module_name.'/assets');
		
		// Set all permissions to the back up module directory
		$this->chmodr('./module_backups/'.$module_name, 0777);
		
		// Create zip file of the backup module
		$path = './module_backups/'.$module_name.'/';
		$this->zip->read_dir($path); 
		$this->zip->archive('./module_backups/'.$module_name.'.zip'); // Creates a file named myarchive.zip
		
		// Delete the module folder jsut created. We have now zipped back up
		$this->deleteAll('./module_backups/'.$module_name);		
		
		// Remove the folders in module directory and assets directory
		$this->deleteAll('./application/modules/'.$module_name);
		$this->deleteAll('./assets/modules/'.$module_name);
		
		// Disable All menus
		$module		= $this->main_model->select_as_object('modules', array('module_name'=>$module_name), '', '', TRUE);
		if(count($module) > 0)
		{
			// Disabling module
			$this->db->where('module_id', $module->module_id);
			$this->db->update('modules', array('installation_status'=>'0'));
			
			//Disabling menu related to module
			$this->db->where('module_id', $module->module_id);
			$this->db->update('admin_submenu_group', array('submenu_group_status'=>'0'));
		}
		
		return true;
	}
	
	/**
	 * function remove_module()
	 * accepts module_name
	 * deletes backup zip file and entries from modulles table and menu table
	 **/
	function remove_module($module_name)
	{
		unlink('./module_backups/'.$module_name.'.zip');
		
		// Get the module details
		$module	= $this->main_model->select_as_object('modules', array('module_name' => $module_name), '', '', TRUE);
		
		// Get the submenu group details
		$admin_submenu_group	= $this->main_model->select_as_object('admin_submenu_group', array('module_id'=>$module->module_id), '', '', TRUE);
		
		if(count($admin_submenu_group) > 0)
		{
			// Delete all entry related to the module from admin_submenus
			$this->db->where('group_id', $admin_submenu_group->submenu_group_id);
			$this->db->delete('admin_submenus');
		}
		
		// Delete Submenu group
		$this->db->where('module_id', $module->module_id);
		$this->db->delete('admin_submenu_group');		
		
		// Finally delete module
		$this->db->where('module_id', $module->module_id);
		$this->db->delete('modules');
	}
     
    /**
	 * function copy_module
	 * copies a directory from given path to destination path
	 *
	 **/ 
	function copy_module( $path, $dest )
    {
        if( is_dir($path) )
        {
            @mkdir( $dest );
            $objects = scandir($path);
            if( sizeof($objects) > 0 )
            {
                foreach( $objects as $file )
                {
                    if( $file == "." || $file == ".." )
                        continue;
                    // go on
                    if( is_dir( $path.DS.$file ) )
                    {
                        $this->copy_module( $path.DS.$file, $dest.DS.$file );
                    }
                    else
                    {
                        copy( $path.DS.$file, $dest.DS.$file );
                    }
                }
            }
            return true;
        }
        elseif( is_file($path) )
        {
            return copy($path, $dest);
        }
        else
        {
            return false;
        }
    }
	
	/**
	 * function chmodr
	 * sets folder permissions immediately after installing modules
	 * sets 0777
	 *
	 **/	
	function chmodr($path, $filemode) 
	{
		if (!is_dir($path))
		return chmod($path, $filemode);
	
		$dh = opendir($path);
		while (($file = readdir($dh)) !== false) 
		{
			if($file != '.' && $file != '..') 
			{
				$fullpath = $path.'/'.$file;
				if(is_link($fullpath))
				return FALSE;
				elseif(!is_dir($fullpath) && !chmod($fullpath, $filemode))
				return FALSE;
				elseif(!$this->chmodr($fullpath, $filemode))
				return FALSE;
			}
		}
	
	closedir($dh);
	
	if(chmod($path, $filemode))
	return TRUE;
	else
	return FALSE;
	}
	
	/**
	 * function deleteAll
	 *
	 * deletes a folder, subfolder and files completely
	 * @params $empty - keeps the root dir and clears its contents
	 **/
	function deleteAll($directory, $empty = false) 
	{
		if(substr($directory,-1) == "/") 
		{
			$directory = substr($directory,0,-1);
		}
	
		if(!file_exists($directory) || !is_dir($directory)) 
		{
			return false;
		} 
		elseif(!is_readable($directory)) 
		{
			return false;
		} 
		else 
		{
			$directoryHandle = opendir($directory);
		   
			while ($contents = readdir($directoryHandle)) 
			{
				if($contents != '.' && $contents != '..') 
				{
					$path = $directory . "/" . $contents;
				   
					if(is_dir($path)) {
						$this->deleteAll($path);
					} 
					else 
					{
						unlink($path);
					}
				}
			}
		   
			closedir($directoryHandle);
	
			if($empty == false) 
			{
				if(!rmdir($directory)) 
				{
					return false;
				}
			}
		   
			return true;
		}
	} 
	
	
	/**
	 * Extract the file extension
	 *
	 * @param	string
	 * @return	string
	 */
	public function get_extension($filename)
	{
		$x = explode('.', $filename);
		return end($x);
	}
	
	/**
	 * Extract the file name
	 *
	 * @param	string
	 * @return	string
	 */
	public function get_file_name($filename)
	{
		$x = explode('.', $filename);
		return $x[0];
	}
	
	/**
	 * function get_file_tree
	 * displays folders and paths in front end
	 *
	 * jquery plugin file tree is used for displaying in the front end
	 **/
	function get_file_tree($dir)
	{
		$root	= './';
		$html	= '';
		if( file_exists($root . $dir) ) 
		{
			$files = scandir($root . $dir);
			natcasesort($files);
			if( count($files) > 2 ) 
			{ /* The 2 accounts for . and .. */
				$html .= "<ul class=\"jqueryFileTree\" style=\"display: none;\">";
				// All dirs
				foreach( $files as $file ) 
				{
					if( file_exists($root . $dir . $file) && $file != '.' && $file != '..' && is_dir($root . $dir . $file) ) 
					{
						$html .= "<li class=\"directory collapsed\"><a href=\"#\" rel=\"" . htmlentities($dir . $file) . "/\">" . htmlentities($file) . "</a></li>";
					}
				}
				// All files
				foreach( $files as $file ) 
				{
					if( file_exists($root . $dir . $file) && $file != '.' && $file != '..' && !is_dir($root . $dir . $file) ) 
					{
						$ext = preg_replace('/^.*\./', '', $file);
						$html .= "<li class=\"file ext_$ext\"><a href=\"#\" rel=\"" . htmlentities($dir . $file) . "\">" . htmlentities($file) . "</a></li>";
					}
				}
				$html .= "</ul>";	
			}
		}
		return $html;
	}
	
	/**
	 * function permission
	 * returns the current permission pf passed file or directory
	 */
	function permission($dir)
	{
		return substr(sprintf('%o', fileperms($dir)), -4);	
	}
	
	function add_css_path()
	{
		$flag = $this->input->post('hidden_form');
		if($flag)
		{
			$data['assets_css_flag']	= $flag;
			$data['assets_css_path']	= $this->input->post('css');
			if($this->db->insert('assets_css',$data))
			{
				$last_id = $this->db->insert_id();
				$datas['assets_css_order_id'] = $last_id;
				
				$this->db->where('assets_css_id',$last_id);
				$this->db->update('assets_css',$datas);	
				
				return true;	
			}
			else
			{	return false;	}
		}
		else
		{
			return false;
		}
	}
	
	function add_js_path()
	{
		$flag = $this->input->post('hidden_form');
		if($flag)
		{
			$data['assets_js_flag']	= $flag;
			$data['assets_js_path']	= $this->input->post('js');
			
			if($this->db->insert('assets_js',$data))
			{
				$last_id = $this->db->insert_id();
				$datas['assets_js_order_id'] = $last_id;
				
				$this->db->where('assets_js_id',$last_id);
				$this->db->update('assets_js',$datas);				
				return true;				
			}
			else
			{	return false;	}
		}
		else
		{
			return false;
		}
	}
	
	function js_sorting_process()
	{
		$orders	=	$this->input->post('order');	
		$i=1;
		foreach($orders as $order)
		{
			$this->db->where('assets_js_id', $order);
			$this->db->update('assets_js',array('assets_js_order_id '=>$i));
			$i++;
		}
		//echo 'Success';
		return true;
	}
	
	function css_sorting_process()
	{
		$orders	=	$this->input->post('orders');	
		$i=1;
		foreach($orders as $order)
		{
			$this->db->where('assets_css_id', $order);
			$this->db->update('assets_css',array('assets_css_order_id '=>$i));
			$i++;
		}
		//echo 'Success';
		return true;
	}
	
	function delete_css_assets($css_id)
	{
		if($css_id)
		{
			$this->db->where('assets_css_id',$css_id);
			if($this->db->delete('assets_css'))
			{	return true;	}
			else
			{	return false;	}
		}
	}
	
	function delete_js_assets($js_id)
	{
		if($js_id)
		{
			$this->db->where('assets_js_id',$js_id);
			if($this->db->delete('assets_js'))
			{	return true;	}
			else
			{	return false;	}
		}
	}
	
	function create_global_css($tab)
	{
		$css_datas = $this->main_model->select_as_object('assets_css',array('assets_css_flag'=>$tab),'assets_css_order_id','ASC',FALSE);
		
		if($css_datas)
		{
			$file_handle = fopen("./assets/themes/".$tab."/css/globals.css", 'w+');
						
			$code	= '';
			foreach($css_datas as $css)
			{
				$code .=  "@import url(\"".base_url().$css->assets_css_path."\");\n";
			}
		}
	
		// Write $code to our opened file.
		if (fwrite($file_handle, $code) === FALSE) 
		{
			fclose($file_handle);
			return false;
		}
		else
		{
			fclose($file_handle);
			return true;
		}
	}
}
