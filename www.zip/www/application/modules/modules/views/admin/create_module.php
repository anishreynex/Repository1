    <!-- content_holder starts -->
	<div id="content_holder">
    <h1>Create Module</h1>
    	<!-- box_left starts -->
        <div id="box_left_big">
        <?php echo $this->session->flashdata('message')?>
        <?php echo form_open('modules/admin/create_module', array('id'=>'create_module'))?>
        <table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
            <td width="19%">Module Name</td>
            <td width="52%"><input type="text" name="module_name" id="module_name" class="input textbox" /></td>
            <td width="29%">&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input type="submit" value="Create Module" class="button" /></td>
              <td>&nbsp;</td>
            </tr>
        </table>
        <?php echo form_close()?>
      </div>
        <!-- box_left ends -->
        
        <!-- box_right starts -->
        <div id="box_right_small">
			<?=$right_panel?>
        </div>
        <!-- box_right ends -->
    </div>
	<!-- content_holder ends -->

	<script type="text/javascript">
    $(document).ready(function(){
                               
        $("#create_module").validate	({
            rules : {   module_name	: "required" },
			
            errorPlacement: function(error, element) {
            error.appendTo( element.parent("td").next("td") );
            },		
    
            messages: {  module_name	: "Please enter a valid module name"  }					 
        });
        
        $("#publish_on").datepicker({ dateFormat: 'yy-mm-dd' });
        
    });
    </script>