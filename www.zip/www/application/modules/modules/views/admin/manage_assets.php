<!-- content_holder starts -->
<div id="content_holder">
<h1>Manage Includes</h1>

    <!-- box_left starts -->
    <div id="box_left_big">
    <?=$this->session->flashdata('message')?>
       
    <a id="tab"></a>
    <div id="tabs">
        <ul>
            <li><a href="#tabs-1">Admin</a></li>
            <li><a href="#tabs-2">Site</a></li>
        </ul>
        
        <div id="tabs-1">
        	<table width="100%" cellpadding="5" cellspacing="0" border="0">
            	<tr>
                	<td align="right">
                    <?php
						if($this->modules_model->permission('./assets/themes/admin/css/globals.css') !='0777')
						{
							echo error_message('Please set permission of <strong>assets/themes/admin/css/globals.css</strong> to <strong>0777</strong> to make this option to work');
							$write = '<a class="small-button grey_text" href="javascript:void(0)" title="Please set permission of <strong>assets/themes/site/css/globals.css</strong> to <strong>0777</strong> to make this option to work">Write to globals.css</a>';
						}
						else
						{	
							$write = anchor('admin/modules/create_global_css/admin','Write to globals.css',array('class'=>'button'));
						}
						
						echo $write;
					?>
                    </td>
                </tr>
            </table><br />
        	
            <?php echo form_open('admin/modules/add_csspath_process',array('id'=>'admin_assets_css')); ?>
            
            <table width="100%" cellpadding="5" cellspacing="0" border="0" class="grid" style="background-color:#FFF;">
            	<tr>
                	<td width="84%"><strong>Add Css Path <span class="form_error">*</span></strong></td>
                  	<td width="16%">&nbsp;</td>
                </tr>
                <tr>
                  	<td><input type="text" name="css" id="css" class="input textbox" /></td>
                    <td><input type="submit" value="Add Css" name="add_css" class="button" /></td>
             	</tr>
            </table>
            
            <input type="hidden" name="hidden_form" value="admin" />
            <?php echo form_close(''); ?>
            
            <br />
            
            <?php echo form_open('admin/modules/add_jspath_process',array('id'=>'admin_assets_js')); ?>
            
            <table width="100%" cellpadding="5" cellspacing="0" border="0" class="grid" style="background-color:#FFF;">
            	<tr>
                	<td width="84%"><strong>Add Js Path <span class="form_error">*</span></strong></td>
                  	<td width="16%">&nbsp;</td>
                </tr>
                <tr>
                  	<td><input type="text" name="js" id="js" class="input textbox" /></td>
                    <td><input type="submit" value="Add Js" name="add_js" class="button" /></td>
             	</tr>
            </table>
            
            <input type="hidden" name="hidden_form" value="admin" />
            
            <?php echo form_close(''); ?>
            
            <br />
                        
            <!-- Start - List Admin css -->
            
            <?php if($admin_css): ?>
            	<div class="assets_title">Cascading Style Sheets</div>
                <ul id="css_list" class="assets">
                	<?php foreach($admin_css as $css): ?>
                    	<li id="<?=$css->assets_css_id?>">
							<div class="assets_url"><?=base_url().$css->assets_css_path?></div>
                            <div class="assets_controls">
                            	<?php 
									echo anchor('admin/modules/delete_css_assets/'.$css->assets_css_id,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
								?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            
            <div id="css_icon_update_status" style="text-align:center; display:none;"><input type="button" id="css_update_button" class="button" value="Update" /></div>
    		<div id="css_icon_update_ok" style="text-align:center; display:none;"><strong>Updated</strong> <input type="button" class="button" id="css_update_ok_button" value="Ok" /></div>
            
            <!-- End - List Admin css -->
                       
            <!--- Start - List Admin Js -->
            
            <?php if($admin_js): ?>
            	<div class="assets_title">Javascripts</div>
                <ul id="js_list" class="assets">
                	<?php foreach($admin_js as $js): ?>
                    	<li id="<?=$js->assets_js_id?>">
							<div class="assets_url"><?=base_url().$js->assets_js_path?></div>
                            <div class="assets_controls">
                            	<?php
									echo anchor('admin/modules/delete_js_assets/'.$js->assets_js_id,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
								?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            
            <div id="js_icon_update_status" style="text-align:center; display:none;"><input type="button" id="js_update_button" class="button" value="Update" /></div>
    		<div id="js_icon_update_ok" style="text-align:center; display:none;"><strong>Updated</strong> <input type="button" class="button" id="js_update_ok_button" value="Ok" /></div>
    		
            <!--- End - List Admin Js -->
        </div>
        
        <div id="tabs-2">
        	<table width="100%" cellpadding="5" cellspacing="0" border="0">
            	<tr>
                	<td align="right">
					<?php
						if($this->modules_model->permission('./assets/themes/site/css/globals.css') !='0777')
						{
							echo error_message('Please set permission of <strong>assets/themes/site/css/globals.css</strong> to <strong>0777</strong> to make this option to work');
							$write = '<a class="small-button grey_text" href="javascript:void(0)" title="Please set permission of <strong>assets/themes/site/css/globals.css</strong> to <strong>0777</strong> to make this option to work">Write to globals.css</a>';
						}
						else
						{	
							$write = anchor('admin/modules/create_global_css/site','Write to globals.css',array('class'=>'button'));
						}
						
						echo $write;
					?>
                    </td>
                </tr>
            </table><br />
        
            <?php echo form_open('admin/modules/add_csspath_process',array('id'=>'site_assets_css')); ?>
            
            <table width="100%" cellpadding="5" cellspacing="0" border="0" class="grid" style="background-color:#FFF;">
            	<tr>
                	<td width="84%"><strong>Add Css Path <span class="form_error">*</span></strong></td>
                  	<td width="16%">&nbsp;</td>
                </tr>
                <tr>
                  	<td><input type="text" name="css" id="css" class="input textbox" /></td>
                    <td><input type="submit" value="Add Css" name="add_css" class="button" /></td>
             	</tr>
            </table>
            
            <input type="hidden" name="hidden_form" value="site" />
            <?php echo form_close(''); ?>
            
            <br />
            
            <?php echo form_open('admin/modules/add_jspath_process',array('id'=>'site_assets_js')); ?>
            
            <table width="100%" cellpadding="5" cellspacing="0" border="0" class="grid" style="background-color:#FFF;">
            	<tr>
                	<td width="84%"><strong>Add Js Path <span class="form_error">*</span></strong></td>
                  	<td width="16%">&nbsp;</td>
                </tr>
                <tr>
                  	<td><input type="text" name="js" id="js" class="input textbox" /></td>
                    <td><input type="submit" value="Add Js" name="add_js" class="button" /></td>
             	</tr>
            </table>
            
            <input type="hidden" name="hidden_form" value="site" />
            
            <?php echo form_close(''); ?>
            
            <br />
            
            <!-- Start - List Site css -->
            
            <?php if($site_css): ?>
            	<div class="assets_title">Cascading Style Sheets</div>
                <ul id="site_css_list" class="assets">
                	<?php foreach($site_css as $css): ?>
                    	<li id="<?=$css->assets_css_id?>">
							<div class="assets_url"><?=base_url().$css->assets_css_path?></div>
                            <div class="assets_controls">
                            	<?php 
									echo anchor('admin/modules/delete_css_assets/'.$css->assets_css_id,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
								?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            
            <div id="site_css_icon_update_status" style="text-align:center; display:none;"><input type="button" id="site_css_update_button" class="button" value="Update" /></div>
    		<div id="site_css_icon_update_ok" style="text-align:center; display:none;"><strong>Updated</strong> <input type="button" class="button" id="site_css_update_ok_button" value="Ok" /></div>
            
            <!-- End - List Site css -->
                       
            <!--- Start - List Site Js -->
            
            <?php if($site_js): ?>
            	<div class="assets_title">Javascripts</div>
                <ul id="site_js_list" class="assets">
                	<?php foreach($site_js as $js): ?>
                    	<li id="<?=$js->assets_js_id?>">
							<div class="assets_url"><?=base_url().$js->assets_js_path?></div>
                            <div class="assets_controls">
                            	<?php
									echo anchor('admin/modules/delete_js_assets/'.$js->assets_js_id,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
								?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            
            <div id="site_js_icon_update_status" style="text-align:center; display:none;"><input type="button" id="site_js_update_button" class="button" value="Update" /></div>
    		<div id="site_js_icon_update_ok" style="text-align:center; display:none;"><strong>Updated</strong> <input type="button" class="button" id="site_js_update_ok_button" value="Ok" /></div>
    		
            <!--- End - List Site Js -->
        </div>
    </div>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?=$right_panel?></div>
    <!-- box_right ends -->
    
</div>
<!-- content_holder ends -->

<script>
	$(function() {
		$( "#tabs" ).tabs();
		
		$("#admin_assets_css").validate	({
			rules : {
				css	: "required"
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td"));
			},		
	
			messages: {
				css	: "The Css Path field is required"
			}					 
		});
		
		$("#admin_assets_js").validate	({
			rules : {
				js	: "required"
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td"));
			},		
	
			messages: {
				js	: "The Js Path field is required"
			}					 
		});
		
		$("#site_assets_css").validate	({
			rules : {
				css	: "required"
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td"));
			},		
	
			messages: {
				css	: "The Css Path field is required"
			}					 
		});
		
		$("#site_assets_js").validate	({
			rules : {
				js	: "required"
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td"));
			},		
	
			messages: {
				js	: "The Js Path field is required"
			}					 
		});
		
		/* Admin Js sorting */
		$("#js_list").sortable({
			update: function(event, ui) { $("#js_icon_update_status").fadeIn();},
			placeholder: 'ui-state-highlight',
			opacity: 0.6,
			cursor: 'move',
			revert: 'true'
		});
        $("#js_list").disableSelection();	
		
		$("#js_update_button").button();
		$("#js_update_ok_button").button();
		
		$("#js_update_ok_button").click(function(){
			$("#js_icon_update_ok").hide();									  
		});
		
		$("#js_update_button").click(function(){
			$("#js_icon_update_status").html('<img src="<?=base_url()?>assets/modules/modules/admin/images/ajax-loader.gif" align="absmiddle"/> Updating...');
			var result = $("#js_list").sortable('toArray');
			$.post('<?=base_url()?>admin/modules/js_sorting_process',{order:result},function(response){
			$("#js_icon_update_status").hide();
			$("#js_icon_update_ok").show();
			});
		});
		
		/* Admin Css sorting */
		$("#css_list").sortable({
			update: function(event, ui) { $("#css_icon_update_status").fadeIn();},
			placeholder: 'ui-state-highlight',
			opacity: 0.6,
			cursor: 'move',
			revert: 'true'
		});
        $("#css_list").disableSelection();	
		
		$("#css_update_button").button();
		$("#css_update_ok_button").button();
		
		$("#css_update_ok_button").click(function(){
			$("#css_icon_update_ok").hide();									  
		});
		
		$("#css_update_button").click(function(){
			$("#css_icon_update_status").html('<img src="<?=base_url()?>assets/modules/modules/admin/images/ajax-loader.gif" align="absmiddle"/> Updating...');
			var js_result = $("#css_list").sortable('toArray');
			$.post('<?=base_url()?>admin/modules/css_sorting_process',{orders:js_result},function(response){
			$("#css_icon_update_status").hide();
			$("#css_icon_update_ok").show();
			});
		});
		
		/* Site Js sorting */
		$("#site_js_list").sortable({
			update: function(event, ui) { $("#site_js_icon_update_status").fadeIn();},
			placeholder: 'ui-state-highlight',
			opacity: 0.6,
			cursor: 'move',
			revert: 'true'
		});
        $("#site_js_list").disableSelection();	
		
		$("#site_js_update_button").button();
		$("#site_js_update_ok_button").button();
		
		$("#site_js_update_ok_button").click(function(){
			$("#site_js_icon_update_ok").hide();									  
		});
		
		$("#site_js_update_button").click(function(){
			$("#site_js_icon_update_status").html('<img src="<?=base_url()?>assets/modules/modules/admin/images/ajax-loader.gif" align="absmiddle"/> Updating...');
			var result = $("#site_js_list").sortable('toArray');
			$.post('<?=base_url()?>admin/modules/js_sorting_process',{order:result},function(response){
			$("#site_js_icon_update_status").hide();
			$("#site_js_icon_update_ok").show();
			});
		});
		
		/* Site Css sorting */
		$("#site_css_list").sortable({
			update: function(event, ui) { $("#site_css_icon_update_status").fadeIn();},
			placeholder: 'ui-state-highlight',
			opacity: 0.6,
			cursor: 'move',
			revert: 'true'
		});
        $("#site_css_list").disableSelection();	
		
		$("#site_css_update_button").button();
		$("#site_css_update_ok_button").button();
		
		$("#site_css_update_ok_button").click(function(){
			$("#site_css_icon_update_ok").hide();									  
		});
		
		$("#site_css_update_button").click(function(){
			$("#site_css_icon_update_status").html('<img src="<?=base_url()?>assets/modules/modules/admin/images/ajax-loader.gif" align="absmiddle"/> Updating...');
			var site_result = $("#site_css_list").sortable('toArray');
			$.post('<?=base_url()?>admin/modules/css_sorting_process',{orders:site_result},function(response){
			$("#site_css_icon_update_status").hide();
			$("#site_css_icon_update_ok").show();
			});
		});
	});
</script>