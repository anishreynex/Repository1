    <!-- content_holder starts -->
	<div id="content_holder">
    <h1>Configure <?=ucwords($module->module_name)?> Module</h1>
    	<!-- box_left starts -->
        <div id="box_left_big">
			<?php 
			echo $this->session->flashdata('message');
			
            if($this->session->userdata('module_creation_errors'))
            {
                echo $this->session->userdata('module_creation_errors');
                $this->session->unset_userdata('module_creation_errors');
            }
            ?>
			<input type="text" id="selected_file_path" class="input textbox" value="Select a file" style="width:582px; margin-bottom:15px;" readonly="readonly" />
            <a href="javascript:void(0)" id="copy_path" class="button">Copy Path</a>
            <table width="100%" border="0" cellspacing="0" cellpadding="5" class="grid">
             <thead>
              <tr>
                <td width="50%">Modules Folder Structure</td>
                <td width="50%">Assets Folder Structure</td>
              </tr>
              </thead>
              <tbody>
              <tr>
                <td align="left" valign="top">
					<?php if(file_exists('application/modules/'.$module->module_name)) :?>
                    <div id="module_directory"></div>
                    <?php 
                    else :
                    echo notice_message('The <strong>'.ucwords($module->module_name).'</strong> module not found');
                    endif; ?>
                </td>
                <td align="left" valign="top">
					<?php if(file_exists('assets/modules/'.$module->module_name)) :?>
                  	<div id="assets_directory"></div>
                    <?php 
                    else :
                    echo notice_message('The <strong>'.ucwords($module->module_name).'</strong> module assets folder not found');
                    endif; ?>
                </td>
              </tr>
              </tbody>
            </table>
        </div>
        <!-- box_left ends -->
        
        <!-- box_right starts -->
        <div id="box_right_small">
			<?=$right_panel?>
        </div>
        <!-- box_right ends -->
    </div>
	<!-- content_holder ends -->
    
	<script type="text/javascript">
    $(document).ready( function() {
        $('#module_directory').fileTree({ 
			root: 'application/modules/<?=$module->module_name?>/', 
			script: '<?=site_url()?>admin/modules/file_tree', 
			expandSpeed : 100,
			collapseSpeed :100
			}, function(file) {
				$("#selected_file_path").val(file);
        });
		
        $('#assets_directory').fileTree({ 
			root: 'assets/modules/<?=$module->module_name?>/', 
			script: '<?=site_url()?>admin/modules/file_tree', 
			expandSpeed : 100,
			collapseSpeed :100
			}, function(file) {
            $("#selected_file_path").val(file);      	

		});
		
		$('a#copy_path').zclip({
			path:'<?=base_url()?>assets/themes/plugins/zclip/ZeroClipboard.swf',
			copy:function(){return $('input#selected_file_path').val();},
			afterCopy:function(){
				$("#selected_file_path").val('Path copied to your clipboard...');      	
			}
		});
    });
    </script>