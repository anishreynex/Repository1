    <!-- content_holder starts -->
	<div id="content_holder">
    <h1>Installed Modules</h1>
    	<!-- box_left starts -->
        <div id="box_left_big">
        <?php
		echo $this->session->flashdata('message');
		
		if($this->modules_model->permission('./module_backups') !='0777')
		{
			echo error_message('Please set permission of <strong>addones/module_backups</strong> to <strong>0777</strong> to make uninstall option to work');
		}
		
		?>
          <?php if(!empty($modules)) : ?>
          <table width="100%" border="0" cellspacing="0" cellpadding="5" class="grid">
            <thead>
              <tr>
                <th width="27%">Module Name</th>
                <th width="24%">Installation Status</th>
                <th width="27%">Installation On</th>
                <th width="22%">Action</th>
              </tr>
            </thead>
            <tbody>
			<?php foreach($modules as $module) :?>

              <tr>
                <td align="left" valign="middle"><?=ucwords($module->module_name)?></td>
                <td align="left" valign="middle"><?php if($module->installation_status==1): echo 'Installed'; else : echo 'UnInstalled'; endif; ?></td>
                <td align="left" valign="middle"><?=unix_to_human($module->installed_on)?></td>
                <td align="left" valign="middle">
                <?=anchor('admin/modules/configure/'.$module->module_id, 'Configure', array('class'=>'small-button'))?>
                
                <?php 
				if($this->modules_model->permission('./module_backups') !='0777')
				{
					$uninstall_button		= '<a href="javascript:void(0)" class="small-button grey_text">Uninstall</a>';
				}
				else
				{
					$uninstall_button		= anchor('admin/modules/uninstall/'.$module->module_name, 'Uninstall', array('class'=>'small-button confirm_link', 'title' =>'This will remove '.ucwords($module->module_name).' module and all folders, files related to it. A backup will be taken and stored in <strong>module_backups</strong> directory. If the uninstallation cause any issues, you can restore the module.'));
				}
				
				echo $uninstall_button;
				?>                
                </td>
              </tr>
			<?php endforeach;?>
            </tbody>
            </table>
            
            <?php else : 
			echo notice_message('No modules installed...');
			endif;
			?>
        </div>
        <!-- box_left ends -->
        
        <!-- box_right starts -->
        <div id="box_right_small">
			<?=$right_panel?>
        </div>
        <!-- box_right ends -->
    </div>
	<!-- content_holder ends -->