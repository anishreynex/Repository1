    <!-- content_holder starts -->
	<div id="content_holder">
    <h1>Uninstalled Modules</h1>
    	<!-- box_left starts -->
        <div id="box_left_big">
        <?php
		
		echo $this->session->flashdata('message');
		
		if($this->modules_model->permission('./module_backups') !='0777')
		{
			echo error_message('Please set permission of <strong>addones/module_backups</strong> to <strong>0777</strong> to make removal option to work');
		}
		
		?>
        <?php echo notice_message('Message')?>
          <?php if(!empty($modules)) : ?>
          <table width="100%" border="0" cellspacing="0" cellpadding="5" class="grid">
            <thead>
              <tr>
                <th width="27%">Module Name</th>
                <th width="19%">Installation Status</th>
                <th width="22%">Installation On</th>
                <th width="32%">Action</th>
              </tr>
            </thead>
            <tbody>
			<?php foreach($modules as $module) :?>

              <tr>
                <td align="left" valign="middle"><?=ucwords($module->module_name)?></td>
                <td align="left" valign="middle"><?php if($module->installation_status==1): echo 'Installed'; else : echo 'Uninstalled'; endif; ?></td>
                <td align="left" valign="middle"><?=unix_to_human($module->installed_on)?></td>
                <td align="left" valign="middle">
                               
                <?php 
				if($this->modules_model->permission('./module_backups') !='0777')
				{
					$remove_button		= '<a href="javascript:void(0)" class="small-button grey_text">Restore</a>';
				}
				else
				{
					$remove_button		= anchor('admin/modules/remove/'.$module->module_name, 'Remove Permanently', array('class'=>'small-button confirm_link', 'title' =>'You are going to remove module '.ucwords($module->module_name).' and all folders, files related to it. This action cannot be undone. Are you sure, you want to proceed?'));
				}
				
				echo anchor('admin/modules/restore_module/'.$module->module_name, 'Restore',array('class'=>'small-button'));
				
				echo $remove_button;				
				?>                
                </td>
              </tr>
			<?php endforeach;?>
            </tbody>
            </table>
            
            <?php else : 
			echo notice_message('No modules found in backup directory...');
			endif;
			?>
        </div>
        <!-- box_left ends -->
        
        <!-- box_right starts -->
        <div id="box_right_small">
			<?=$right_panel?>
        </div>
        <!-- box_right ends -->
    </div>
	<!-- content_holder ends -->