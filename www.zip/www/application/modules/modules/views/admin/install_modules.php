    <!-- content_holder starts -->
	<div id="content_holder">
    <h1>Install Modules</h1>
            <?php 
			if(!is_readable('./application/modules')) :
			echo error_message('Please check folder permissions of <strong>"application/modules"</strong> directory. The modules directory permission must be set to <strong>0777</strong> to proceed');
			
			else :			
			?>    
    	<!-- box_left starts -->
        <div id="box_left_big">
        	
            <?php echo notice_message('<strong>Follow the steps given below to install a module successfully.</strong> <ul><li>Upload the Zip Archieve of module to the <strong>addones directory in your application folder</strong></li><li>Click the install button to install a module.</li><li>Make sure you have deleted the module and related files after successfull instalation by pressing the delete button</li></ul>')?>
            
            <?php echo $this->session->flashdata('message')?>
            
            <?php if(!empty($zipped_modules)) : ?>
          <table width="100%" border="0" cellspacing="0" cellpadding="5" class="grid">
            <thead>
              <tr>
                <th width="46%">Module</th>
                <th width="35%">Installation Status</th>
                <th width="19%">Action</th>
              </tr>
            </thead>
            <tbody>
			<?php 
			foreach($zipped_modules as $zipped_module) : 
				if($this->modules_model->zip_installation_status($zipped_module))
				{
					$install_button		= '<a href="javascript:void(0)" class="small-button grey_text">Install</a>';
					$status	= '<span class="green_text">Installed</span>';
				}
				else
				{
					$install_button		= anchor('admin/modules/install/'.$zipped_module, 'Install', array('class'=>'small-button'));
					$status				= 'Not Installed';	
				}
			?>
              <tr>
                <td align="left" valign="middle"><?=img('assets/themes/admin/images/zip.gif')?>&nbsp;&nbsp;<?=$zipped_module?></td>
                <td align="left" valign="middle"><?=$status?></td>
                <td align="left" valign="middle">
				<?=$install_button?>
				<?=anchor('admin/modules/remove_zip/'.$zipped_module, 'Remove', array('class'=>'small-button confirm_link', 'title' =>'This will remove '.$zipped_module.' from addones directory. You can uninstall a module from Modules configuration page.'))?>
                </td>
              </tr>
			<?php endforeach;?>
            </tbody>
            </table>
            
            <?php else : 
			if(!$readable)
			{
				echo error_message('Your <strong>addones</strong> directory is not <strong>readable</strong>. Set permission to 0777 and reload this page to proceed');
			}
			
			if(!$writable)
			{
				echo error_message('Your <strong>addones</strong> directory is not <strong>writable</strong>. Set permission to 0777 and reload this page to proceed');
			}
			
			echo notice_message('Addones directory doesnt contains any zip files');
			endif;
			?>
            
            
        </div>
        <!-- box_left ends -->
        
        <!-- box_right starts -->
        <div id="box_right_small">
			<?=$right_panel?>
        </div>
        <!-- box_right ends -->
        <?php endif; ?>
    </div>
	<!-- content_holder ends -->