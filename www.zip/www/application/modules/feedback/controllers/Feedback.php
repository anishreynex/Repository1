<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class feedback
 * Class to display feedback section.
 *
 * @ author			: Vaisakh		
 * @ created on		: 04/07/2017
 * @ modified on	: 04/07/2017
 *
 **/
class Feedback extends CI_Controller {
	
    protected $common_view_path	= 'templates/site/';
	protected $module_view_path	= 'feedback/site/';

	 public function __construct()
	 {
	 	parent::__construct();
		
	 }
	 /**
	 * function index
	 *
	 *
	 **/
	 public function index($page=0)
	 {
	 	$data = array();
		$this->load->library('pagination');
		$config['base_url'] 	= site_url().'feedback/index/';
		$config['total_rows'] 	= count($this->main_model->select_as_object('feedback','','feedback_id','DESC',FALSE));
		$config['per_page'] 	= 3;
		$config['uri_segment']	= 3;
		$config['full_tag_open']  = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_tag_open']  = '<li>';
    	$config['prev_tag_close'] = '</li>';
    	$config['next_tag_open']  = '<li>';
    	$config['next_tag_close'] = '</li>';
   	    $config['cur_tag_open']   = '<li class="active"><a href="#">';
    	$config['cur_tag_close']  = '</a></li>';
    	$config['num_tag_open']   = '<li>';
    	$config['num_tag_close']  = '</li>';
     	$config['first_link']     = FALSE;
    	$config['last_link']      = FALSE;
		$this->pagination->initialize($config);
	
		$data['page']            =$page;
		$data['count'] = $page;
		$data["feedback_details"]	=	 $this->main_model->select_as_object('feedback','','feedback_id','DESC',FALSE,$config['per_page'],$page);
		
	 	$this->load->view($this->common_view_path.'inner_header');
		
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'inner_footer');
	 }
}
