
    

<section class="project_sec_bg">
<!-- Four Columns -->
<div class="container-fluid">
<div class="row">

<div class="project_wrapper animated fadeInUp">

<div class="project_title">
events
</div>

<div class="col-sm-12">
<div class="box-inner">

<div class="row events_area-sec">
<div class="col-md-12">
<div>

<?php if($events_details) { ?>
<?php foreach($events_details as $events):  ?>
<div class="events_timeline">
<div class="events_timeline-item events_timeline-item-bordered">
<!-- timeline entry -->
<?php $stamp = strtotime($events->posted_on);?>
<div class="events_timeline-entry">
<small class="events_strong"><?php echo date("d",$stamp);?></small>
<div class="clearfix"></div>
<strong class="events_small_mid"><?php echo date("M",$stamp);?></strong>
<div class="clearfix"></div>
<small class="events_small"><?php echo date("Y",$stamp);?></small>
<div class="events_timeline-vline"></div>
</div>
<!-- /timeline entry -->

<h2 class="uppercase bold size-17 events_dud"><?php echo $events->title?></h2>
<div class="forum-content">
<div class="comments-space">
<?php echo $events->description?></div>
</div>
</div>
</div>
<?php  endforeach; ?>
<?php }
      
else { ?>
	<div id="events"><center><p style="color:gray" class="nodataFound">No Data Found.</p></center></div>
<?php	
}
   ?>
</div>
<div class="text-center">
<?php echo $this->pagination->create_links(); ?>
</div>


</div>
</div>


</div>
</div>





</div>
</div>
</div>
<!-- End Four Columns -->
</section>


 
