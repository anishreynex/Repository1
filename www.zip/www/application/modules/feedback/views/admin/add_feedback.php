<section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
       <div class="pageHeadRow">
        <div class="pagetble-cell">
          <h3 data-toggle="tooltip"  title="Feedback" class="page-subHead">
          	 	<?php if($feedback){?>         	 	
       <?php echo "Edit Feedback";?>
          	 		
          	 <?php	} 
          	 	else
          	 	{?>
          	 		<?php echo "Add Feedback";?>
          	 <?php	} ?>
          	 
          	 	
        </h3>
        </div>
        <div class="pagetble-cell text-right">
          <ol class="breadcrumb">
            <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
           <li class="active"><a href="<?php echo base_url('admin/feedback/view_feedback');?>">Feedback</a></li>
           <li class="active">Add Feedback</li>
          </ol>
        </div>
      </div>
      <?php
$post_array =$this->session->userdata('postarray');
?>

      <div class="row">
        <div class="col-md-10">
        	<?php
if ($feedback) {	echo form_open_multipart('admin/feedback/edit_feedback_process/' . $feedback -> feedback_id . '/' . $page, array('id' => 'edit_feedback_form'));
} else {	echo form_open_multipart('admin/feedback/add_feedback_process', array('id' => 'add_feedback_form'));
}
	?>
        <input type="hidden" name="feedback_id" value="<?php
			if ($feedback) : echo $feedback -> feedback_id;
			endif;?>" />

            
              <div class="form-group">
                <label for="exampleInputPassword1"><strong>Feedback By</strong> <span class="form_error">*</span><br><small></small></label>
                <input type="text" class="form-control"  name="txt_title" maxlength="100" id="txt_title" placeholder="Feedback By" 
                value="<?php if ($feedback) { echo $feedback -> title;} elseif ($post_array) { echo $post_array['title'];}?>">
              </div>
              
                 <div class="form-group">
                <label for="exampleInputEmail1"><strong>Feedback</strong> <span class="form_error">*</span><br><small></small></label>
                <textarea class="form-control" id="txt_descriptions" name="txt_descriptions" row="5"><?php
				if ($feedback) {echo $feedback -> description;}?></textarea>
              </div>
              
              
             
              
          
            <!--  <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
              </div>-->
            
             <!-- <div class="checkbox">
                <label>
                  <input type="checkbox"> Check me out
                </label>
              </div>-->
              
              <input type="submit" name="feedback_submit" id="feedback_submit" value="Save" class="btn btn-default" />
            	<?=anchor('admin/feedback/view_feedback' . '/' . $page, '[ Back To List ]') ?>
            <?=form_close('') ?>
                 </div>
    </div>
  </div>
</section>

    <?php
	$this -> session -> unset_userdata('postarray');
    ?>
    

