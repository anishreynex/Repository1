
<section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
      <div class="pageHeadRow">
        <div class="pagetble-cell">
          <h3 data-toggle="tooltip"  title="Feedback" class="page-subHead">Feedback
          	|
           <a href="<?php echo base_url('admin/feedback/add_feedback/') ?>" class="btn btn-success"><i class="fa fa-upload" aria-hidden="true"></i>
       	 +Add</a>
          	 </h3>
        </div>
     <div class="pagetble-cell text-right">
      <ol class="breadcrumb">
        <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
        <li class="active">Feedback</li>
      </ol>
    </div>
      </div>
      

      <div class="row">
<div class="col-md-12">
<div class="row">
<div class="col-md-12">
<div class="filterwrap">



</div>
</div>
</div>
<div class="table-responsive "> 
	    <?php if($feedback): ?> 
<table class="table table-bordered text-center"> 

<thead class="table_head">
<tr>
<th class="text-center table_head_text">Sl No</th>
<th class="text-center table_head_text">Feedback By</th>
<th class="text-center table_head_text">Action</th>
</tr>
</thead>

<tbody class="tbody_text">
<?php if($this->uri->segment(10)=='') { $slno = 1; } else { $slno = $this->uri->segment(10)+1; } ?>
<?php foreach($feedback as $feedback): ?>
<tr>
<td><?=$slno+$count?></td>
<td><?=$feedback->title?></td>
<td>
 <?php
 echo anchor('admin/feedback/edit_feedback/'.$feedback->feedback_id.'/'.$page,'Edit',array('class'=>'btn table_btn02')); 
$onclick="return confirm('Are you sure you want to delete this item?');";
echo anchor('admin/feedback/delete_feedback/'.$feedback->feedback_id.'/'.$page,'Delete',array('class'=>'class="deleteText" ','onclick'=>$onclick,'title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));?>
</td>
</td>
                    </tr>
                    <?php $slno++; endforeach; ?>
                    <tr>
                    	<td colspan="6" align="center"><?=$this->pagination->create_links()?></td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
        	<p><em>No results found!</em></p>
        <?php endif; ?>
       
    
</div>
</div>
</div>
    </div>
  </div>
     
</section>

<script>
  
  $(document).on("click", "a.deleteText", function() {
    if (confirm('Are you sure ?'))
     return true;
    return false;
     {
        $(this).prev('span.text').remove();
    }
});</script>






    
    <script type="text/javascript">
    $(document).ready(function(){
	$("a[rel=gallery]").fancybox({
		'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'feedback_titlePosition' 	: 'over',
		'feedback_titleFormat'       : function(feedback_title, currentArray, currentIndex, currentOpts) {
		    return '<span id="fancybox-feedback_title-over">Image ' +  (currentIndex + 1) + ' / ' + currentArray.length + ' ' + feedback_title + '</span>';
		}
	});						   
	});
    </script>
