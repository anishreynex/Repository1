<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @ Author  		: Chaitra RS
 *
 * @ Created On  	: 09/26/2011
 * @ Modified On 	: 09/26/2011
 *
 * Class to manage the events section.
 *
**/
class Feedback_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function any_function
	 *
	 *
	 **/
	 public function any_function()
	 {
	 	//index
	 }
	 public function delete_feedback($id)
	 {
	 	$this->db->where('feedback_id',$id);
		if($this->db->delete('feedback'))
		{
			return true;
		}
		else {
			return false;
		}
	 }
}
