<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class About Us_model
* Model Class to manage Administrator option of Rooms
*
**/
class Rooms_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function any_function
	 *
	 *
	 **/
	  public function delete_rooms($id)
	 {
	 	$this->db->where('room_id',$id);
		if($this->db->delete('room'))
		{
			return true;
		}
		else {
			return false;
		}
	 }
}
