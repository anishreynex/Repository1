<?php if (!defined('BASEPATH'))exit('No direct script access allowed');
$autoload['model'] = array('Rooms_model');
/**
 * class Admin
 * Class to manage Administrator option of services
 *
 **/
class Admin extends CI_Controller {
	protected $common_view_path = 'templates/admin/';
	protected $module_view_path = 'rooms/admin/';

	public function __construct() {
		parent::__construct();
		$this -> load -> library('session');

		if (!$this -> ion_auth -> logged_in()) {
			redirect('admin/auth');
		}
	}

	public function add_room($page='')
	 {
		$this->load->view($this->common_view_path.'header');
		$data['page_title']        ='Add room';
		$data['room']      ="";
		$data['page']              =$page;
		$data['right_panel']       = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'add_room',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	public function add_room_process()
	 {
	 	$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('txt_title', 'Title', 'required');
		$this->form_validation->set_rules('txt_descriptions', 'Description', 'required');
		
		
		
		
			
			$data['title']	=	$this->input->post('txt_title');
			$data['single']	=	$this->input->post('txt_single');
			$data['double']	=	$this->input->post('txt_double');
			$data['bed']	=	$this->input->post('txt_bed');
			if($this->db->insert('room',$data))
			{
				redirect('admin/room/view_room');
				$this->session->set_flashdata('message',error_message('Room Added Successfully.'));	
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Room adding failed.'));	
							}
		}
		public function view_room($page=0)
	{
		$config['base_url'] 	= site_url().'admin/room/view_room/';
		$config['total_rows'] 	= count($this->main_model->select_as_object('room','','room_id','DESC',FALSE));
		$config['per_page'] 	= 10;
		$config['uri_segment']	= 4;
		$this->pagination->initialize($config);
		$data['page']            =$page;
		$data['count'] = $page;
		$data['room']=$this->main_model->select_as_object('room','','room_id ','DESC',FALSE,$config['per_page'],$page);
		$data['right_panel']    = $this->load->view($this->common_view_path.'right_panel','',true);	
		$this->load->view($this->common_view_path.'header');
	    $this->load->view($this->module_view_path.'index',$data);
        $this->load->view($this->common_view_path.'footer');
		
		
	}

  function edit_room($id='',$page='')
	{
		if($id)
		{
			
	    $this->session->unset_userdata('uploaded_file_name');
		$this->session->unset_userdata('file_upload_error');
	    $this->load->view($this->common_view_path.'header');
		
		$data['action']	         ='Edit';
		$data['page']            =$page;
		$data['room']	 = $this->main_model->select_as_object('room',array('room_id'=>$id),'','',TRUE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);	
		 
		$this->load->view($this->module_view_path.'add_room',$data);
		$this->load->view($this->common_view_path.'footer');
		
	
	}
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			redirect('admin/rooms/edit_room');
		}
	}

    public function edit_room_process($id='',$page='')
	{
		
		
	   $id = $this->input->post('room_id');
	
		if($id)
		{
			
				
				$data['title']	=	$this->input->post('txt_title');
			    $data['single']	=	$this->input->post('txt_single');
				$data['double']	=	$this->input->post('txt_double');
				$data['bed']	=	$this->input->post('txt_bed');
				
				
				$this->db->where('room_id',$id);
			    if($this->db->update('room',$data))
				{
				
				$this->session->set_flashdata('message',success_message('Room updated successfully.'));	
				redirect('admin/rooms/view_room'.'/'.$page);
					
			  }
				else
				{
					$this->session->set_flashdata('message',error_message('Room uploading failed.'));	
					redirect('admin/rooms/view_room'.'/'.$page);
				}
			}
			
		
	}

        function delete_room($id='',$page='')
	{
		$autoload['model'] = array('rooms_model');
		if($id)
		{
			
		$this->db->where('room_id',$id);
			if($this->db->delete('room'))
			{
				
				$this->session->set_flashdata('message',success_message('room deleted successfully.'));	
			}
			else
			{	$this->session->set_flashdata('message',error_message('room deletion failed.'));	}
			redirect('admin/rooms/view_room'.'/'.$page);
		}
		
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			redirect('admin/rooms/view_room'.'/'.$page);
		}
	
	}
	 	
	 }

