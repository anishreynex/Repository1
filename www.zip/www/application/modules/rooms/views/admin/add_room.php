<section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
       <div class="pageHeadRow">
        <div class="pagetble-cell">
          <h3 data-toggle="tooltip"  title="Edit Rooms" class="page-subHead">
          	 	Edit Rooms
        </h3>
        </div>
        <div class="pagetble-cell text-right">
          <ol class="breadcrumb">
            <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
           <li class="active"><a href="<?php echo base_url('admin/rooms/view_room');?>" data-toggle="tooltip"  title="Rooms">Rooms</a></li>
           <li class="active">Edit room</li>
          </ol>
        </div>
      </div>
      <?php
$post_array =$this->session->userdata('postarray');
?>

      <div class="row">
        <div class="col-md-10">
        	<?php
if ($room) {	echo form_open_multipart('admin/rooms/edit_room_process/' . $room -> room_id . '/' . $page, array('id' => 'edit_room_form'));
} else {	echo form_open_multipart('admin/rooms/add_room_process', array('id' => 'add_room_form'));
}
	?>
        <input type="hidden" name="room_id" value="<?php
			if ($room) : echo $room -> room_id;
			endif;?>" />

            
              <div class="form-group">
                <label for="exampleInputPassword1"><strong>Room Name</strong> <span class="form_error">*</span><br><small></small></label>
                <input type="text" class="form-control"  name="txt_title" maxlength="100" id="txt_title" placeholder="Room Name" 
                value="<?php if ($room) { echo $room -> title;} elseif ($post_array) { echo $post_array['title'];}?>">
              </div>
              
                 <div class="form-group">
                <label for="exampleInputEmail1"><strong>Single</strong> <span class="form_error">*</span><br><small></small></label>
                
				 <input type="text" class="form-control"  name="txt_single" maxlength="100" id="txt_single" placeholder="Single" 
                value="<?php if ($room) {echo $room -> single;}?>">
              </div>
                <div class="form-group">
                <label for="exampleInputEmail1"><strong>Double</strong> <span class="form_error">*</span><br><small></small></label>
               
					 <input type="text" class="form-control"  name="txt_double" maxlength="100" id="txt_double" placeholder="Double" 
                value="<?php
				if ($room) {echo $room -> double;}?>">
              </div>
                <div class="form-group">
                <label for="exampleInputEmail1"><strong>Extra Bed</strong> <span class="form_error">*</span><br><small></small></label>
                
              <input type="text" class="form-control"  name="txt_bed" maxlength="100" id="txt_bed" placeholder="Extra Bed" 
                value="<?php
				if ($room) {echo $room -> bed;}?>">
             
              <br>
          
            <!--  <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
              </div>-->
            
             <!-- <div class="checkbox">
                <label>
                  <input type="checkbox"> Check me out
                </label>
              </div>-->
              
              <input type="submit" name="room_submit" id="room_submit" value="Save" class="btn btn-default" />
            	<?=anchor('admin/rooms/view_room' . '/' . $page, '[ Back To List ]') ?>
            <?=form_close('') ?>
                 </div>
    </div>
  </div>
</section>

    <?php
	$this -> session -> unset_userdata('postarray');
    ?>
    

