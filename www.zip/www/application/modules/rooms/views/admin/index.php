
<section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
<div class="pageHeadRow">
    <div class="pagetble-cell">
       <h3 data-toggle="tooltip"  title="Room Details" class="page-subHead">
          	 	Rooms
        </h3>
    </div>
    <div class="pagetble-cell text-right">
      <ol class="breadcrumb">
        <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
        <li class="active">Rooms</li>
      </ol>
    </div>
</div>
      <?php echo $this->session->flashdata('message')?>

      <div class="row">
<div class="col-md-12">
<div class="row">
<div class="col-md-12">
<div class="filterwrap">



</div>
</div>
</div>
<div class="table-responsive "> 
	    <?php if($room): ?> 
<table class="table table-bordered text-center"> 

<thead class="table_head">
<tr>
<th class="text-center table_head_text">Sl No</th>
<th class="text-center table_head_text">Room Name</th>
<th class="text-center table_head_text">Action</th>
</tr>
</thead>

<tbody class="tbody_text">
<?php if($this->uri->segment(10)=='') { $slno = 1; } else { $slno = $this->uri->segment(10)+1; } ?>
<?php foreach($room as $room): ?>
<tr>
<td><?=$slno+$count?></td>
<td><?=$room->title?></td>
<td>
 <?php
 echo anchor('admin/rooms/edit_room/'.$room->room_id.'/'.$page,'Edit',array('class'=>'btn table_btn02')); 
$onclick="return confirm('Are you sure you want to delete this item?');";
/*echo anchor('admin/rooms/delete_room/'.$room->room_id.'/'.$page,'Delete',array('class'=>'class="deleteText" ','onclick'=>$onclick,'title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));*/?>
</td>
</td>
                    </tr>
                    <?php $slno++; endforeach; ?>
                    <tr>
                    	<td colspan="6" align="center"><?=$this->pagination->create_links()?></td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
        	<p><em>No results found!</em></p>
        <?php endif; ?>
       
    
</div>
</div>
</div>
    </div>
  </div>
     
</section>

<script>
  
  $(document).on("click", "a.deleteText", function() {
    if (confirm('Are you sure ?'))
     return true;
    return false;
     {
        $(this).prev('span.text').remove();
    }
});</script>






    
    <script type="text/javascript">
    $(document).ready(function(){
	$("a[rel=gallery]").fancybox({
		'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'room_titlePosition' 	: 'over',
		'room_titleFormat'       : function(room_title, currentArray, currentIndex, currentOpts) {
		    return '<span id="fancybox-room_title-over">Image ' +  (currentIndex + 1) + ' / ' + currentArray.length + ' ' + room_title + '</span>';
		}
	});						   
	});
    </script>
