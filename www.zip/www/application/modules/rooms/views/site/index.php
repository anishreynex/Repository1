 <!-- Modal -->
  
   <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
     <div class="modal-header">
     	 <?php $room1 = $this->main_model->select_as_object('room',array('room_id'=>39),'room_id','DESC',TRUE);?>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title modal-title-02" id="myModalLabel"><?php echo $room1->title;?></h4>
      </div>
      
      <div class="modal-body">
        <div class="modal-img">
        <img src="<?php echo base_url();?>assets/themes/site/images/modal-img-pop-01.jpg" class="img-responsive">
        </div>
        
        
       
        
        <div>
        <table class="table table-bordered">
        <thead>
        <tr class="success02">
        <th>Room Category</th>
        <th>Rates</th>
        </tr>
        </thead>
        <tbody>
        <tr class="success-dis">
        <td>Single</td>
        <td>&#x20B9;&nbsp; <?php echo $room1->single;?></td>
        </tr>
        <tr>
        <td>Double</td>
        <td>&#x20B9;&nbsp; <?php echo $room1->double;?></td>
        </tr>
        <tr  class="success-dis2">
        <td colspan="2" class="extra-bed">Extra Person / Bed: &#x20B9;&nbsp;<?php echo $room1->bed;?> /-</td>
        </tr>
        </tbody>
        </table>
        </div>
      </div>
      
     
      
    </div>
  </div>
</div>

  <!-- Modal End -->
  
  
     <!-- Modal -->
  
   <div class="modal fade bs-example-modal-md2" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
     <div class="modal-header">
     	<?php $room2 = $this->main_model->select_as_object('room',array('room_id'=>40),'room_id','DESC',TRUE);?>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title  modal-title-02" id="myModalLabel"><?php echo $room2->title;?></h4>
      </div>
      
      <div class="modal-body">
        <div class="modal-img">
        <img src="<?php echo base_url();?>assets/themes/site/images/modal-img-pop-02.jpg" class="img-responsive">
        </div>
        
        
        <div>
        <table class="table table-bordered">
        <thead>
        <tr class="success02">
        <th>Room Category</th>
        <th>Rates</th>
        </tr>
        </thead>
        <tbody>
        <tr class="success-dis">
        <td>Single</td>
        <td>&#x20B9;&nbsp; <?php echo $room2->single;?></td>
        </tr>
        <tr>
        <td>Double</td>
        <td>&#x20B9;&nbsp; <?php echo $room2->double;?></td>
        </tr>
        <tr  class="success-dis2">
        <td colspan="2" class="extra-bed">Extra Person / Bed: &#x20B9;&nbsp;<?php echo $room2->bed;?> /-</td>
        </tr>
        </tbody>
        </table>
        </div>
      </div>
      
      
      
    </div>
  </div>
</div>

  <!-- Modal End -->



   <!-- Modal -->
  
   <div class="modal fade bs-example-modal-md3" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
     <div class="modal-header">
     	<?php $room3 = $this->main_model->select_as_object('room',array('room_id'=>41),'room_id','DESC',TRUE);?>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title  modal-title-02" id="myModalLabel"><?php echo $room3->title;?></h4>
      </div>
      
      <div class="modal-body">
        <div class="modal-img">
        <img src="<?php echo base_url();?>assets/themes/site/images/modal-img-504.jpg" class="img-responsive">
        </div>

        
        <div>
        <table class="table table-bordered">
        <thead>
        <tr class="success02">
        <th>Room Category</th>
        <th>Rates</th>
        </tr>
        </thead>
        <tbody>
        <tr class="success-dis">
        <td>Single</td>
        <td>&#x20B9;&nbsp; <?php echo $room3->single;?></td>
        </tr>
        <tr>
        <td>Double</td>
        <td>&#x20B9;&nbsp; <?php echo $room3->double;?></td>
        </tr>
        <tr  class="success-dis2">
        <td colspan="2" class="extra-bed">Extra Person / Bed: &#x20B9;&nbsp;<?php echo $room3->bed;?> /-</td>
        </tr>
        </tbody>
        </table>
        </div>
      </div>
      
      
    </div>
  </div>
</div>

  <!-- Modal End -->
   <section class="seven-hills-about">
   <div class="seven-background"></div>
	<div class="container">
    <div class="row seven-row">
    <div class="col-md-12">
    <div class="seven-white">
    <h4 class="title-dist"><span class="span-padd"><img src="<?php echo base_url();?>assets/themes/site/images/side-logo.png"></span>Rooms</h4>
    
    <div class="row">
    
    <div class="col-md-12 dist">
    <div class="content-wrap">
   
   <div class="room-content">
   <div class="row">
   
  	<div class="col-md-4 col-sm-4">
    
<?php $room1 = $this->main_model->select_as_object('room',array('room_id'=>39),'room_id','DESC',TRUE);?>
   <div>
   <figure  class="mg-room">
   <img src="<?php echo base_url();?>assets/themes/site/images/room-01.jpg" class="img-responsive">
   <figcaption>
   <h2><?php echo $room1->title;?></h2>
   <div class="mg-room-price"><b>&#x20B9;&nbsp;<?php echo $room1->single;?> - &#x20B9;&nbsp;<?php echo $room1->double;?></b></div>
   <!--<p>adversantur probatum iudicante indicaverunt repugnantibus.</p>-->
   <a href="#" class="btn btn-link" data-toggle="modal" data-target=".bs-example-modal-md">View Details <i class="fa fa-angle-double-right"></i></a>
   </figcaption>
   </figure>
   </div>
   </div>
   
	<div class="col-md-4 col-sm-4">
		<?php $room2 = $this->main_model->select_as_object('room',array('room_id'=>40),'room_id','DESC',TRUE);?>
   <div>
   <figure  class="mg-room">
   <img src="<?php echo base_url();?>assets/themes/site/images/room-02.jpg" class="img-responsive">
   <figcaption>
   <h2><?php echo $room2->title;?></h2>
   <div class="mg-room-price"><b>&#x20B9;&nbsp;<?php echo $room2->single;?> - &#x20B9;&nbsp;<?php echo $room2->double;?></b></div>
   <!--<p>adversantur probatum iudicante indicaverunt repugnantibus.</p>-->
   <a href="#" class="btn btn-link" data-toggle="modal" data-target=".bs-example-modal-md2">View Details <i class="fa fa-angle-double-right"></i></a>
   </figcaption>
   </figure>
   </div>
   </div>
   
    <div class="col-md-4 col-sm-4">
    <?php $room3 = $this->main_model->select_as_object('room',array('room_id'=>41),'room_id','DESC',TRUE);?>
    
   <div>
   <figure  class="mg-room">
   <img src="<?php echo base_url();?>assets/themes/site/images/room-03.jpg" class="img-responsive">
   <figcaption>
   <h2><?php echo $room3->title;?></h2>
   <div class="mg-room-price"><b>&#x20B9;&nbsp;<?php echo $room3->single;?> - &#x20B9;&nbsp;<?php echo $room3->double;?></b></div>
   <!--<p>adversantur probatum iudicante indicaverunt repugnantibus.</p>-->
   <a href="#" class="btn btn-link" data-toggle="modal" data-target=".bs-example-modal-md3">View Details <i class="fa fa-angle-double-right"></i></a>
   </figcaption>
   </figure>
   </div>
   </div>
   
    <div class="col-md-12 col-sm-12">
    <h4 class="room-terms">Terms And Conditions</h4>
    
    <div class="terms-li">
    <ul>
    <li>Inclusive of Breakfast</li>
    <li>15% Luxury taxes extra on Room Tariff</li>
    <li>No charge for two children under 10 years occupying the same room without an extra bed.</li>
    <li>No-show or cancellation of a guaranteed reservation 24 hours prior to arrival, will attract one night's retention charge.</li>
    <li>Any taxes existing on the day of stay will also be applicable</li>
    <li>Kitchen and dining facilities available at roof top for group bookings.</li>
    <li>24 hours Checkin / Checkout</li>
    <li>All major Credit / Debit Cards accepted</li>
    <li>Note: Compulsory New Year Eve supplement @ &#x20B9;&nbsp;750/- per person will be applicable. Children above 10 years @ &#x20B9;&nbsp;450/- per child</li>
    </ul>
    </div>
    </div>
    
   
   </div>
   </div>
   
   </div>
   <div class="clearfix"></div>
   
   </div>
    
    
    
    </div>
    
    </div>
    </div>
    </div>
    </div>
   </section>
   
  <div class="clearfix"></div>
  
