<section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
       <div class="pageHeadRow">
        <div class="pagetble-cell">
          <h3 data-toggle="tooltip"  title="Services" class="page-subHead">
          	 	<?php if($services){?>         	 	
       <?php echo "Edit Services";?>
          	 		
          	 <?php	} 
          	 	else
          	 	{?>
          	 		<?php echo "Add Services";?>
          	 <?php	} ?>
        </h3>
        </div>
        <div class="pagetble-cell text-right">
          <ol class="breadcrumb">
            <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
           <li class="active"><a href="<?php echo base_url('admin/services/view_services');?>">Services</a></li>
           <li class="active">Add services</li>
          </ol>
        </div>
      </div>
      <?php
$post_array =$this->session->userdata('postarray');
?>

      <div class="row">
        <div class="col-md-10">
        	<?php
if ($services) {	echo form_open_multipart('admin/services/edit_services_process/' . $services -> services_id . '/' . $page, array('id' => 'edit_services_form'));
} else {	echo form_open_multipart('admin/services/add_services_process', array('id' => 'add_services_form'));
}
	?>
        <input type="hidden" name="services_id" value="<?php
			if ($services) : echo $services -> services_id;
			endif;?>" />

            
              <div class="form-group">
                <label for="exampleInputPassword1"><strong>Services Name</strong> <span class="form_error">*</span><br><small></small></label>
                <input type="text" class="form-control"  name="txt_title" maxlength="100" id="txt_title" placeholder="services Name" 
                value="<?php if ($services) { echo $services -> title;} elseif ($post_array) { echo $post_array['title'];}?>">
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Title</strong> <span class="form_error">*</span><br><small></small></label>
                <input type="text" class="form-control"  name="txt_name" maxlength="100" id="txt_name" placeholder="Title" 
                value="<?php if ($services) { echo $services ->name;} elseif ($post_array) { echo $post_array['name'];}?>">
              </div>
                 <div class="form-group">
                <label for="exampleInputEmail1"><strong>Description</strong> <span class="form_error">*</span><br><small></small></label>
              
                <textarea class="form-control" id="txt_description" cols="100" rows="5" name="txt_description" ><?php if ($services) {echo $services -> description;}?></textarea>
              </div>
             
            
          
            <!--  <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
              </div>-->
            
             <!-- <div class="checkbox">
                <label>
                  <input type="checkbox"> Check me out
                </label>
              </div>-->
              
              <input type="submit" name="services_submit" id="services_submit" value="Save" class="btn btn-default" />
            	<?=anchor('admin/services/view_services' . '/' . $page, '[ Back To List ]') ?>
            <?=form_close('') ?>
                 </div>
    </div>
  </div>
</section>

    <?php
	$this -> session -> unset_userdata('postarray');
    ?>
    

