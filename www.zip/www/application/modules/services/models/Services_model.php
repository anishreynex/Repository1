<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class About Us_model
* Model Class to manage Administrator option of Rooms
*
**/
class Services_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function any_function
	 *
	 *
	 **/
	  public function delete_services($id)
	 {
	 	$this->db->where('services_id',$id);
		if($this->db->delete('services'))
		{
			return true;
		}
		else {
			return false;
		}
	 }
}
