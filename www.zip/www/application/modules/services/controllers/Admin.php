<?php if (!defined('BASEPATH'))exit('No direct script access allowed');
$autoload['model'] = array('services_model');
/**
 * class Admin
 * Class to manage Administrator option of services
 *
 **/
class Admin extends CI_Controller {
	protected $common_view_path = 'templates/admin/';
	protected $module_view_path = 'services/admin/';

	public function __construct() {
		parent::__construct();
		$this -> load -> library('session');

		if (!$this -> ion_auth -> logged_in()) {
			redirect('admin/auth');
		}
	}

	public function add_services($page='')
	 {
		$this->load->view($this->common_view_path.'header');
		$data['page_title']        ='Add services';
		$data['services']      ="";
		$data['page']              =$page;
		$data['right_panel']       = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'add_services',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	public function add_services_process()
	 {
	 	$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('txt_title', 'Title', 'required');
		$this->form_validation->set_rules('txt_descriptions', 'Description', 'required');
		
		
		
		
			
			$data['title']	=	$this->input->post('txt_title');
			$data['name']	=	$this->input->post('txt_name');
			$data['description']	=	$this->input->post('txt_description');
			
			if($this->db->insert('services',$data))
			{
				redirect('admin/services/view_services');
				$this->session->set_flashdata('message',error_message('Services Added Successfully.'));	
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Services adding failed.'));	
							}
		}
		public function view_services($page=0)
	{
		$config['base_url'] 	= site_url().'admin/services/view_services/';
		$config['total_rows'] 	= count($this->main_model->select_as_object('services','','services_id','DESC',FALSE));
		$config['per_page'] 	= 10;
		$config['uri_segment']	= 4;
		$this->pagination->initialize($config);
		$data['page']            =$page;
		$data['count'] = $page;
		$data['services']=$this->main_model->select_as_object('services','','services_id ','DESC',FALSE,$config['per_page'],$page);
		$data['right_panel']    = $this->load->view($this->common_view_path.'right_panel','',true);	
		$this->load->view($this->common_view_path.'header');
	    $this->load->view($this->module_view_path.'index',$data);
        $this->load->view($this->common_view_path.'footer');
		
		
	}

  function edit_services($id='',$page='')
	{
		if($id)
		{
			
	    $this->session->unset_userdata('uploaded_file_name');
		$this->session->unset_userdata('file_upload_error');
	    $this->load->view($this->common_view_path.'header');
		
		$data['action']	         ='Edit';
		$data['page']            =$page;
		$data['services']	 = $this->main_model->select_as_object('services',array('services_id'=>$id),'','',TRUE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);	
		 
		$this->load->view($this->module_view_path.'add_services',$data);
		$this->load->view($this->common_view_path.'footer');
		
	
	}
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			redirect('admin/services/edit_services');
		}
	}

    public function edit_services_process($id='',$page='')
	{
		
		
	   $id = $this->input->post('services_id');
	
		if($id)
		{
			
				
				$data['title']	=	$this->input->post('txt_title');
				$data['name']	=	$this->input->post('txt_name');
			    $data['description']	=	$this->input->post('txt_description');
			
				
				
				$this->db->where('services_id',$id);
			    if($this->db->update('services',$data))
				{
				
				$this->session->set_flashdata('message',success_message('Services updated successfully.'));	
				redirect('admin/services/view_services'.'/'.$page);
					
			  }
				else
				{
					$this->session->set_flashdata('message',error_message('Services uploading failed.'));	
					redirect('admin/services/view_services'.'/'.$page);
				}
			}
			
		
	}

        function delete_services($id='',$page='')
	{
		$autoload['model'] = array('services_model');
		if($id)
		{
			
		$this->db->where('services_id',$id);
			if($this->db->delete('services'))
			{
				
				$this->session->set_flashdata('message',success_message('Services deleted successfully.'));	
			}
			else
			{	$this->session->set_flashdata('message',error_message('Services deletion failed.'));	}
			redirect('admin/services/view_services'.'/'.$page);
		}
		
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			redirect('admin/services/view_services'.'/'.$page);
		}
	
	}
	 	
	 }

