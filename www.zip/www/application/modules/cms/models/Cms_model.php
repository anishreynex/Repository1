<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @ Author  		: Chaitra RS
 *
 * @ Created On  	: 09/29/2011
 * @ Modified On 	: 09/29/2011
 *
 * Class to manage the cms section.
 *
**/
class Cms_model extends CI_Model
{
	/**
	 * function add_page_process
	 * process the administrator create cms page action
	**/
	function add_page_process()
	{
		$this->db->where('page_title',$this->input->post('page_title'));
		$count = $this->db->count_all_results('cms_page');
		
		if($count==0)
		{	
			$data['page_title']			= $this->input->post('page_title');
			//$data['page_alias']			= strtolower(str_replace(' ','-',$this->input->post('page_title')));
			$data['page_alias']			= $this->input->post('url_title');
			$data['page_category']		= $this->input->post('category');
			$data['page_excerpt']		= $this->input->post('excerpt');
			$data['page_content']		= $this->input->post('page_content');
			$data['page_created_on']	= time();
			$data['page_modified_on ']	= time();		
			
			if($this->db->insert('cms_page',$data))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Page title already exist! please try another.'));
			redirect('admin/cms/add_page');
		}
	}
		
	/**
	 * function edit_page_process
	 * process the administrator cms page updation process
	**/
	function edit_page_process()
	{
		$this->db->where('cms_page_id !=',$this->input->post('hidden_page_id'));
		$this->db->where('page_title',$this->input->post('page_title'));
		$count = $this->db->count_all_results('cms_page');
		if($count==0)
		{
			//$data['page_title']			= $this->input->post('page_title');
			//$data['page_alias']			= $this->input->post('url_title');
			$data['page_category']		= $this->input->post('category');
			$data['page_excerpt']		= $this->input->post('excerpt');
			$data['page_content']		= $this->input->post('page_content');
			$data['page_modified_on ']	= time();
			
			$this->db->where('cms_page_id',$this->input->post('hidden_page_id'));
			if($this->db->update('cms_page',$data))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Page title already exist! please try another.'));
			redirect('admin/cms');
		}
	}
	
	/**
	 * function delete_cms_page
	 * process the administrator delete cms page action.
	**/
	function delete_cms_page($page_id)
	{
		$this->db->where('cms_page_id',$page_id);
		if($this->db->delete('cms_page'))
		{	return true;	}
		else
		{	return false;	}
	}
	
	/**
	 * function get_page()
	 * params $page_title, $strip_tags
	 * returns page saved in database
	 *
	 * @authour Abin
	 **/
	function get_page($page_alias, $strip_tags=FALSE, $allowed_tags='', $word_limiter='')
	{
		$page	= $this->main_model->select_as_object('cms_page', array('page_alias'=>$page_alias), '', '', TRUE);
		
		if($page)
		{
			if($strip_tags == TRUE)
			{
				if($word_limiter)
				return $this->strip_all_tags(word_limiter($page->page_content, $word_limiter), $allowed_tags);
				else
				return $this->strip_all_tags($page->page_content, $allowed_tags);
			}
			else
			{
				if($word_limiter)
				return word_limiter($page->page_content, $word_limiter);
				else
				return $page->page_content;
			}
		}
		else
		{
			return error_message('A page with given title not found in database');
		}
		
	}
	
	/**
	 * function strip_all_tags()
	 **/
	
	function strip_all_tags($page, $allowed_tags)
	{	
		$result = strip_tags($page, $allowed_tags);
		$result = $this->clean_inside_tags($result,$allowed_tags);
		
		return $result;
		
	}
	
	//Clean the inside of the tags
	function clean_inside_tags($txt,$tags)
	{
	    preg_match_all("/<([^>]+)>/i",$tags,$allTags,PREG_PATTERN_ORDER);
	
		foreach ($allTags[1] as $tag){
			$txt = preg_replace("/<".$tag."[^>]*>/i","<".$tag.">",$txt);
		}
	
		return $txt;
	}
	function get_title($page_alias)
	{
		$title	= $this->main_model->select_as_object('cms_page', array('page_alias'=>$page_alias), '', '', TRUE);
		if(!empty($title))
		return $title->page_title;
		else
		return false;
		
	}
	
	/**
	 * function add_category_process
	 * process the add category action.

	**/
	public function add_category_process()
	{
		$this->session->unset_userdata('image_success');
		$this->session->unset_userdata('image_error');
		
		$this->session->unset_userdata('error_message');
				
		$data['cms_category_name']	= $this->input->post('page_category');
		
		if($this->upload_image())
		{
			$image_data 					    = $this->session->userdata('image_success');
			$data['cms_category_image']			= $image_data['upload_image']['file_name'];
			$data['cms_category_description']	= $this->input->post('description');
			
			if($this->db->insert('cms_category',$data))
			{
				$this->session->set_flashdata('category','');
				$this->session->set_flashdata('description','');				
				return true;	
			}
			else
			{
				$this->session->set_flashdata('category',$this->input->post('page_category'));
				$this->session->set_flashdata('description',$this->input->post('description'));
				
				return false;
			}
		}
		else
		{
			$image_error = $this->session->userdata('image_error');
			if($image_error['error'] == '<span>You did not select a file to upload.</span>')
			{
				$data['cms_category_description']	= $this->input->post('description');
				if($this->db->insert('cms_category',$data))
				{
					$this->session->set_flashdata('category','');
					$this->session->set_flashdata('description','');
				
					return true;	
				}
				else
				{
					$this->session->set_flashdata('category',$this->input->post('page_category'));
					$this->session->set_flashdata('description',$this->input->post('description'));
					
					return false;	
				}
			}
			else
			{
				$this->session->set_flashdata('category',$this->input->post('page_category'));
				$this->session->set_flashdata('description',$this->input->post('description'));
				$this->session->set_userdata('error_message',$image_error['error']);
				return false;
			}
		}
	}
	
	/**
	 * function edit_category_process
	 * process the edit category action
	**/
	public function edit_category_process()
	{
		$cat_id = $this->input->post('hidden_id');
		if($cat_id)
		{
			$this->session->unset_userdata('image_success');
			$this->session->unset_userdata('image_error');
			
			$this->session->unset_userdata('error_message');
					
			$data['cms_category_name']	= $this->input->post('page_category');
			
			if($this->upload_image())
			{
				$image_data 					    = $this->session->userdata('image_success');
				$data['cms_category_image']			= $image_data['upload_image']['file_name'];
				$data['cms_category_description']	= $this->input->post('description');
				
				$this->db->where('cms_category_id',$cat_id);
				if($this->db->update('cms_category',$data))
				{
					$this->session->set_flashdata('category','');
					$this->session->set_flashdata('description','');
					
					return true;	
				}
				else
				{
					$this->session->set_flashdata('category',$this->input->post('page_category'));
					$this->session->set_flashdata('description',$this->input->post('description'));
					
					return false;
				}
			}
			else
			{
				$image_error = $this->session->userdata('image_error');
				if($image_error['error'] == '<span>You did not select a file to upload.</span>')
				{
					$data['cms_category_description']	= $this->input->post('description');
					$this->db->where('cms_category_id',$cat_id);
					if($this->db->update('cms_category',$data))
					{
						$this->session->set_flashdata('category','');
						$this->session->set_flashdata('description','');
					
						return true;	
					}
					else
					{
						$this->session->set_flashdata('category',$this->input->post('page_category'));
						$this->session->set_flashdata('description',$this->input->post('description'));
						
						return false;	
					}
				}
				else
				{
					$this->session->set_flashdata('category',$this->input->post('page_category'));
					$this->session->set_flashdata('description',$this->input->post('description'));
					$this->session->set_userdata('error_message',$image_error['error']);
					return false;
				}
			}
		}
		else
		{	return false;	}
	}
	
	/**
	 * function delete_category
	 * process the category deletion action
	**/
	public function delete_category($category_id)
	{
		if($this->check_category_exist($category_id))
		{
			$this->db->where('cms_category_id',$category_id);
			if($this->db->delete('cms_category'))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{	return false;	}
	}
	
	/**
	 * function check_category_exist
	 * check datas exist in cms_page table.
	**/
	public function check_category_exist($category_id)
	{
		$this->db->where('page_category',$category_id);
		if($this->db->count_all_results('cms_page')==0)
		{	return true;	}
		else
		{	return false;	}
	}
	
	/**
	 * function page_title_check
	 * check wheather the page title exist in database.
	**/
	public function page_title_check()
	{
		$title = $this->input->post('page_title');	
		
		$this->db->where('page_title',$title);
		if($this->db->count_all_results('cms_page')==0)
		{	return true;	}
		else
		{	return false ;	}
	}
	
	/**
	 * function edit_page_title_check
	 * 
	**/
	public function edit_page_title_check()
	{
		$new_title = $this->input->post('page_title');	
		$old_title = $this->input->post('title');
		
		if($new_title!=$old_title)
		{
			$this->db->where('page_title',$new_title);
			if($this->db->count_all_results('cms_page')==0)
			{	return true;	}
			else
			{	return false ;	}
		}
		else
		{	return true;	}
	}
	
	public function upload_image()
	{
		$config['upload_path'] 	 = './uploads/cms_category/';
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']		 = '100';
		$config['max_width'] 	 = '1024';
		$config['max_height'] 	 = '768';
		$config['encrypt_name']	 = true;

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload())
		{
			$image_error = array('error' => $this->upload->display_errors('<span>','</span>'));
			$this->session->set_userdata('image_error',$image_error);
			return false;
		}
		else
		{
			$image_data = array('upload_image' => $this->upload->data());
			$this->image_resize('uploads/cms_category/'.$image_data['upload_image']['file_name']);
			$this->session->set_userdata('image_success',$image_data);
			return true;
		}
	}
	
	public function image_resize($path, $width=600, $height=400)
	{
		$config['image_library'] 	= 'gd2';
		$config['source_image'] 	= $path;
		$config['maintain_ratio'] 	= TRUE;
		$config['width'] 			= $width;
		$config['height'] 			= $height;
		
		$this->load->library('image_lib', $config);
		
		$this->image_lib->resize();
	}
}
