<div id="main-wrap">
    <div id="clm-left">
      <!--start banner-->
      <div id="banner">
      <div class="banner-title"><?php echo $title; ?></div>
      <img src="<?=base_url()?>assets/themes/site/images/banner-inner.jpg" width="704" height="200" /></div>
      <!--close banner-->
      <div id="conntent-text">
      <?php echo $content; ?></p></div>
    </div>
    <!--close clm-left-->
    <?=$right_panel;?>
    <!--close clm-righ-->
  </div>