<!-- content_holder starts -->
<div id="content_holder">

<?php if($page_info){ $page_title = 'Edit Page'; $button = 'Update'; } else { $page_title = 'Add Page'; $button = 'Save'; } ?>
<h1><?php echo $page_title; ?></h1>

    <!-- box_left starts -->
    <!--<div id="box_left_big">-->
    
    <?php echo $this->session->flashdata('message'); ?>

	<?php
		if($page_info)
		{	echo form_open('admin/cms/edit_page_process/'.$page_info->cms_page_id,array('id'=>'edit_page_form'));	}
		else
    	{	echo form_open('admin/cms/save_page',array('id'=>'add_page_form'));	}
	?>
	
    <input type="hidden" name="hidden_page_id" value="<?php if($page_info) { echo $page_info->cms_page_id; } ?>" />
    <input type="hidden" name="hidden_title" id="hidden_title" value="<?php if($page_info) { echo $page_info->page_title; } ?>" />
    
    <table width="100%" border="0" cellspacing="0" cellpadding="5" align="left" class="grid">
        <tr>
            <td colspan="2">
            	<strong>Page Title</strong> <span class="form_error">*</span>
           	  <div class="small_text" style="color:#999;">This will shown as page name</div>
            </td>
      </tr>
        <tr>
            <td width="66%">
           	  <input type="text" name="page_title" id="page_title" class="input textbox" value="<?php if($page_info) { echo $page_info->page_title; } ?>" />   
            </td>
          <td width="32%">&nbsp;</td>
      </tr>
        
        <tr>
            <td colspan="2">
            	<strong>Url Title</strong>
            	<div class="small_text" style="color:#999;">This will shown as page url</div>
            </td>
      </tr>
        <tr>
            <td>
            	<input type="text" name="url_title" id="url_title" readonly="readonly" class="input textbox" value="<?php if($page_info) { echo $page_info->page_alias; } ?>" />   
            </td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
        	<td colspan="2"><strong>Category</strong></td>
        </tr>
        <tr>
        	<td>
        		<select name="category" id="category" class="input select">
                <?php foreach($categories as $category): ?>
                	<option value="<?=$category->cms_category_id;?>" <?php if($page_info): if($category->cms_category_id==$page_info->page_category): echo ' selected="selected"'; endif; endif; ?>><?=$category->cms_category_name?></option>
                <?php endforeach; ?>
            	</select>
            </td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
        	<td colspan="2"><strong>Excerpt</strong></td>
        </tr>
        <tr>
            <td colspan="2">
                <textarea class="ckeditor" cols="1" id="excerpt" name="excerpt" rows="1"><?php if($page_info) { echo $page_info->page_excerpt; } ?></textarea>
            </td>
        </tr>
        
        <tr>
            <td colspan="2">
                <strong>Page content</strong> <span class="form_error">*</span>
                <div class="small_text" style="color:#999;">
                Content to be shown when the above named link clicked
                    <ul>
                        <li>Use &quot;Heading 1&quot; for main headings</li>
                        <li>Use &quot;Heading 3&quot; for sub headings</li>
                        <li>No need of adding font colors. Text will be formatted automatically. (eg: links, strong, em etc...)</li>
                    </ul>
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <textarea class="ckeditor" cols="10" id="page_content" name="page_content" rows="5"><?php if($page_info) { echo $page_info->page_content; } ?></textarea>
            </td>
        </tr>
        
        <tr>
        	<td>
            	<input id="cms_submit" type="submit" name="save" class="button" value="<?php echo $button; ?>" />
                <?php echo anchor('admin/cms',' [ Back To List ] '); ?>
            </td>
            <td>&nbsp;</td>
        </tr>
    
    </table>
    
    <!--</div>-->
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <!--<div id="box_right_small"><?php echo $right_panel; ?></div>-->
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->

<script language="javascript">
	$(document).ready(function(){
	
	$("#cms_submit").mousedown(function(){
	  for (var i in CKEDITOR.instances){
		CKEDITOR.instances[i].updateElement();
	  }
	});
		
		$("#add_page_form").validate({
			rules : {
				page_title	: {	
								required:true,
								remote:	{ url: "<?=base_url()?>admin/cms/page_title_check", type:"post" }
							  },
				page_content	: "required"
			},	
					
	
			messages: {
				page_title	: { required: "<br>The Page Title field is required", remote: "Page Title not available" },
				page_content	: "<br>The Page Content is required",
			}					 
		});
		
		$("#page_title").blur(function(){
			var page_title = $("#page_title").val().toLowerCase();
			var url_title  = page_title.replace(/ /g,'-');


			$("#url_title").val(url_title);
		});
		
		$("#edit_page_form").validate({
			rules : {
				page_title	: {	
								required:true,
								remote:	{ url: "<?=base_url()?>admin/cms/edit_page_title_check", type:"post",data: {  title:  $('#hidden_title').val() }
 }
							  },
				page_content	: "required"
			},		
	
				messages: {
				page_title	: { required: "<br>The Page Title field is required", remote: "Page Title not available" },
				page_content	: "<br>The Page Content is required",
			}				 
		});
	});
</script>