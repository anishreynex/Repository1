<!-- content_holder starts -->
<div id="content_holder">
<?=link_tag('assets/modules/cms/admin/css/cms.css')?>

<h1>View Category</h1>

    <!-- box_left starts -->
    <div id="box_left_big">
 
    <?php echo $this->session->flashdata('message'); ?>
    
    <?php if($categories): ?>
    
    <table cellpadding="5" cellspacing="0" border="0" width="100%" class="grid">
      <?php foreach($categories as $category): ?>
        <tr>
            <td width="86%"><strong><?=$category->cms_category_name?></strong></td>
            <td width="14%">
                <?php
                    echo anchor('admin/cms/page_category/'.$category->cms_category_id,'Edit',array('class'=>'small-button'));
                    if($this->cms_model->check_category_exist($category->cms_category_id))
                    {
                        echo anchor('admin/cms/delete_category/'.$category->cms_category_id,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
                    }
					else 
					{
						echo '<a class="confirm_link grey_text small-button" title="Category cannot be deleted because pages exist in this category.">Delete</a>';
					}
                ?>
            </td>
        </tr>
        <tr>
        	<td colspan="2">
            	<div class="cms_image">
                	<?php
                    	if($category->cms_category_image=='')
						{	$image_array = array('src'=>'assets/modules/cms/admin/images/no-image.gif','width'=>'100','height'=>'80');	}
						else
						{	$image_array = array('src'=>'uploads/cms_category/'.$category->cms_category_image,'width'=>'100','height'=>'80');		}
						echo img($image_array);
					?>
                </div>
                
                <div class="cms_description"><?php echo $category->cms_category_description; ?></div>
            </td>
        </tr>
	  <?php endforeach; ?>
    </table>
    
    <?php else : ?>
    	<p><em>No datas found.</em></p>
    <?php endif; ?>

    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->

<script language="javascript">
	$(document).ready(function(){
		$("#category").validate({
			rules : {
				page_category	: "required"	
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td"));
			},		
	
			messages: {
				page_category	: "The Category field is required"
			}					 
		});
	});
</script>