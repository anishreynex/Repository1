<!-- content_holder starts -->
<div id="content_holder">
<h1>View CMS Page</h1>

    <!-- box_left starts -->
    <div id="box_left_big">
    
    <?php echo $this->session->flashdata('message'); ?>

	<?php if($page_info) : ?>
    	<table width="100%" cellpadding="5" cellspacing="0" border="0" class="grid">
        
        	<thead>
                <tr>
                    <td width="7%"><strong>Sl No</strong></td>
                  	<td width="48%"><strong>Page Title</strong></td>
                    <td width="13%"><strong>Url Title</strong></td>
                  	<td width="18%"><strong>Modified On</strong></td>
                  	<td width="14%"><strong>Action</strong></td>
              </tr>
            </thead>
            
            <tbody>
            
				<?php if($this->uri->segment(4)!='') { $slno = 1; } else { $slno = $this->uri->segment(4)+1; } ?>
                <?php foreach($page_info as $page): ?>
                <tr>
                    <td><?php echo $slno; ?></td>
                    <td><?php echo $page->page_title; ?></td>
                    <td><?php echo $page->page_alias; ?></td>
                    <td><?php echo date('m/d/Y H:i',$page->page_modified_on); ?></td>
                    <td>
                        <?php
                            echo anchor('admin/cms/edit_cms_page/'.$page->cms_page_id,'Edit',array('class'=>'small-button'));

							if($this->ion_auth->in_group('superadmin')):
								echo anchor('admin/cms/delete_cms_page/'.$page->cms_page_id.'/'.str_replace('/','-',uri_string()),'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
							endif;
                        ?>
                    </td>
                </tr>
                <?php $slno++; endforeach; ?>
        	</tbody>
        </table>
    <?php else : ?>
    	<p><em>No data`s found in this section.</em></p>
    <?php endif; ?>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->