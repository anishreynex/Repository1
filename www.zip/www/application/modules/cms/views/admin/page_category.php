<!-- content_holder starts -->
<div id="content_holder">

 <?php if($edit){ $page = 'Edit'; $button = 'Update'; } else { $page = 'Add'; $button = 'Save'; } ?>

<h1>Manage Category</h1>

    <!-- box_left starts -->
    <div id="box_left_big">
    
    <?php echo $this->session->flashdata('message'); ?>
    
    <?php
		if($edit)
		{	echo form_open_multipart('admin/cms/edit_category_process',array('id'=>'category'));	}
		else
		{	echo form_open_multipart('admin/cms/add_category_process',array('id'=>'category'));	}
	?>
    
    <input type="hidden" name="hidden_id" value="<?php if($edit): echo $edit->cms_category_id ; endif; ?>" />
    
    <table cellpadding="5" cellspacing="0" border="0" width="100%" class="grid">

        <tr>
            <td colspan="2"><strong>Category <span class="form_error">*</span></strong></td>
        </tr>        
        <tr>
       	  	<td width="63%"><input type="text" name="page_category" id="page_category" class="textbox input" value="<?php if($edit): echo $edit->cms_category_name ; else : echo $this->session->flashdata('category'); endif; ?>" /></td>
            <td width="37%">&nbsp;</td>
        </tr>
        
        <?php if($edit && $edit->cms_category_image!=''): ?>
        <tr>
        	<td colspan="2"><strong>Uploaded Image</strong></td>
        </tr>
        <tr>
        	<td>
            <?php
				$image_array = array('src'=>'uploads/cms_category/'.$edit->cms_category_image,'width'=>'150');
				echo img($image_array);
			?>
            </td>
        </tr>
        <?php endif; ?>
        
        <tr>
            <td colspan="2"><strong>Image</strong></td>
        </tr>        
        <tr>
        	<td><input type="file" name="userfile" class="input textbox" /></td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
            <td colspan="2"><strong>Description</strong></td>
        </tr>        
        <tr>
        	<td><textarea name="description" id="description" class="input text_area"><?php if($edit): echo $edit->	cms_category_description ; else : echo $this->session->flashdata('description'); endif; ?></textarea></td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
        	<td>
            	<input type="submit" name="save" class="button" value="<?=$button?>" /> 
                <?=anchor('admin/cms/view_category','[ Back To List ]')?>
            </td>
            <td>&nbsp;</td>
        </tr>
            
    </table>
    <?php echo form_close(''); ?>
   
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->

<script language="javascript">
	$(document).ready(function(){
		$("#category").validate({
			rules : {
				page_category	: "required"/*,
				userfile		: {accept:'jpg|png|gif'}*/
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td").next("td"));
			},		
	
			messages: {
				page_category	: "The Category field is required"/*,
				userfile		: {accept:"Please upload a file with valid extension"}*/
			}					 
		});
	});
</script>