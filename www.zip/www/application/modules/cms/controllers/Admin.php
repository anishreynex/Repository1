<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class Admin
 * Class to display Cms section.
 *
 * @ author		: Chaitra RS
 * @ created on	: 09/29/2011
 * @ modified on : 09/29/2011
 *
 **/
class Admin extends CI_Controller {

	/**
	 * path to view folder
	 *
	 * @var string
	 **/
	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'cms/admin/';
	
	
	
	public function __construct()
	{
		parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	}
	
	/**
	 * function index
	 * loads the administrator view cms page
	 **/
	public function index()
	{
		$this->load->view($this->common_view_path.'header');
		$data['page_info']	 = $this->main_model->select_as_object('cms_page','','cms_page_id','DESC',FALSE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function add_page
	 * loads the administrator add cms page form
	**/
	public function add_page()
	{
		$this->load->view($this->common_view_path.'header');
		$data['categories']	 = $this->main_model->select_as_object('cms_category','','cms_category_name','ASC',FALSE);
		$data['page_info']   = '';
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'add_page',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function save_page()
	 * process the administrator save cms page action
	**/
	public function save_page()
	{
		if($this->cms_model->add_page_process())
		{	$this->session->set_flashdata('message',success_message('Cms page created successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Cms page creation failed.'));	}
		redirect('admin/cms/add_page');
	}
	
	/**
	 * function edit_cms_page
	 * load the administrator edit cms page form.
	**/
	public function edit_cms_page($page_id)
	{
		$this->load->view($this->common_view_path.'header');
		$data['categories']	 = $this->main_model->select_as_object('cms_category','','cms_category_name','ASC',FALSE);
		$data['page_info']	 = $this->main_model->select_as_object('cms_page',array('cms_page_id'=>$page_id),'','',TRUE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'add_page',$data);
		$this->load->view($this->common_view_path.'footer');
	}
		
	/**
	 * function edit_page_process
	 * process the administrator cms page edit action.
	**/
	public function edit_page_process($page_id)
	{
		if($this->cms_model->edit_page_process())
		{	$this->session->set_flashdata('message',success_message('Cms page updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Cms page updation failed.'));	}
		redirect('admin/cms/edit_cms_page/'.$page_id);
	}
	
	/**
	 * function delete_cms_page
	 * process the administrator delete cms page action.
	**/
	public function delete_cms_page($page_id,$redirect='')
	{
		if($this->cms_model->delete_cms_page($page_id))
		{	$this->session->set_flashdata('message',success_message('Cms page deleted successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Cms page deletion failed.'));	}
		
		if($redirect)
		{	redirect(str_replace('-','/',$redirect));	}
		else
		{	redirect('admin/cms');	}
	}
	
	/**
	 * function view_category
	 * loads the manage category page
	**/
	public function view_category()
	{
		$this->load->view($this->common_view_path.'header');
		$data['categories']	 = $this->main_model->select_as_object('cms_category','','cms_category_id','DESC',FALSE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'view_category',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function page_category
	 * loads the add category page
	**/
	public function page_category($cat_id = '')
	{
		$this->load->view($this->common_view_path.'header');
		if($cat_id)
		{
			$data['edit'] = $this->main_model->select_as_object('cms_category',array('cms_category_id'=>$cat_id),'','',TRUE);
		}
		else
		{
			$data['edit'] = '';
		}
		$data['categories']	 = $this->main_model->select_as_object('cms_category','','cms_category_id','DESC',FALSE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'page_category',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function add_category_process
	 * process the add category action.
	**/
	public function add_category_process()
	{
		if($this->cms_model->add_category_process())
		{	$this->session->set_flashdata('message',success_message('Category inserted successfully.')); redirect('admin/cms/page_category');	}
		else
		{
			if($this->session->userdata('error_message'))
			{	$this->session->set_flashdata('message',error_message($this->session->userdata('error_message')));	}
			else
			{	$this->session->set_flashdata('message',error_message('Category insertion failed.'));	}
			redirect('admin/cms/page_category');
		}
		redirect('admin/cms/page_category');
	}
	
	/**
	 * function edit_category_process
	 * process the edit category action
	**/
	public function edit_category_process()
	{
		$category_id = $this->input->post('hidden_id');
		if($category_id)
		{
			if($this->cms_model->edit_category_process())
			{	$this->session->set_flashdata('message',success_message('Category updated successfully.'));	}
			else
			{	$this->session->set_flashdata('message',error_message('Category updation failed.'));	}
			redirect('admin/cms/page_category/'.$category_id);
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			redirect('admin/cms/page_category');
		}
	}
	
	/**
	 * function delete_category
	 * process the category deletion action
	**/
	public function delete_category($category_id)
	{
		if($category_id)
		{
			if($this->cms_model->check_category_exist($category_id))
			{
				if($this->cms_model->delete_category($category_id))
				{	$this->session->set_flashdata('message',success_message('Category deleted successfully.'));	}
				else
				{	$this->session->set_flashdata('message',error_message('Category deletion failed.'));	}
				redirect('admin/cms/page_category');
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Sorry you cannot delete this category.Data exist in this category.'));
				redirect('admin/cms/page_category');
			}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			redirect('admin/cms/page_category');
		}
	}
	
	/**
	 * function page_title_check
	 * check wheather the page title exist in database.
	**/
	public function page_title_check()
	{	
		if($this->cms_model->page_title_check())
		{	echo 'true';	}
		else
		{	echo 'false';	}
	}
	
	public function edit_page_title_check()
	{
		if($this->cms_model->edit_page_title_check())
		{	echo 'true';	}
		else
		{	echo 'false';	}
	}
}
