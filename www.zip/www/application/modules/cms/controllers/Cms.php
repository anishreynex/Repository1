<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Cms extends CI_Controller {
 
	protected $common_view_path	= 'templates/site/';
	protected $module_view_path	= 'cms/site/';
	
	public function __construct()
	 {
	 	parent::__construct();
	 }

	
	function pages($url_title='')
	{

		$data['title'] = $this->cms_model->get_title($url_title);
		$data['content'] = $this->cms_model->get_page($url_title);
		
		$this->load->view($this->common_view_path.'header');
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'footer');
	}
}
