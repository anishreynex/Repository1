<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @ Author  		: Chaitra RS
 *
 * @ Created On  	: 09/27/2011
 * @ Modified On 	: 09/27/2011
 *
 * Class to manage the menu section.
 *
**/
class Menu_model extends CI_Model
{
	/**
	 * Function : add_menu
	 * process the add menu action
	**/
	function add_menu()
	{
		$data['menu_name']	= $this->input->post('menu_name');
		$data['menu_url']	= $this->input->post('menu_url');
		
		if($this->db->insert('admin_menus',$data))
		{	return true;	}
		else
		{	return false;	}
	}
	
	/**
	 * Function : add_menu_group
	 * process the add menu group action.
	**/
	function add_menu_group()
	{
		$data['menu_id']			= $this->input->post('menu');
		$data['module_id']			= $this->input->post('module');
		$data['submenu_group_name']	= $this->input->post('menu_group');
		
		if($this->db->insert('admin_submenu_group',$data))
		{	return true;	}
		else
		{	return false;	}
	}
	
	/**
	 * Function : get_menu_group
	 * fetch the menu group from db and display in as combo box.
	 **/
	 function get_menu_group()
	 {
	 	$menu_id = $this->input->post('menu_id');
		if(($menu_id) || ($menu_id==0) )
		{
			$menu_groups = $this->main_model->select_as_object('admin_submenu_group',array('menu_id'=>$menu_id,'submenu_group_status'=>1),'submenu_group_id','ASC',FALSE);
			$output  = '<select name="menu_group" id="menu_group" class="input select">';
						foreach ($menu_groups as $groups)
						{
							$output .= '<option value="'.$groups->submenu_group_id.'">'.$groups->submenu_group_name.'</option>';
						}
			$output .= '</select>';
			echo $output;			
		}
		else
		{	return false;	}
	 }
	 
	 /**
	  * function add_sub_menu
	  * process the administrator add sub menu action
	  **/
	function add_sub_menu()
	{
	$data['menu_id']		= $this->input->post('menu');
	$data['group_id']		= $this->input->post('menu_group');
	$data['submenu_name']	= $this->input->post('submenu');
	$data['submenu_url']	= $this->input->post('submenu_url');	
	
	if($this->db->insert('admin_submenus',$data))
	{	return true;	}
	else
	{	return false;	}
	}

	/**
	 * function edit_menu
	 * process the administrator edit main menu action.
	 **/
	function edit_menu()
	{
		$menu_id = $this->input->post('hidden_menu_id');
		
		$data['menu_name']	= $this->input->post('menu_name');
		$data['menu_url']	= $this->input->post('menu_url');
		
		$this->db->where('admin_menu_id',$menu_id);
		if($this->db->update('admin_menus',$data))
		{	return true;	}
		else
		{	return false;	}
	}
	
	/**
	 * function edit_group_menu
	 * process the administrator edit menu group action.
	 **/
	function edit_group_menu()
	{
		$menu_id = $this->input->post('hidden_menu_id');
		
		$data['menu_id']			= $this->input->post('menu');
		$data['module_id']			= $this->input->post('module');
		$data['submenu_group_name']	= $this->input->post('menu_group');
		
		$this->db->where('submenu_group_id ',$menu_id);
		if($this->db->update('admin_submenu_group',$data))
		{	return true;	}
		else
		{	return false;	}
	}
	
	/**
	 * function edit_group_menu
	 * process the administrator edit menu group action.
	 **/
	function edit_submenu()
	{
		$menu_id = $this->input->post('hidden_menu_id');
		
		$data['menu_id']		= $this->input->post('menu');
		$data['group_id']		= $this->input->post('menu_group');
		$data['submenu_name']	= $this->input->post('submenu');
		$data['submenu_url']	= $this->input->post('submenu_url');
		
		$this->db->where('submenu_id',$menu_id);
		if($this->db->update('admin_submenus',$data))
		{	return true;	}
		else
		{	return false;	}
	}
	
	/**
	 * function delete menu
	 * process the administrator delete menu action
	**/
	function delete_menu($table,$menu_id_field,$menu_id)
	{
		if($table == 'admin_menus')
		{
			// Delete from admin_menu_group
			$this->db->where('menu_id',$menu_id);
			$this->db->delete('admin_submenu_group');
			
			// Delete from admin_submenu
			$this->db->where('menu_id',$menu_id);
			$this->db->delete('admin_submenus');
			
			// Delete from admin_menus table.
			$this->db->where($menu_id_field,$menu_id);
			if($this->db->delete($table))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{
			$this->db->where($menu_id_field,$menu_id);
			if($this->db->delete($table))
			{	return true;	}
			else
			{	return false;	}
		}
	}
	
	/**
	 * function delete_settings_menu
	 * process the administrator delete settings menu action
	**/
	function delete_settings_menu($table,$menu_id_field,$menu_id)
	{
		if($table == 'admin_submenu_group')
		{			
			// Delete from admin_submenu
			$this->db->where('menu_id',0);
			$this->db->where('group_id',$menu_id);
			$this->db->delete('admin_submenus');
			
			// Delete from admin_menus table.
			$this->db->where($menu_id_field,$menu_id);
			if($this->db->delete($table))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{
			$this->db->where($menu_id_field,$menu_id);
			if($this->db->delete($table))
			{	return true;	}
			else
			{	return false;	}
		}
	}
}
