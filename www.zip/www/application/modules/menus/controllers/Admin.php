<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class Admin
 * Class to display Menu section.
 *
 * @ author		 : Chaitra RS
 * @ created on	 : 09/27/2011
 * @ modified on : 09/30/2011
 *
 **/
class Admin extends CI_Controller {

	/**
	 * path to view folder
	 * @var string
	 **/
	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'menus/admin/';
	
	
	
	public function __construct()
	{
		parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	}
	
	/**
	 * function index
	 * loads the administrator view menu page
	 **/
	public function index()
	{
		$this->load->view($this->common_view_path.'header');
		$data['menus'] = $this->main_model->select_as_object('admin_menus',array('menu_status'=>1),'admin_menu_id','ASC',FALSE);
		$data['right_panel'] = $this->load->view($this->module_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function add_menu
	 * loads the administrators add menu form page.
 	 **/
	public function add_menu()
	{
		$this->load->view($this->common_view_path.'header');
		$data['right_panel'] = $this->load->view($this->module_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'add_menus',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function add_menus_process
	 * process the administrator add menu action.
	 **/
	public function add_menus_process()
	{
		if($this->menu_model->add_menu())
		{	$this->session->set_flashdata('message',success_message('Menu added successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Menu insertion failed.'));	}
		redirect ('admin/menus/add_menu');
	}
	
	/**
	 * function add_menu
	 * loads the administrators add menu group form page.
 	 **/
	public function add_menu_group()
	{
		$this->load->view($this->common_view_path.'header');
		$data['main_menu']   = $this->main_model->select_as_object('admin_menus',array('menu_status'=>1),'admin_menu_id','ASC',FALSE);
		$data['modules']	 = $this->main_model->select_as_object('modules','','module_id','ASC',FALSE);
		$data['right_panel'] = $this->load->view($this->module_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'add_menu_group',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function menu_group_process
	 * process the administrator add menu group action.
	 **/
	public function menu_group_process()
	{
		if($this->menu_model->add_menu_group())
		{	$this->session->set_flashdata('message',success_message('Menu group added successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Menu group insertion failed.'));	}
		redirect ('admin/menus/add_menu_group');
	}
	
	/**
	 * function add_menu
	 * loads the administrators add sub menu form page.
 	 **/
	public function add_sub_menu()
	{
		$this->load->view($this->common_view_path.'header');
		$data['main_menu']   = $this->main_model->select_as_object('admin_menus',array('menu_status'=>1),'admin_menu_id','ASC',FALSE);
		$data['right_panel'] = $this->load->view($this->module_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'add_sub_menu',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function get_menu_group
	 * fetch the menu group from database.
	 **/
	public function get_menu_group()
	{
		$this->menu_model->get_menu_group();
	}
	
	/**
	 * function add_submenus_process
	 * process the administrators add submenu action.
	 **/
	public function add_submenus_process()
	{
		if($this->menu_model->add_sub_menu())
		{	$this->session->set_flashdata('message',success_message('Sub menu added successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Sub menu insertion failed.'));	}
		redirect('admin/menus/add_sub_menu');
	}
	
	/**
	 * function delete_menu
	 * process the delete menu action
	**/
	public function delete_menu($level,$menu_id)
	{
		if($level && $menu_id)
		{
			if($level == 'menu')
			{
				$table 			= 'admin_menus';	
				$menu_id_field	= 'admin_menu_id';
			}
			elseif($level == 'group')
			{
				$table 			= 'admin_submenu_group';
				$menu_id_field	= 'submenu_group_id';
			}
			elseif($level == 'submenu')
			{
				$table 			= 'admin_submenus';
				$menu_id_field	= 'submenu_id';
			}
			else
			{
				$table = '';	
			}
			
			if($table)
			{				
				if($this->menu_model->delete_menu($table,$menu_id_field,$menu_id))		
				{	$this->session->set_flashdata('message',success_message('Menu deleted successfully.'));	}
				else
				{	$this->session->set_flashdata('message',error_message('Menu deletion failed.'));	}
				redirect('admin/menus');
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Error occured! try again.'));
				redirect('admin/menus');
			}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error occured! try again.'));
			redirect('admin/menus');
		}
	}
	
	/**
	 * function edit_menu
	 * load the edit menu form page
	**/
	public function edit_menu($level,$menu_id)
	{
		if($level && $menu_id)
		{
			if($level == 'menu')
			{
				$table 			= 'admin_menus';	
				$menu_id_field	= 'admin_menu_id';
			}
			elseif($level == 'group')
			{
				$table 			= 'admin_submenu_group';
				$menu_id_field	= 'submenu_group_id';
			}
			elseif($level == 'submenu')
			{
				$table 			= 'admin_submenus';
				$menu_id_field	= 'submenu_id';
			}
			else
			{
				$table = '';	
			}
			
			if($table)
			{
				$data['level']    = $level;
				$data['menu_id']  = $menu_id;
				$data['menu']     = $this->main_model->select_as_object($table,array($menu_id_field=>$menu_id),'','',TRUE);
				$data['main_menu']= $this->main_model->select_as_object('admin_menus',array('menu_status'=>1),'admin_menu_id','ASC',FALSE);
				$data['modules']  = $this->main_model->select_as_object('modules','','module_id','ASC',FALSE);
				$this->load->view($this->module_view_path.'edit_menu',$data);			
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Error occured! try again.'));
				redirect('admin/menus');
			}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error occured! try again.'));
			redirect('admin/menus');
		}
	}
	
	/**
	 * function edit_menus_process
	 * process the administrator edit main menu action.
	 **/
	public function edit_menus_process()
	{
		$level 		= 'menu';
		$menu_id	= $this->input->post('hidden_menu_id');
		
		if($this->menu_model->edit_menu())
		{	$this->session->set_flashdata('message',success_message('Menu updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Menu updation successfully.'));	}
		redirect('admin/menus/edit_menu/'.$level.'/'.$menu_id);
	}
	
	/**
	 * function edit_group_process
	 * process the administrator edit menu group action.
	 **/
	public function edit_group_process()
	{
		$level 		= 'group';
		$menu_id	= $this->input->post('hidden_menu_id');
		
		if($this->menu_model->edit_group_menu())
		{	$this->session->set_flashdata('message',success_message('Menu updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Menu updation successfully.'));	}
		redirect('admin/menus/edit_menu/'.$level.'/'.$menu_id);
	}
	
	/**
	 * function edit_submenus_process
	 * process the administrator edit sub menu action.
	 **/
	public function edit_submenus_process()
	{
		$level 		= 'submenu';
		$menu_id	= $this->input->post('hidden_menu_id');
		
		if($this->menu_model->edit_submenu())
		{	$this->session->set_flashdata('message',success_message('Menu updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Menu updation successfully.'));	}
		redirect('admin/menus/edit_menu/'.$level.'/'.$menu_id);
	}

	/**
	 * function manage_settings
	 * loads the administrator manage settings page.
	**/
	public function manage_settings()
	{
		$this->load->view($this->common_view_path.'header');
		$data['menu_group'] = $this->main_model->select_as_object('admin_submenu_group',array('submenu_group_status'=>1,'menu_id'=>0),'submenu_group_id','ASC',FALSE);
		$data['right_panel'] = $this->load->view($this->module_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'manage_settings',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
	/**
	 * function delete_settings_menu
	 * process the delete settings menu action
	**/
	public function delete_settings_menu($level,$menu_id)
	{
		if($level && $menu_id)
		{
			if($level == 'group')
			{
				$table 			= 'admin_submenu_group';
				$menu_id_field	= 'submenu_group_id';
			}
			elseif($level == 'submenu')
			{
				$table 			= 'admin_submenus';
				$menu_id_field	= 'submenu_id';
			}
			else
			{
				$table = '';	
			}
			
			if($table)
			{				
				if($this->menu_model->delete_settings_menu($table,$menu_id_field,$menu_id))		
				{	$this->session->set_flashdata('message',success_message('Menu deleted successfully.'));	}
				else
				{	$this->session->set_flashdata('message',error_message('Menu deletion failed.'));	}
				redirect('admin/menus/manage_settings');
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Error occured! try again.'));
				redirect('admin/menus/manage_settings');
			}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error occured! try again.'));
			redirect('admin/menus/manage_settings');
		}
	}
	
	/**
	 * function edit_settings_menu
	 * load the edit menu form page
	**/
	public function edit_settings_menu($level,$menu_id)
	{
		if($level && $menu_id)
		{
			if($level == 'group')
			{
				$table 			= 'admin_submenu_group';
				$menu_id_field	= 'submenu_group_id';
			}
			elseif($level == 'submenu')
			{
				$table 			= 'admin_submenus';
				$menu_id_field	= 'submenu_id';
			}
			else
			{
				$table = '';	
			}
			
			if($table)
			{
				$data['level']    = $level;
				$data['menu_id']  = $menu_id;
				$data['menu']     = $this->main_model->select_as_object($table,array($menu_id_field=>$menu_id),'','',TRUE);
				$data['modules']  = $this->main_model->select_as_object('modules','','module_id','ASC',FALSE);
				$this->load->view($this->module_view_path.'edit_settings_menu',$data);			
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Error occured! try again.'));
				redirect('admin/menus');
			}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error occured! try again.'));
			redirect('admin/menus');
		}
	}
	
	/**
	 * function edit_group_process
	 * process the administrator edit menu group action.
	 **/
	public function edit_settings_group_process()
	{
		$level 		= 'group';
		$menu_id	= $this->input->post('hidden_menu_id');
		
		if($this->menu_model->edit_group_menu())
		{	$this->session->set_flashdata('message',success_message('Menu updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Menu updation successfully.'));	}
		redirect('admin/menus/edit_settings_menu/'.$level.'/'.$menu_id);
	}
	
	/**
	 * function edit_submenus_process
	 * process the administrator edit sub menu action.
	 **/
	public function edit_settings_submenus_process()
	{
		$level 		= 'submenu';
		$menu_id	= $this->input->post('hidden_menu_id');
		
		if($this->menu_model->edit_submenu())
		{	$this->session->set_flashdata('message',success_message('Menu updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Menu updation successfully.'));	}
		redirect('admin/menus/edit_settings_menu/'.$level.'/'.$menu_id);
	}
}
