<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update Menu</title>
<script type="text/javascript" src="<?=base_url()?>assets/themes/libraries/jquery/jquery-1.6.4.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/themes/plugins/validate/jquery.validate.js"></script>

<style type="text/css">
body {
	margin: 0px;
	padding: 3px;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}

h1{
	letter-spacing: -2px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 5px;
	margin-left: 0px;
	padding-top: 5px;
	padding-right: 0px;
	padding-bottom: 5px;
	padding-left: 0px;
	border-bottom:1px solid #CCC;
}

.text_box_medium{
	padding:7px;
	width:200px;
	border:#CCC 1px solid;
	-moz-border-radius:4px;
	-webkit-border-radius:4px;
}

.text_box_medium:focus{
	border:#FFB871 1px solid;
}

.select_box_medium{
	padding:7px;
	width:215px;
	border:#CCC 1px solid;
	-moz-border-radius:4px;
	-webkit-border-radius:4px;
}

.select_box_medium:focus{
	border:#FFB871 1px solid;
}

.text_area_medium{
	padding:7px;
	width:200px;
	height:150px;
	border:#CCC 1px solid;
	-moz-border-radius:4px;
	-webkit-border-radius:4px;
}

.form_error {
	color:#CC0000;
}

</style>
</head>

<body bgcolor="#F5F5F5">

<?php echo $this->session->flashdata('message'); ?>

<!-- Start Menu -->
<?php if($level == 'menu') : ?>

	<h1>Update Menu</h1>

	<?php echo form_open('admin/menus/edit_menus_process',array('id'=>'add_menu_form')); ?>

    <input type="hidden" name="hidden_menu_id" value="<?php echo $menu_id; ?>" />

	<table width="100%" cellpadding="5" cellspacing="0" border="0" id="add_menu">
    
		<tr>
            <td width="24%">Menu <span class="form_error">*</span></td>
          <td width="29%"><input type="text" name="menu_name" id="menu_name" value="<?php echo $menu->menu_name; ?>" class="text_box_medium" /></td>
          <td width="47%">&nbsp;</td>
   	  </tr>
        
        <tr>
            <td>Menu Url <span class="form_error">*</span></td>
            <td><input type="text" name="menu_url" id="menu_url" class="text_box_medium" value="<?php echo $menu->menu_url; ?>" /></td>
            <td>&nbsp;</td>
      	</tr>
        
        <tr>
        	<td>&nbsp;</td>
            <td><input type="submit" value="Update" name="edit" class="button" /></td>
            <td>&nbsp;</td>
        </tr>
    </table>
    
    <?php echo form_close(); ?>
    
<?php endif; ?>
<!-- End Menu -->

<!-- Start Menu Group -->
<?php if($level == 'group') : ?>

	<h1>Update Menu Group</h1>
	
    <?php echo form_open('admin/menus/edit_group_process',array('id'=>'menu_group_form')); ?>

	<input type="hidden" name="hidden_menu_id" value="<?php echo $menu_id; ?>" />
    
	<table width="100%" cellpadding="5" cellspacing="0" border="0" id="add_menu_group">
    
    	<tr>
        	<td>Menu</td>
            <td>
            	<select name="menu" id="menu" class="select_box_medium">
                <?php foreach($main_menu as $menus): ?>
                <?php if($menus->admin_menu_id == $menu->menu_id): $selected = 'selected="selected"'; else :$selected = ''; endif; ?>
                <option value="<?php echo $menus->admin_menu_id; ?>" <?php echo $selected; ?>><?php echo $menus->menu_name; ?></option>
                <?php endforeach; ?>
                </select>
            </td>
            <td>&nbsp;</td>
        </tr>
    
		<tr>
            <td width="24%">Menu Group <span class="form_error">*</span></td>
          <td width="29%"><input type="text" name="menu_group" id="menu_group" class="text_box_medium" value="<?php echo $menu->submenu_group_name; ?>" /></td>
          <td width="47%">&nbsp;</td>
      </tr>
        
         <tr>
        	<td>Module</td>
            <td>
            	<select name="module" id="module" class="select_box_medium">
                <?php foreach($modules as $module): ?>
                <?php if($module->module_id == $menu->module_id): $selected2 = 'selected="selected"'; else :$selected2 = ''; endif; ?>
                <option value="<?php echo $module->module_id; ?>" <?php echo $selected2; ?>><?php echo $module->module_name; ?></option>
                <?php endforeach; ?>
                </select>
            </td>
            <td>&nbsp;</td>
        </tr>
              
        <tr>
        	<td>&nbsp;</td>
            <td><input type="submit" value="Update" name="save" class="button" /></td>
            <td>&nbsp;</td>
        </tr>
    </table>
    
    <?php echo form_close(); ?>

<?php endif; ?>

<!-- End Menu Group -->

<!-- Start Sub Menu -->

<?php if($level == 'submenu') : ?>

<h1>Update Sub Menu</h1>

<?php echo form_open('admin/menus/edit_submenus_process',array('id'=>'sub_menu_form')); ?>

<input type="hidden" name="hidden_menu_id" value="<?php echo $menu_id; ?>" />

	<table width="100%" cellpadding="5" cellspacing="0" border="0" id="add_menu">
    
    	<tr>
        	<td>Menu</td>
            <td>
            	<select name="menu" id="menu" class="text_box_medium">
                <option value=""></option>
                <?php foreach($main_menu as $menus): ?>
                	<?php if($menus->admin_menu_id == $menu->menu_id): $selected = 'selected="selected"'; else :$selected = ''; endif; ?>
                	<option value="<?php echo $menus->admin_menu_id; ?>" <?php echo $selected; ?>><?php echo $menus->menu_name; ?></option>
                <?php endforeach; ?>
                </select>
            </td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
        	<td>Menu Group</td>
            <td id="td_menu_group">
            	<select name="menu_group" id="menu_group" class="text_box_medium">
                	<option value=""></option>
	                <?php if($menu): ?>
                    <?php $groups = $this->main_model->select_as_object('admin_submenu_group',array('menu_id'=>$menu->menu_id),'submenu_group_id','ASC',FALSE); ?>
                    <?php foreach ($groups as $group): ?>
                    	<?php if($group->submenu_group_id == $menu->group_id): $selected1 = 'selected="selected"'; else :$selected1 = ''; endif; ?>
                    	<option value="<?php echo $group->submenu_group_id; ?>" <?php echo $selected1; ?>><?php echo $group->submenu_group_name; ?></option>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </td>
            <td>&nbsp;</td>
        </tr>
    
		<tr>
            <td width="24%">Sub Menu <span class="form_error">*</span></td>
          <td width="29%"><input type="text" name="submenu" id="submenu" class="text_box_medium" value="<?php echo $menu->submenu_name; ?>" /></td>
          <td width="47%">&nbsp;</td>
      </tr>
        
        <tr>
            <td>Sub Menu Url <span class="form_error">*</span></td>
            <td><input type="text" name="submenu_url" id="submenu_url" class="text_box_medium" value="<?php echo $menu->submenu_url; ?>" /></td>
            <td>&nbsp;</td>
      	</tr>
        
        <tr>
        	<td>&nbsp;</td>
            <td><input type="submit" value="Update" name="save" class="button" /></td>
            <td>&nbsp;</td>
        </tr>
    </table>
    
    <?php echo form_close(); ?>

<?php endif; ?>

<!-- Start Sub Menu -->

</body>
</html>

<script language="javascript" src="<?php echo base_url(); ?>assets/modules/menus/admin/js/menus.js"></script>

<script language="javascript">
	$(document).ready(function(){
		
		$("#menu").change(function(){
			var menu_id = $(this).val();
			$.post("<?php echo $this->config->item('absolute_url'); ?>admin/menus/get_menu_group", { menu_id: menu_id },function(data) {
				$("#td_menu_group").html(data);
	   		});
		});
		
	});
</script>