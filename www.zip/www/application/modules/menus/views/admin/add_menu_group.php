<!-- content_holder starts -->
<div id="content_holder">

<h1>Add Menu Group</h1>

	<!-- box_left starts -->
	<div id="box_left_big">

	<?php echo notice_message('Create Menu before creating sub menu.')?>
    
	<?php echo $this->session->flashdata('message'); ?>
    
    <?php echo form_open('admin/menus/menu_group_process',array('id'=>'menu_group_form')); ?>

	<table width="100%" cellpadding="5" cellspacing="0" border="0" id="add_menu_group" class="grid">
    
    	<tr>
        	<td width="63%"><strong>Menu</strong></td>
            <td width="37%">&nbsp;</td>
      </tr>
        <tr>
            <td>
            	<select name="menu" id="menu" class="input select">
                <?php foreach($main_menu as $menu): ?>
                <option value="<?php echo $menu->admin_menu_id; ?>"><?php echo $menu->menu_name; ?></option>
                <?php endforeach; ?>
                <option value="0">Settings</option>
                </select>
            </td>
            <td>&nbsp;</td>
        </tr>
    
		<tr>
            <td><strong>Menu Group <span class="form_error">*</span></strong></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td><input type="text" name="menu_group" id="menu_group" class="input textbox" /></td>
            <td>&nbsp;</td>
   	    </tr>
        
        <tr>
        	<td><strong>Module</strong></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>
            	<select name="module" id="module" class="input select">
                <?php foreach($modules as $module): ?>
                <option value="<?php echo $module->module_id; ?>"><?php echo $module->module_name; ?></option>
                <?php endforeach; ?>
                </select>
            </td>
            <td>&nbsp;</td>
        </tr>
              
        <tr>
            <td><input type="submit" value="Save" name="save" class="button" /> <?php echo anchor('admin/menus','[ Back To List ]'); ?></td>
            <td>&nbsp;</td>
        </tr>
    </table>
    
    <?php echo form_close(); ?>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
    
</div>
<!-- content_holder ends -->
<script language="javascript" src="<?php echo base_url(); ?>assets/modules/menus/admin/js/menus.js"></script>