<!-- content_holder starts -->
<div id="content_holder">
<?php echo link_tag('assets/modules/menus/admin/css/menu.css')?>
<h1>Manage Menu</h1>

    <!-- box_left starts -->
    <div id="box_left_big">
    
    <?php echo $this->session->flashdata('message'); ?>

    <?php if($menus) : ?>
    	<!-- Start Main Menu -->
    	<ul id="ul_menu">
        	<?php foreach ($menus as $menu): ?>
            
            <li id="li_menu">
				<?php echo $menu->menu_name; ?>
                <div id="menu_edit">
					<?php echo anchor('admin/menus/edit_menu/menu/'.$menu->admin_menu_id,'Edit',array('class'=>'edit_menu small-button')); ?>
                    <?php
                        $count_group = count($this->main_model->select_as_object('admin_submenu_group',array('menu_id'=>$menu->admin_menu_id,'submenu_group_status'=>1),'','',FALSE));
                        if($count_group!=0)
                        {
                            $group_delete_button = '<a href="javascript:void(0)" class="small-button grey_text">Delete</a>';
                        }
                        else
                        {
                            $group_delete_button = anchor('admin/menus/delete_menu/menu/'.$menu->admin_menu_id, 'Delete', array('class'=>'small-button confirm_link', 'title' =>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
                        }
                        echo $group_delete_button;
                    ?>
                </div>
            </li>
            
            	<!-- Start Menu group -->
            	<?php $menu_group = $this->main_model->select_as_object('admin_submenu_group',array('menu_id'=>$menu->admin_menu_id,'submenu_group_status'=>1),'submenu_group_id','ASC',FALSE); ?>
                
            	<?php if($menu_group): ?>
                
                <ul id="ul_group">
                	<?php foreach ($menu_group as $group): ?>
                    <li id="li_group">
						<?php echo $group->submenu_group_name; ?>
                        <div id="menu_edit">
							<?php echo anchor('admin/menus/edit_menu/group/'.$group->submenu_group_id,'Edit',array('class'=>'edit_menu small-button')); ?>	
                    		<?php
								$count_submenu = count($this->main_model->select_as_object('admin_submenus',array('menu_id'=>$menu->admin_menu_id,'group_id'=>$group->submenu_group_id,'submenu_status'=>1),'','',FALSE));
								if($count_submenu!=0)
								{
									$submenu_delete_button = '<a href="javascript:void(0)" class="small-button grey_text">Delete</a>';
								}
								else
								{
									$submenu_delete_button = anchor('admin/menus/delete_menu/group/'.$group->submenu_group_id, 'Delete', array('class'=>'small-button confirm_link', 'title' =>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
								}
								echo $submenu_delete_button;
							?>        
                         </div>
                    </li>
                    
                    	<!-- Start sub menu -->
                        <?php $submenus = $this->main_model->select_as_object('admin_submenus',array('menu_id'=>$menu->admin_menu_id,'group_id'=>$group->submenu_group_id,'submenu_status'=>1),'submenu_id','ASC',FALSE); ?>
                        
                        <?php if($submenus): ?>
                        <ul id="ul_submenu">
                        	<?php foreach ($submenus as $submenu): ?>
                            <li id="li_submenu">
								<?php echo $submenu->submenu_name; ?>
                                <div id="menu_edit">
									<?php echo anchor('admin/menus/edit_menu/submenu/'.$submenu->submenu_id,'Edit',array('class'=>'edit_menu small-button')); ?>
                                    <?php echo anchor('admin/menus/delete_menu/submenu/'.$submenu->submenu_id, 'Delete', array('class'=>'small-button confirm_link', 'title' =>'These item will be permanently deleted and cannot be recovered. Are you sure?')); ?>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                        <!-- End sub menu -->
                    
                    <?php endforeach; ?>
                </ul>
                
                <?php endif; ?>
                <!-- End Menu group -->
            
            <?php endforeach; ?>
            
        </ul>
        <!-- End Main Menu -->
    <?php else : ?>
    	<p><em>No data`s found in this section.</em></p>
    <?php endif; ?>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->
<script language="javascript">
	$(document).ready(function(){		
		$(".edit_menu").fancybox({
			'width'				: 550,
			'height'			: 350,
			'autoScale'			: false,
			'transitionIn'		: 'none',
			'transitionOut'		: 'none',
			'type'				: 'iframe',
			onClosed			:	function() {
				 	window.location.href = '<?php echo $this->config->item('absolute_url'); ?>admin/menus';
			}
	   });
	});
</script>