<!-- content_holder starts -->
<div id="content_holder">

<h1>Add Menu</h1>

	<!-- box_left starts -->
	<div id="box_left_big">

	<?php echo $this->session->flashdata('message'); ?>
    
    <?php echo form_open('admin/menus/add_menus_process',array('id'=>'add_menu_form')); ?>

	<table width="100%" cellpadding="5" cellspacing="0" border="0" id="add_menu" class="grid">
    
		<tr>
            <td width="60%"><strong>Menu <span class="form_error">*</span></strong></td>
          <td width="40%">&nbsp;</td>
      </tr>
        <tr>
            <td><input type="text" name="menu_name" id="menu_name" class="input textbox" /></td>
            <td>&nbsp;</td>
      	</tr>
        
        <tr>
            <td><strong>Menu Url <span class="form_error">*</span></strong></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td><input type="text" name="menu_url" id="menu_url" class="input textbox" /></td>
            <td>&nbsp;</td>
      	</tr>
        
        <tr>
            <td>
            	<input type="submit" value="Save" name="save" class="button" />
                <?php echo anchor('admin/menus','[ Back To List ]'); ?>
            </td>
            <td>&nbsp;</td>
        </tr>
    </table>
    
    <?php echo form_close(); ?>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
    
</div>
<!-- content_holder ends -->
<script language="javascript" src="<?php echo base_url(); ?>assets/modules/menus/admin/js/menus.js"></script>