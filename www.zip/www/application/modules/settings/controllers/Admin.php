<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class Admin
 * Class to manage settings
 *
 * @author Abin V Paul
 **/
class Admin extends CI_Controller {

	/**
	 * path to view folder
	 *
	 * @var string
	 **/
	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'settings/admin/';
	
	public function __construct()
	{
		parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	}
	
	/**
	 * function index
	 *
	 * loads the administrator settings page
	 * 
	 **/
	public function index()
	{
		$this->load->view($this->common_view_path.'header');
		$data['settings_group'] = $this->main_model->select_as_object('admin_submenu_group',array('menu_id'=>0,'submenu_group_status'=>1),'submenu_group_id','ASC',FALSE);
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	
}
