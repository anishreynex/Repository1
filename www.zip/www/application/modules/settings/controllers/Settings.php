<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class Admin
 * Class to manage settings
 *
 * @author Arya
 **/
class Settings extends CI_Controller {

	/**
	 * path to view folder
	 *
	 * @var string
	 **/
	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'settings/site/';
	
	public function __construct()
	{
		parent::__construct();
		
		
	}
	
	/**
	 * function index
	 *
	 * loads the administrator settings page
	 * 
	 **/
	public function index()
	{
		
	}
	
	/*
	@ Arya
	@ date - june 8 2016
	*/
	
	public function change_password()
	{
		if(!$this->ion_auth->logged_in())
		{
			redirect('');	
		}
		
		$data = array();
		$data['url_now'] = 'change_password';
		$this->load->view($this->common_view_path.'header',$data);
		$this->load->view($this->module_view_path.'change_password',$data);
		$this->load->view($this->common_view_path.'footer',$data);
	}
	
	public function change_password_process()
	{		
	    if(isset($_POST['password']))
		{
	        $old = $this->input->post('old');
	        $new = $this->input->post('new_pwd');
	      
			$prof 	  = $this->ion_auth->user()->row();
	        $identity = $prof->username;
	      
	       // $change = $this->ion_auth->change_password($identity, $old, $new);
		   $change = $this->ion_auth_model->change_password($identity, $old, $new);
		
    		if ($change)
    		{
				$this->ion_auth->set_message_delimiters('<span>','</span>');
    			$this->session->set_flashdata('message',success_message($this->ion_auth->messages()));
				redirect('settings/change_password');
    		}
    		else
    		{
				$this->ion_auth->set_error_delimiters('<span>','</span>');
				$this->session->set_flashdata('message',error_message('<span for="txt_title" class="invalid">Unable to change</span>'));
				redirect('settings/change_password');	
    		}
		}

		
	    
	}
	
	
	/*
	@ Arya
	@ date - june 14 2016
	*/
	public function change_email()
	{
					if(isset($_POST['update']))
	{
		$prof       = $this->ion_auth->user()->row();
		$email      = $this->input->post('email_id');
		$count = count($this->main_model->select_as_object('users',array('id !='=>$prof->id,'email'=>$email),'','',FALSE));
		if($count==0)
		{
		 $data['email'] = $email;
	     $this->db->where('id',$prof->id);
		if($this->db->update('users',$data))
		{
			$this->session->set_flashdata('message',success_message('Settings updated successfully.'));
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Email id updation failed.'));
		}
				redirect('settings/change_password');
		}
		else
		{
			$this->session->set_flashdata('message','Email id already exist! Please try another.');
			redirect('settings/change_password');
		}
	}
	}
		public function forgetPassword()
	{
		$this->load->view($this->common_view_path.'header');
		$this->load->view($this->module_view_path.'forget_pwd');
		$this->load->view($this->common_view_path.'footer');
	}
	
	public function forgetpassword_process()
	{
		$data['emailid']	= $this->input->post('email');	
		//$username = $this->main_model->get_text('users', 'username', 'email', $this->input->post('email'));
		$forgotten = $this->ion_auth->forgotten_password($this->input->post('email'));
		if ($forgotten)
		{ 	$this->session->set_flashdata('login_message', success_message($this->ion_auth->messages())); 	}
		else
		{ 	$this->session->set_flashdata('login_message', error_message($this->ion_auth->errors())); }
		
		redirect('settings/forgetPassword');
	}
	
	public function reset_password($code)
	{
		$reset = $this->ion_auth->forgotten_password_complete($code);	
		if ($reset) {  //if the reset worked then send them to the login page
			//$this->session->set_flashdata('message', $this->ion_auth->messages());
			//redirect("/");
			$this->session->set_flashdata('login_message',success_message('Check your email for new password.'));
		}
		else { //if the reset didnt work then send them back to the forgot password page
			$this->session->set_flashdata('login_message', error_message($this->ion_auth->errors()));
			
		}
		redirect("settings/forgetPassword");
	}
	
	
}