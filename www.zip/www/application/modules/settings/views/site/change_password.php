<section id="contentwrap">
  <div id="AllcontWrap">
  <div class="container">
  <!--row start-->



<div class="pageHeadRow">
    <div class="pagetble-cell">
      <h3 class="page-subHead">Settings</h3>
    </div>
    <div class="pagetble-cell text-right">
      <ol class="breadcrumb">
        <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
        <li class="active"> Settings</li>
      </ol>
    </div>
</div>



<!-- content Wrapper -->
<div class="content animate-panel">
<div class="row">
<div class="col-lg-12  m-t-md">




<!-- Dashboard head -->

<div class="row margin_bottom_25px padding_area">
<div class="col-md-12 recently_played">
<!--<h3 class="resently_played_head">played games</h3>-->

<div class="row">

<?php echo form_open('settings/change_password_process',array('id'=>'change_password_form'))?>

        <div class="col-md-5 col-md-offset-3 ak_change_pass_wrapper">
        <div class="ak_change_password_sec">
        <div class="ak_change_password_head"></div>
        <?php if(!empty($upload_error_message)) echo '<span class="form_error">'. $upload_error_message.'</span>'; ?>
        <?php echo $this->session->flashdata('message'); ?>
        <div class="ak_pass_wrapper">
        <div class="ak_change_password_input_margin">
        <label>Old Password</label>
        <div class="input-group ak_change_password_input">
        <span class="input-group-addon"><i class="fa fa-unlock" aria-hidden="true"></i></span>
        <input class="form-control" name="old" type="password"  id="old">
        
        </div>
        
        <div class="ak_escli"></div><p></p>
        </div>
        
        <div class="ak_change_password_input_margin">
        <label>New Password</label>
        <div class="input-group ak_change_password_input">
        <span class="input-group-addon"><i class="fa fa-unlock-alt" aria-hidden="true"></i></span>
        <input class="form-control" name="new_pwd" type="password"  id="new_pwd">
        </div>
         <div class="ak_escli"></div>
        </div>
        
        
        <div class="ak_change_password_input_margin">
         <label>Confirm Password</label>
        <div class="input-group ak_change_password_input">
        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
        <input class="form-control" name="new_repeat" type="password"  id="new_repeat">
        </div>
         <div class="ak_escli"></div>
        </div>
        
        <div class=" ak_change_pass_btn"><br />
        <button name="password" type="submit" class="btn btn-success">Change Password</button>
        </div>
        <?php echo form_close();?>
        <?php
			echo form_open('settings/change_email',array('id'=>'update_email_form')); 
			$prof = $this->ion_auth->user()->row();
		?>
       
               <div class="ak_change_password_input_margin">
         <label>Email Id </label>
        <div class="input-group ak_change_password_input">
        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
        <input type="text" class="form-control" name="email_id" type="password"  id="email_id" value="<?php echo $prof->email?>">
        </div>
         <div class="ak_esclii"></div>
        </div>
        <div class=" ak_change_pass_btn"><br />
        <button name="update" type="submit" value="Update Email"class="btn btn-success">Update Email</button>
        </div>
        </div>
        </div>
        </div>
         <?php echo form_close('')?>
     
               
</div>
     
</div>
</div>
</div>


</div>
</div>


</div>
</div>
</div>

</section>
<!-- content End -->\
