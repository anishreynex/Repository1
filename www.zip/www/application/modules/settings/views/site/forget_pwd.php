

<!-- Begin Jumbotron -->
	<div id="home" class="jumbotron jumbotron-register">
		<div id="particles-js"></div><!-- /.particles div -->
		<div class="container center-vertically-holder">

			<div class="center-vertically">
				

				<div class="col-sm-6 col-lg-5 col-lg-offset-4 col-xs-12 col-sm-offset-3 mt40-xs ak_at_media_log_form">
                 <form role="form" id="register_form" class="register-form mb40-xs" method="post" action="<?php echo base_url('settings/forgetpassword_process');?>" target="_parent">
                  
				
                        <h3 class="no-margin-top mb20"> Enter Your Email Here</h3>
                      <?php echo $this->session->flashdata('login_message')?>
                        <div class="form-group">
                            <input type="email" placeholder="Enter Your Email Here" class="form-control" id="email" name="email" required email >
                        </div>
                        
                        <div class="form-group no-margin-bottom mt20">
                            <button type="submit" class="btn-primary-login">Submit</button> 
                            
                        </div>
                    </form>
				</div><!-- /.column -->
			</div><!-- /.vertical center -->
		</div><!-- /.container -->
	</div>
	<!-- End Jumbotron -->

    <script type="text/javascript" src="<?php echo base_url();?>assets/themes/site/js/particles.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/themes/site/js/particlesRun.js"></script>



