    <!-- content_holder starts -->
	<div id="content_holder">
    <h1>Control Panel Settings</h1>
    
    <?php if($settings_group): ?>
    	
        <table width="100%" border="0" cellspacing="0" cellpadding="0" id="settings_table">
            <!-- Start Main MEnu -->
        	<tr>
        		<?php $i = 0; foreach ($settings_group as $group): ?>
            		<td align="left" valign="top">
                    	<div class="header"><strong><?php echo $group->submenu_group_name; ?></strong></div>
                        
                        <!-- Start Sub menu -->
						<?php
                        $submenus = $this->main_model->select_as_object('admin_submenus',array('menu_id'=>$group->menu_id,'group_id'=>$group->submenu_group_id,'submenu_status'=>1),'submenu_id','ASC',FALSE);
                        ?>
                        
                        <div>
                            <ul>
                            	<?php foreach($submenus as $menu): ?>
                                <li><?php echo anchor($menu->submenu_url,$menu->submenu_name); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                            
						<!-- End Sub Menu -->
                        
                        
                        
                    </td>
            	<?php if($i==2) { echo '</tr><tr>'; $i=0; } else { $i++; } ?>
            	<?php endforeach; ?>
        	</tr>
            <!-- End Main MEnu -->
            
        </table>
        
    <?php else : ?>
    	<p><em>No data`s found in this section.</em></p>
    <?php endif; ?>
    
    <!--<table width="100%" border="0" cellspacing="0" cellpadding="5" id="settings_table">
      <tr>
        <td align="left" valign="top" class="header"><strong>CPanel Setting</strong></td>
        <td align="left" valign="top" class="header"><strong>Modules</strong></td>
        <td align="left" valign="top" class="header"><strong>Assets</strong></td>
      </tr>
      <tr>
        <td align="left" valign="top"><ul>
          <li><a href="#">Update Logo</a></li>
        </ul></td>
        <td align="left" valign="top"><ul>
          <li><?=anchor('admin/modules/install_modules', 'Install new Module')?></li>
          <li><?=anchor('admin/modules/installed_modules', 'View Installed Modules')?></li>
        </ul></td>
        <td align="left" valign="top"><ul>
          <li><a href="#">Global</a></li>
          <li><a href="#">Plugins</a></li>
        </ul></td>
      </tr>
      <tr>
        <td align="left" valign="top" class="header"><strong>Site Promotion</strong></td>
        <td align="left" valign="top" class="header"><strong>Emails</strong></td>
        <td align="left" valign="top" class="header"><strong>News Letters</strong></td>
      </tr>
      <tr>
        <td align="left" valign="top"><ul>
          <li><a href="#">On Oage Promotion</a></li>
          <li><a href="#">Off Oage Promotion</a></li>
        </ul></td>
        <td align="left" valign="top"><ul>
          <li><a href="#">Create Email Templates</a></li>
          <li><a href="#">View Email Templates</a></li>
        </ul></td>
        <td align="left" valign="top"><ul>
          <li><a href="#">Create News Letter</a></li>
          <li><a href="#">Config</a></li>
        </ul></td>
      </tr>
      <tr>
        <td align="left" valign="top" class="header"><strong>Menus</strong></td>
        <td align="left" valign="top" class="header"><strong>&nbsp;</strong></td>
        <td align="left" valign="top" class="header"><strong>&nbsp;</strong></td>
      </tr>
      <tr>
        <td align="left" valign="top"><ul>
          <li><?php echo anchor('admin/menus','View Menu'); ?></li>
          <li><?php echo anchor('admin/menus/add_menu','Add Menu'); ?></li>
          <li><?php echo anchor('admin/menus/add_menu_group','Add Menu Group'); ?></li>          
          <li><?php echo anchor('admin/menus/add_sub_menu','Add Sub Menu'); ?></li>
        </ul></td>
        <td align="left" valign="top">&nbsp;</td>
        <td align="left" valign="top">&nbsp;</td>
      </tr>
    </table>-->

    
    </div>
	<!-- content_holder ends -->