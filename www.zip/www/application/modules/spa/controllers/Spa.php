<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class About Us
* Class to manage Spa
*
**/
class Spa extends MX_Controller {
	
    protected $common_view_path	= 'templates/site/';
	protected $module_view_path	= 'spa/site/';

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function index
	 *
	 *
	 **/
	 public function index()
	 {
	 	
	 	$this->load->view($this->common_view_path.'inner_header');
		$this->load->view($this->module_view_path.'index');
		$this->load->view($this->common_view_path.'inner_footer');
	 }
	 
	}
