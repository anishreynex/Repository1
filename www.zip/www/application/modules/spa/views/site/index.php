   <section class="seven-hills-about">
   <div class="seven-background"></div>
	<div class="container">
    <div class="row seven-row">
    <div class="col-md-12">
    <div class="seven-white">
    <h4 class="title-dist"><span class="span-padd"><img src="<?php echo base_url();?>assets/themes/site/images/side-inner-logo.png"></span>SPA</h4>
    
    <div class="row">
    <div class="col-md-12">
    
	<div class="white-inner">
    
    
    <div class="content-wrap-contact">
   
   <div class="contact-content">
   
   
   <div class="row">
   
   <div>
  <img src="<?php echo base_url();?>assets/themes/site/images/spa27.jpg" class="img-responsive">
   </div>
   
   </div>
      
   </div>
   </div>

    </div>

    </div>
    
    </div>
  
    </div>
    </div>
    </div>
    </div>
   </section>