<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class email_model
* Model Class to manage Administrator option of email
*
**/
class Email_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 
	 /**
	 * function send_appointment_email
	 **/
	 public function send_appointment_email($data)
	 {
		$name		= $data['appointment_name'];
		$email		= $data['appointment_email'];
		
		$msg = $this->load->view('email/site/appointment_email',$data,true);
		
		$config['protocol'] = 'sendmail';
		$config['mailpath'] = '/usr/sbin/sendmail';
		$config['charset'] 	= 'iso-8859-1';
		$config['wordwrap'] = TRUE;
		$config['mailtype'] = 'html';
		
		$this->email->initialize($config);
		
		$this->email->from($email, $name);
		$this->email->to($this->get_admin_email());
		
		$this->email->subject('Online Appointment Details');
		$this->email->message($msg);
		
		if($this->email->send())
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
	 
	 public function activation_appointment_email($name,$email,$status)
	 {
	 	$data['name'] 	= $name;
		$data['status'] = $status;
	 	$msg = $this->load->view('email/admin/activation_appointment_email',$data,true);
		
		if($status == 'y')
		{	$subject = 'Appointment Approved.';	}
		else
		{	$subject = 'Appointment Rejected.';	}
		
		$config['protocol'] = 'sendmail';
		$config['mailpath'] = '/usr/sbin/sendmail';
		$config['charset'] 	= 'iso-8859-1';
		$config['wordwrap'] = TRUE;
		$config['mailtype'] = 'html';
		
		$this->email->initialize($config);
		
		$this->email->from($this->get_admin_email(),'Administrator');
		$this->email->to($email);
		
		$this->email->subject($subject);
		$this->email->message($msg);
		
		if($this->email->send())
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
	 
	 public function get_admin_email()
	 {
	 	$admin_email = $this->main_model->select_as_object('users',array('id'=>1),'','',TRUE);
		return $admin_email->email;
	 }
	 
	 public function send_reservation_email($data)
	 {
		$name		= $data['reservation_first_name'];
		$email		= $data['reservation_email'];
		
		$msg = $this->load->view('email/site/reservation_email',$data,true);
		
		$config['protocol'] = 'sendmail';
		$config['mailpath'] = '/usr/sbin/sendmail';
		$config['charset'] 	= 'iso-8859-1';
		$config['wordwrap'] = TRUE;
		$config['mailtype'] = 'html';
		
		$this->email->initialize($config);
		
		$this->email->from($email, $name);
		$this->email->to($this->get_admin_email());
		
		$this->email->subject('Online Reservation Details');
		$this->email->message($msg);
		
		if($this->email->send())
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
	 
	 public function activation_reservation_email($name,$email,$status)
	 {
	 	$data['name'] 	= $name;
		$data['status'] = $status;
	 	$msg = $this->load->view('email/admin/reservation_activation_email',$data,true);
		
		if($status == 'y')
		{	$subject = 'Reservation Approved.';	}
		else
		{	$subject = 'Reservation Rejected.';	}
		
		$config['protocol'] = 'sendmail';
		$config['mailpath'] = '/usr/sbin/sendmail';
		$config['charset'] 	= 'iso-8859-1';
		$config['wordwrap'] = TRUE;
		$config['mailtype'] = 'html';
		
		$this->email->initialize($config);
		
		$this->email->from($this->get_admin_email(),'Administrator');
		$this->email->to($email);
		
		$this->email->subject($subject);
		$this->email->message($msg);
		
		if($this->email->send())
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
	 
	 /**
	  * function edit_template_process
	  * process the administrator create template action
	 **/
	 public function email_template_process()
	 {
	 	$data['template_name'] 			= $this->input->post('template_name');
		$data['template_content'] 		= $this->input->post('template_content');
		$data['template_modified_on'] 	= time();
		
		if($this->db->insert('email_template',$data))
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
	 
	 /**
	  * function edit_template_process
	  * process the administrator edit template action
	 **/
	 public function edit_template_process()
	 {
	 	$data['template_name'] 			= $this->input->post('template_name');
		$data['template_content'] 		= $this->input->post('template_content');
		$data['template_modified_on'] 	= time();
		
		$this->db->where('template_id',$this->input->post('hidden_id'));
		if($this->db->update('email_template',$data))
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
	 
	 function delete_template_process($template_id)
	 {
	 	$this->db->where('template_id',$template_id);
		if($this->db->delete('email_template'))
		{
			return true;
		}
		else
		{
			return false;
		}
	 }
}
