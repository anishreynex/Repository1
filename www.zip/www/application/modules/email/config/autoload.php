<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$autoload['model'] = array('email_model');


/* End of file autoload.php */
/* Location: ./application/modules/config/autoload.php */