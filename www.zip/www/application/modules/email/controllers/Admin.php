<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class Admin
* Class to manage Administrator option of email
*
**/
class Admin extends CI_Controller {

	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'email/admin/';

	 public function __construct()
	 {
	 	parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	 }
	 /**
	 * function index
	 * loads the administrator view email template page.
	 **/
	 public function index()
	 {
	 	$this->load->view($this->common_view_path.'header');
		$data['templates']	 = $this->main_model->select_as_object('email_template','','template_id','DESC',FALSE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function email_template
	  * loads the administrator create email template form.
	 **/
	 public function email_template()
	 {
	 	$this->load->view($this->common_view_path.'header');
		$data['edit']		 = '';
		$data['redirect']	 = '';
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
		$this->load->view($this->module_view_path.'add_email_template',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function email_template_process
	  * process the administrator create email template form.
	 **/
	 public function email_template_process()
	 {
	 	if($this->email_model->email_template_process())
		{	$this->session->set_flashdata('message',success_message('Email template inserted successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Email template insertion failed.'));	}
		redirect('admin/email/email_template');
	 }
	 
	 /**
	  * function edit_template
	  * load the administrator edit template form
	 **/
	 public function edit_template($template_id,$redirect='')
	 {
	 	if($template_id)
		{
			$this->load->view($this->common_view_path.'header');
			$data['edit']		 = $this->main_model->select_as_object('email_template',array('template_id'=>$template_id),'','',TRUE);
			$data['redirect']	 = $redirect;
			$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);		
			$this->load->view($this->module_view_path.'add_email_template',$data);
			$this->load->view($this->common_view_path.'footer');
		}
		else
		{
			$this->sesion->set_flashdata('message',error_message('Error occured! try again.'));
			if($redirect)
			{	redirect(str_replace('-','/',uri_string()));	}
			else
			{	redirect('admin/email');	}
		}
	 }
	 
	 /**
	  * function edit_template_process
	  * process the administrator edit template action
	 **/
	 public function edit_template_process($redirect='')
	 {
	 	if($this->email_model->edit_template_process())
		{	$this->session->set_flashdata('message',success_message('Email template updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Email template updation failed.'));	}
		
		if($redirect)
		{	redirect(str_replace('-','/',$redirect));	}
		else
		{	redirect('admin/email');	}
	 }
	 
	 /**
	  * function delete_template
	  * process the administrator delete template action
	 **/
	 public function delete_template($template_id)
	 {
	 	if($template_id)
		{
			if($this->email_model->delete_template_process($template_id))
			{	$this->session->set_flashdata('message',success_message('Email template deleted successfully.'));	}
			else
			{	$this->session->set_flashdata('message',error_message('Email template deletion failed.'));	}
			
			redirect('admin/email');
		}
		else
		{
			$this->sesion->set_flashdata('message',error_message('Error occured! try again.'));
			redirect('admin/email');
		}
	 }
}
