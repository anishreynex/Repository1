<html>
<body>
	<?php 
		$absolute_url   = $this->config->item('absolute_url'); 
		$user 			= $this->main_model->select_as_object('users',array('email'=>$identity),'','',TRUE); 
	?>
	<!--<h1>New Password for <?php echo $identity;?></h1>-->
	
	<p>
    	Hi <?=$user->first_name.' '.$user->last_name?> <br /><br />
    	Your password has been reset to: <?php echo $new_password;?> <br />
        Please <?php echo anchor($absolute_url, 'Click Here');?> to login.  <br /><br />        
    </p>
    <br /><br />
    
    Thanks, <br /><br />
    
    Irish Charity American Fund Team.
</body>
</html>