<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Appointment Details</title>
</head>

<body>
	<table border="0" width="100%" cellpadding="5" cellspacing="0">
    	<tr>
        	<td colspan="2">Dear Administrator</td>
        </tr>
                
        <tr>
        	<td colspan="2">An appointment has been received for <?php echo $appointment_date_time; ?>. The details is as follows </td>
        </tr>
        
        <tr>
        	<td colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
        	<td width="24%">Name :</td>
          <td width="76%"><?php echo $appointment_name; ?></td>
      </tr>
        
        <tr>
        	<td valign="top">Address :</td>
            <td>
				<?php
                	echo $appointment_address1;
					if($appointment_address2!='') { echo '<br />'.$appointment_address2; }
					if($appointment_address3!='') { echo '<br />'.$appointment_address3; }
				?>
            </td>
        </tr>
        
        <tr>
        	<td>Phone :</td>
            <td><?php echo $appointment_phone; ?></td>
        </tr>
        
        <?php if($appointment_fax!='') { ?>
        <tr>
        	<td>Fax :</td>
            <td><?php echo $appointment_fax; ?></td>
        </tr>
        <?php } ?>
       
       	<tr>
        	<td>Country :</td>
        	<td> 
        		<?php
					$country = $this->main_model->select_as_object('countries',array('CountryId'=>$appointment_country),'','',TRUE); 
					echo $country->CountryId;
				?>
        	</td>
		</tr>
        
        <tr>
        	<td>Appointment On :</td>
            <td><?php echo $appointment_date_time; ?></td>
        </tr>
        
        <tr>
        	<td colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
        	<td colspan="2"><?php echo $appointment_message; ?></td>
        </tr>
        
        <tr>
        	<td colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
        	<td colspan="2">Thank You<br /><?=$this->config->item('site_team')?></td>
        </tr>
        
    </table>
</body>
</html>
