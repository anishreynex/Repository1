<html>
<body>
	<?php
		$absolute_url   = $this->config->item('absolute_url'); 
		$user 			= $this->main_model->select_as_object('users',array('email'=>$identity),'','',TRUE);
	?>
    
    <p>
    	Hi <?=$user->first_name.' '.$user->last_name?>
        <br /><br />
    	We have received a password reset request for your account. <br />Follow the instructions below for making the changes come into effect.
        <br /><br />
		<!--<pReset Password for <?php echo $identity;?></p>-->
		Please click this link to <?php echo anchor($absolute_url.'auth/user/reset_password/'. $forgotten_password_code, 'Reset Your Password');?>.
        <br /><br />
        
    	Note : After Resetting we will send your another email having the New Password.
    </p>
    <br /><br />
    
    Thanks, <br /><br />
    
    Irish Charity American Fund Team.
</body>
</html>