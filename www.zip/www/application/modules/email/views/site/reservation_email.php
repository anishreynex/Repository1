<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Reservation Details</title>
</head>

<body>
	<table border="0" width="100%" cellpadding="5" cellspacing="0" class="grid">
    	<tr>
        	<td colspan="2">Dear Administrator</td>
        </tr>
                
        <tr>
        	<td colspan="2"><p><?php echo $reservation_first_name; ?> have reserved rooms on <?=$reservation_arrival_date?>. The details is as follows :</p></td>
        </tr>
        
        <tr>
        	<td colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
        	<td colspan="2">Reservation Details</td>
        </tr>
        
        <tr>
        	<td width="35%">Category :</td>
      <td width="65%">
				<?php $category = $this->main_model->select_as_object('reservation_category',array('reservation_category_id'=>$reservation_category),'','',TRUE); ?>
                <?php echo $category->reservation_category_name; ?>            </td>
      </tr>
        
        <tr>
        	<td width="35%">Type Of Room :</td>
      <td width="65%">
				<?php $type = $this->main_model->select_as_object('room_type',array('room_type_id'=>$reservation_room_type),'','',TRUE); ?>
                <?php echo $type->room_type_name; ?>            </td>
      </tr>
        
        <tr>
        	<td>No of Rooms :</td>
            <td><?=$reservation_room_nos?></td>
        </tr>
        
        <tr>
        	<td>Arrival Date & Time :</td>
            <td><?=$reservation_arrival_date.' '.$reservation_arrival_time?></td>
        </tr>
        
        <tr>
        	<td>Departure Date :</td>
            <td><?=$reservation_departure_date?></td>
        </tr>
        
        <tr>
        	<td>No. of Guests :</td>
            <td><?=$reservation_guest_no?></td>
        </tr>
        
        <?php if($reservation_airport_pickup==1): ?>
        
        <tr>
        	<td>Airport Pickup :</td>
            <td>Needed</td>
        </tr>
        
        <tr>
        	<td>Flight Details :</td>
            <td><?=$reservation_flight_details?></td>
        </tr>
        
        <?php endif; ?>
        
        <tr>
        	<td colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
        	<td colspan="2">General Information</td>
        </tr>
        
        <tr>
        	<td width="35%">Name :</td>
          <td width="65%"><?php echo $reservation_first_name.' '.$reservation_last_name; ?></td>
      </tr>
        
        <tr>
        	<td width="35%">Company :</td>
          <td width="65%"><?php echo $reservation_company; ?></td>
      </tr>
        
        <tr>
        	<td width="35%">Address :</td>
          <td width="65%"><?php echo $reservation_address; ?></td>
      </tr>
        
        <tr>
        	<td width="35%">Phone :</td>
          <td width="65%"><?php echo $reservation_phone; ?></td>
      </tr>
        
        <tr>
        	<td width="35%">Remarks :</td>
          <td width="65%"><?php echo $reservation_remarks; ?></td>
      	</tr>
      
      	<tr>
        	<td colspan="2">&nbsp;</td>
        </tr>
        
        <tr>
        	<td colspan="2">Thank You<br /><?=$this->config->item('site_team')?></td>
        </tr>
        
    </table>
</body>
</html>
