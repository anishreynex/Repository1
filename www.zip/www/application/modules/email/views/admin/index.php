<!-- content_holder starts -->
<div id="content_holder">
<h1>View Email Template</h1>

    <!-- box_left starts -->
    <div id="box_left_big">
    
    <?php echo $this->session->flashdata('message'); ?>
    
    <?php if($templates): ?>
    	<table cellpadding="5" cellspacing="0" border="0" width="100%" class="grid">
        	
            <thead>
            	<tr>
                	<td width="12%"><strong>Sl No</strong></td>
                    <td width="66%"><strong>Template Title</strong></td>
                    <td width="22%"><strong>Action</strong></td>
              </tr>
            </thead>
            
            <tbody>
            	<?php $slno = 1; foreach($templates as $template): ?>
            	<tr>
                	<td><?=$slno?></td>
                    <td><?=$template->template_name?></td>
                    <td>
                    	<?php
							echo anchor('admin/email/edit_template/'.$template->template_id.'/'.str_replace('/','-',uri_string()),'Edit',array('class'=>'small-button'));
							echo anchor('admin/email/delete_template/'.$template->template_id,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
						?>
                    </td>
                </tr>
                <?php $slno++; endforeach; ?>
            </tbody>
            
        </table>
    <?php else : ?>
    	<p><em>No data`s found in this section.</em></p>
    <?php endif; ?>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->