<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Reservation Details</title>
</head>

<body>
	<table border="0" width="100%" cellpadding="5" cellspacing="0">
    	<tr>
        	<td>Dear <?=$name?></td>
        </tr>
                
        <tr>
        	<td>
            	<?php if($status=='y'): ?>
                	Your reservation for <?=$this->config->item('appointment_group')?> has been approved.<br />
                    Please contact administrator for more details.
                <?php else : ?>
                	Your reservation for <?=$this->config->item('appointment_group')?> have been rejected.<br />
                    Please contact administrator for more details.
                <?php endif; ?>
            </td>
        </tr>
        
        <tr>
        	<td>Thank You <br /><?=$this->config->item('site_team')?></td>
        </tr>
        
    </table>
</body>
</html>
