<!-- content_holder starts -->
<div id="content_holder">
<?php if($edit){ $page_title = 'Update'; $button = 'Update'; } else { $page_title = 'Create'; $button = 'Save'; } ?>
<h1><?=$page_title?> Email Template</h1>

    <!-- box_left starts -->
    <div id="box_left_big">
    
    <?php echo $this->session->flashdata('message'); ?>
    
    <?php
	if($edit)
		echo form_open('admin/email/edit_template_process/'.$redirect,array('id'=>'email_template'));
	else
    	echo form_open('admin/email/email_template_process',array('id'=>'email_template'));
	?>

	<input type="hidden" name="hidden_id" value="<?php if($edit): echo $edit->template_id; endif; ?>" />
     <table width="100%" cellpadding="5" cellspacing="0" border="0" class="grid">
     	
        <tr>
        	<td colspan="4"><strong>Title <span class="form_error">*</span></strong></td>
       </tr>
        <tr>
          	<td width="66%"><input type="text" name="template_name" class="input textbox" value="<?php if($edit): echo $edit->template_name; endif; ?>" /></td>
          <td width="34%">&nbsp;</td>
       </tr>
        
        <tr>
        	<td colspan="4"><strong>Email Content</strong></td>
        </tr>
        <tr>
            <td colspan="4"><textarea name="template_content" id="template_content" class="ckeditor"><?php if($edit): echo $edit->template_content; endif; ?></textarea></td>
        </tr>
        
        <tr>
            <td colspan=""><input type="submit" name="submit" value="<?=$button?>" class="button" /> <?=anchor('admin/email','[Back To List]')?></td>
            <td>&nbsp;</td>
        </tr>
        
     </table>
     
     <?=form_close('')?>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->

<script language="javascript">
	$(document).ready(function(){
		$("#email_template").validate({
			rules : {
				template_name	: "required"	
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td").next("td"));
			},		
	
			messages: {
				template_name	: "The Title field is required"
			}					 
		});
	});
</script>