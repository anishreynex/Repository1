<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');


class Admin extends CI_Controller {

	/**
	 * path to view folder
	 *
	 * @var string
	 **/
	protected $common_view_path = 'templates/admin/';
	protected $module_view_path = 'contact_us/admin/';

	public function __construct() {
		parent::__construct();

		if (!$this -> ion_auth -> logged_in()) {
			redirect('admin/auth');
		}
	}
		public function add_details()
	{
		//echo "hi";
		
		$data['contact_detail']	 = $this->main_model->select_as_object('general_info','','','ASC',TRUE);
		$this->load->view($this->common_view_path.'header');
		$this->load->view($this->module_view_path.'contact_details',$data);
		$this->load->view($this->common_view_path.'footer');
		
		
	}
	public function edit_detail_process()
{
	   $id = $this->input->post('contact_id');
	    $data['title'] = $this->input->post('txt_title');
		$data['address'] = $this->input->post('txt_address');
		$data['phone'] = $this->input->post('txt_phn');
		$data['c_email']=$this->input->post('txt_cemail');
		$data['fax'] = $this->input->post('txt_fax');
		$data['name'] = $this->input->post('txt_name');
		$data['email'] = $this->input->post('txt_email');
		$data['c_phone'] = $this->input->post('txt_cphn');
		$data['p_name'] = $this->input->post('txt_pname');
		$data['p_email'] = $this->input->post('txt_pemail');
		$data['p_phone'] = $this->input->post('txt_pphn');
		$data['map'] = $this->input->post('txt_map');
		$data['twitter'] = $this->input->post('twitter');
		$data['facebook'] = $this->input->post('facebook');
		$data['googlepluse'] = $this->input->post('google_plus');
		$data['youtube'] = $this->input->post('youtube');
	
	
	 $this->db->where('contact_id',$id);
	if($this->db->update('general_info',$data))
	{
		
	 $this->session->set_flashdata('message',success_message("Contact Details updated successfully "));
	redirect('admin/contact_us/add_details');
	}
	 
	else {
   $this->session->set_flashdata('message',error_message('Contact Details updation failed'));
	redirect('admin/contact-us/add_details');
   }
	
}

}