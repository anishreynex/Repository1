<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

/**
 * class About Us
 * Class to manage About Us
 *
 **/
class Contact_us extends CI_Controller {

	protected $common_view_path = 'templates/site/';
	protected $module_view_path = 'contact_us/site/';

	public function __construct() {
		parent::__construct();
		$this -> load -> helper('captcha');
	}

	/**
	 * function index
	 *
	 *
	 **/
	public function index() {
		$this -> load -> helper('captcha');
		$data = array();
		$data['urlnow'] = 'contact';
		// For captcha
		//$this->load->helper('captcha');

		$vals = array('img_path' => './captcha/', 'img_url' => base_url() . 'captcha/', 'font_path' => './captcha/fonts/FREESCPT.TTF', 'font_size' =>20, 'img_width' => 190, 'img_height' => 48, 'expiration' => 7200, 'colors' => array('background' => array(255, 255, 255), 'border' => array(255, 255, 255), 'text' => array(0, 0, 0), 'grid' => array(255, 40, 40)));

		$cap = create_captcha($vals);

		$datas = array('captcha_time' => $cap['time'], 'ip_address' => $this -> input -> ip_address(), 'word' => $cap['word']);

		$query = $this -> db -> insert_string('captcha', $datas);
		$this -> db -> query($query);

		$data['captcha_image'] = $cap['image'];
		//End captcha

		$data['urlnow'] 	 =  'contact-us'; 
		$data['contact_detail']	 = $this->main_model->select_as_object('general_info','','','ASC',TRUE);
		$this -> load -> view($this -> common_view_path . 'inner_header');
		$this -> load -> view($this -> module_view_path . 'index', $data);
		$this -> load -> view($this -> common_view_path . 'inner_footer');
	}

	public function captcha_code() 
	{
		$this -> contact_us_model -> captcha_code();
	}

	public function contactus_process() 
	{
		
		$contact_name = $this -> input -> post('name');
		$contact_email = $this -> input -> post('email');
		$contact_phn = $this -> input -> post('phone');

		$content_message = $this -> input -> post('message');
		$absolute_url = $this -> config -> item('absolute_url');

		$template = ' <!doctype html>
						<html xmlns="http://www.w3.org/1999/xhtml">
						<head>
						<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
						<title>Sevenhills Mail</title>

					</head>
					<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" yahoo="fix" style="font-family: Arial, Helvetica, sans-serif">

				<!-- Wrapper -->
				<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
				<tr>
				<td width="100%" valign="top" bgcolor="#ffffff" style="padding-top:20px; padding-bottom:0px;">


			<!--Start Header-->
			<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="font-family:Arial,Helvetica,sans-serif;max-width:600px;border:1px solid #d7d7d7"> 
    
   			 <tbody>
    
     		 <tr> 
    		 <td align="center" valign="middle" colspan="4" style=" border-bottom:solid 6px #dddddd; border-top:1px solid #f0f0f0!important;font-family:Arial,Helvetica,sans-serif;color:#fff;padding:10px 0; font-weight:normal;text-align:left; padding-left:15px; margin:5px 0;font-size:12px;   background:#fff; " ><a target="_blank" href="#"><img border="0" align="middle"  src="' . $this -> config -> item('absolute_url') . 'assets/themes/site/images/inner-logo.png" ></a></td> 
   			 </tr> 
   			
			  <tr>
                                <td  class="center" style="font-size: 12px; color: #303030; font-weight: bold; text-align: left; font-family: Arial, Helvetica, sans-serif; line-height: 25px; vertical-align: middle; padding: 20px 10px 10px 10px; " >
                                Hi,                            
                                </td>
                            </tr>
                            <tr>
                                <td  class="center" style=" font-size: 12px; color: #687074; font-weight: bold; text-align: left; font-family: Arial, Helvetica, sans-serif; line-height: 25px; vertical-align: middle; padding:20px 10px 10px 10px; " colspan="2">
                                    You have received an message from ' . ucwords($contact_name) . '.<br />The message and details are pasted below:
                                </td>
                            </tr>
			  <tr>
								        <td style="padding:10px;font-size: 12px; ">Name:</td> <td style="font-size: 12px;">' . ucwords($contact_name) . '</td>
								       
								        
								      </tr>
		<tr>
								        <td style="padding:10px; font-size: 12px;"> Email Id:</td> <td style="font-size: 12px;"> ' . $contact_email . '</td>
								     
								        
								      </tr>							      
								      
  	        <tr>
								        <td style="padding:10px; font-size: 12px;">Phone Number:</td> <td style="font-size: 12px;"> ' . $contact_phn . '</td>
								     
								        
								      </tr>	  
								      
								                  
     <tr>
								        <td style="padding:10px; font-size: 12px; width:20%;  vertical-align: top;">Message:</td> <td style="font-size: 12px;"> ' . nl2br($content_message) . '</td>
								       
								        
								      </tr>	
     
     
      
    								 <tr> 
    								 <td style="padding:10px; font-size: 12px;" colspan="2"> 
   									  Thanking You,<br/> <br/> 
    								   ' . ucwords($contact_name) . '  
     
     									</td> 
  										  </tr> 
    
  									  <tr> 
  									   <td> 
     
 								    </td> 
 									   </tr> 
 								   <tr> 
 		    <td align="center" valign="middle" colspan="4" style="border-top:1px solid #f0f0f0!important;font-family:Arial,Helvetica,sans-serif;color:#fff;padding:10px 0;font-weight:bold;text-align:center;margin:5px 0;font-size:16px;background:#3287BA"> <p style="margin:0;color:#fff;line-height:24px; font-size:13px;">Copyright &copy; Seven Hills 2017.</p> </td> 
 		   </tr> 
    
 		 </tbody>
		  </table>
			<!--End Header-->

			</td>
			</tr>
		</table> 
		<!-- End Wrapper -->
		</body>
		</html>';
		if ($this -> external_mail_contact($contact_email, $template))
			$this -> session -> set_flashdata('message', 'Your mail has been sent successfully!');
		else
			$this -> session -> set_flashdata('message', error_message_web('Mail error!'));
		redirect('contact_us');

	}

	public function external_mail_contact($user_email_address = '', $templ = '') {
		require_once ("phpmailer/class.phpmailer.php");
		$users = $this -> main_model -> select_as_object('users', array('id' => '4'), '', '', TRUE);

		$mail = new PHPMailer(true);

		$mail -> AddAddress($users->email);

		$mail -> SetFrom($user_email_address);
		$mail -> Subject = 'Seven Hills Contact us mail';
		$mail -> AltBody = '';
		$mail -> MsgHTML($templ);
		$rs = $mail -> Send();
		if ($rs)
			return true;
		else
			return false;

	}

}
