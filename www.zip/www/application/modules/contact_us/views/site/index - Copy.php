 <section class="seven-hills-about">
   <div class="seven-background"></div>
	<div class="container">

    <div class="row seven-row">
    <div class="col-md-12">
    <div class="seven-white">
    <h4 class="title-dist"><span class="span-padd"><img src="<?php echo base_url();?>assets/themes/site/images/side-logo.png"></span>Contact Us</h4>
    
    <div class="row">
    <div class="col-md-12">
    
	<div class="white-inner">
    
    
    <div class="content-wrap-contact">
   
   <div class="contact-content">
   
   <?php echo form_open('contact_us/contactus_process',array('id'=>'contactsweb_form'))?>
   		<?php if($this->session->flashdata('message')) { ?>	
	
<div class="alert_sec">
<div class = "alert alert-success alert-dismissible">
   <button type = "button" class = "close" data-dismiss = "alert" aria-hidden = "true">
      &times;
   </button>
	
    <?php echo $this->session->flashdata('message')?>
</div>
</div>
<?php } ?>
   <div class="row">
   <div class="col-md-6">
   <h4>Send an E-mail</h4>
   <div class="contact-dist"> 
   <div class="form-group">
    <label for="exampleInputEmail1">Your Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Name" name="name" id="name" />
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Your Email</label>
    <input type="text" class="form-control"  placeholder="Email" name="email" id="email" />
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Your Phone</label>
    <input type="text" class="form-control"  placeholder="Phone" name="phone" id="phone" />
  </div>
  
  <div class="form-group">
    <label for="exampleInputPassword1">Your Message</label>
    <textarea class="form-control" rows="3" name="message" id="message"></textarea>
  </div>
  
   <div class="form-group">
<label>Image verification</label>
<input type="text" id="captcha" name="captcha" autocomplete="off" class="form-control rounded-right"  placeholder="Enter The Captcha Text" />
</div>
<div class="">
    <?php echo $captcha_image?>
</div>
<br>
  <button id="contactbutton" class="btn  btn-default-read" type="submit">Submit</button>
  
  
   </div>
   </div>
   
   <div class="col-md-6">
   <h4 class="contact-develop">Address</h4>
   <div class="contact-dist-develop"> 
   
   
   <ul class="mg-contact-info">
							<li><i class="fa fa-map-marker"></i><?php if($contact_detail){echo nl2br($contact_detail->address);}?><br>

</li>
							<li><i class="fa fa-phone"></i> <?php if($contact_detail) { echo $contact_detail->phone; } ?> (Sale),<?php if($contact_detail) { echo $contact_detail->c_phone; } ?></li>
							<li><i class="fa fa-envelope"></i> <a href="mailto:#"><?php if($contact_detail) { echo $contact_detail->c_email; } ?>,<?php if($contact_detail) { echo $contact_detail->p_email; } ?></a></li>
						</ul>
                        
	<div class="map_area">
<iframe src="<?php if($contact_detail) { echo $contact_detail->map; } ?>" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
   </div>
   </div>
   
   
   </div>
   
   
   
   </div>
   </div>

    </div>

    </div>
    
    </div>
  
    </div>
    </div>
    </div>
    </div>
   </section>
   
  <div class="clearfix"></div>
  

   <?php echo form_close(); ?> 
