 <section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
 <div class="pageHeadRow">
        <div class="pagetble-cell">
          <h3 data-toggle="tooltip"  title="Contact Details" class="page-subHead">
          	 Contact Details
        </h3>
        </div>
        <div class="pagetble-cell text-right">
          <ol class="breadcrumb">
            <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
           <li class="active">Contact Details</li>
          </ol>
        </div>
      </div>
<!-- content_holder starts -->
<div id="content_holder">


<?php if($contact_detail){ $button = 'Save'; } else { $button = 'Save'; } ?>
    <!-- box_left starts -->
    <div id="box_left_big1">
  
    <?php echo $this->session->flashdata('message');?>
   
    
   <?php
   if($contact_detail)
		{	echo form_open_multipart('admin/contact_us/edit_detail_process/',array('id'=>'edit_contact_detail'));	}
		else
    	{	echo  form_open_multipart('admin/generalinfo/add_detail_process',array('id'=>'add_contact_detail'));	}
		
	
 
	?>
<input type="hidden" name="contact_id" value="<?php if($contact_detail): echo $contact_detail->contact_id; endif; ?>"/> 
  
      <div class="form-group">
                <label for="exampleInputPassword1"><strong>Website Title</strong> <span class="form_error">*</span><br><small></small></label>
                <input type="text" class="form-control"  name="txt_title" maxlength="100" id="txt_title" 
                value="<?php if($contact_detail) { echo $contact_detail->title; } ?>">
              </div>
  <div class="form-group">
                <label for="exampleInputPassword1"><strong>Address</strong> <span class="form_error">*</span><br><small></small></label>
               <textarea name="txt_address" id="txt_address" rows="5" cols="133" class="form-control" /><?php if($contact_detail){echo $contact_detail->address;}?></textarea>
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1"><strong>Phone Number</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_phn" id="txt_phn" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->phone; } ?>"/>
              </div>
                <div class="form-group">
                <label for="exampleInputPassword1"><strong>Email</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_cemail" id="txt_cemail" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->c_email; } ?>"/>
              </div>
                <div class="form-group">
                <label for="exampleInputPassword1"><strong>Fax</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_fax" id="txt_fax" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->fax; } ?>"/>
              </div>
              <h3>Contact Person 1: </h3>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Name</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_name" id="txt_name" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->name; } ?>"/>
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Email</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_email" id="txt_email" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->email; } ?>"/>
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Phone</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_cphn" id="txt_cphn" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->c_phone; } ?>"/>
              </div>
              <h3>Contact Person 2: </h3>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Name</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_pname" id="txt_pname" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->p_name; } ?>"/>
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Email</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_pemail" id="txt_pemail" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->p_email; } ?>"/>
              </div>
                <div class="form-group">
                <label for="exampleInputPassword1"><strong>Phone</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_pphn" id="txt_pphn" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->p_phone; } ?>"/>
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Map</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="txt_map" id="txt_map" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->map; } ?>"/>
              </div>
              <h3>Social Links: </h3>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Twitter</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="twitter" id="twitter" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->twitter; } ?>"/>
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Facebook</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="facebook" id="facebook" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->facebook; } ?>"/>
              </div>
               <div class="form-group">
                <label for="exampleInputPassword1"><strong>Google Plus</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="google_plus" id="google_plus" class="form-control" value="<?php if($contact_detail) { echo $contact_detail->googlepluse; } ?>"/>
              </div>
              <div class="form-group">
                <label for="exampleInputPassword1"><strong>Youtube</strong> <span class="form_error">*</span><br><small></small></label>
               <input type="text" name="youtube" id="youtube" class="form-control"  value="<?php if($contact_detail) { echo $contact_detail->youtube; } ?>"/>
              </div>
              <input type="submit" name="projects_submit" id="projects_submit" value="<?php echo $button;?>" class="btn btn-default" />
            	<?php echo anchor('admin/dashboard','[ Back To List ]');?>

    
  
    
	</div>
	

</div>
</div>
</div>
</section>


<script type="text/javascript">
    $(document).ready(function(){
   
        /*$("#add_specification_form").validate({
            rules: {     
            txt_title		: "required",
            txt_descriptions		: 	"required"
										
									  	
           
			
            },
            messages: {     
            txt_title		    : "The Title field is required",
            txt_descriptions    : "The Description field is required"
			
            },
            errorElement:"span", 
            errorPlacement: function(error, element) {
           // error.appendTo( element.parent("td").next("td") );
            error.insertAfter(element).wrap('<td/>');
            }
        });*/
   
       $("#edit_add_detail").validate({
            rules: { 
            txt_title   :"required",	
            txt_address :"required",  
            txt_phn     :{required: true,pattern: /^[\d\s]+$/},  
            txt_cemail	: { required:true, email:true },
            txt_fax     :{required: true,pattern: /^[\d\s]+$/}
          
            },
            messages: { 
            txt_title   :"The title field is required", 
            txt_address :"The address field is required",
            txt_phn     :  { required:"The number field is required",  pattern: 'Please enter digits or space characters only'}, 
            txt_cemail	: { required:"The email field is required", email:"Please enter a valid email id" },
             txt_fax     :  { required:"The number field is required",  pattern: 'Please enter digits or space characters only'}
          
            },
            errorElement:"span",  
            errorPlacement: function(error, element) {
           // error.appendTo( element.parent("td").next("td") );
            error.insertAfter(element).wrap('<td/>');
            }
        });
		
    });	
</script>
  

