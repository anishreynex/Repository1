<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @ Author  		: Chaitra RS
 *
 * @ Created On  	: 09/26/2011
 * @ Modified On 	: 09/26/2011
 *
 * Class to manage the news section.
 *
**/
class Contact_us_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function any_function
	 *
	 *
	 **/
	function captcha_code()
	 {
	 	
		$expiration = time()-7200; 
		$this->db->query("DELETE FROM captcha WHERE captcha_time < ".$expiration);
        $sql = "SELECT COUNT(*) AS count FROM captcha WHERE word = ? AND ip_address = ? AND captcha_time > ?";
		$binds = array($_POST['captcha'], $this->input->ip_address(), $expiration);
		$query = $this->db->query($sql, $binds);
		$row = $query->row();
		
		if ($row->count == 0)
		{
			echo 'false';
		}
		else
		{
			echo 'true';
		}
	 }
}
