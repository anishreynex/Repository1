<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class auth_model
* Model Class to manage Administrator option of users
*
**/
class Auth_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 
	public function is_authorized_group()
	{
		$user_id = $this->ion_auth->user()->row()->id;
		$group	= $this->main_model->select_as_object('users_groups', array('user_id'=>$user_id), '', '', TRUE);
		if($group->group_id == 1 || $group->group_id == 3)
		return true;
		else
		return false;
	}
	 
}
