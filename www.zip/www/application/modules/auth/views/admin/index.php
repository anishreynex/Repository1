<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Super Admin Login Page</title>
<link href="<?=base_url()?>assets/modules/auth/admin/css/admin_login.css" rel="stylesheet" type="text/css" />
</head>

<body>
	<!-- wrapper starts here -->
    <div id="wrapper">
    <?php echo form_open('auth/admin/login_process')?>
    <table border="0" cellpadding="3" cellspacing="0">
      <tr>
        <td colspan="2" style="padding-bottom:10px;">
        <img src="<?=base_url()?>assets/modules/auth/admin/images/superadmin_controlpanel.gif" width="324" height="34" alt="Super Admin Control Panel" />
        </td>
      </tr>
      <tr>
        <td colspan="2">Username</td>
      </tr>
      <tr>
        <td colspan="2" style="padding-bottom:10px;"><input type="text" name="username" id="username" /></td>
      </tr>
      <tr>
        <td colspan="2">Password</td>
      </tr>
      <tr>
        <td colspan="2" style="padding-bottom:10px;"><input type="password" name="password" id="password" /></td>
      </tr>
      <tr>
        <td width="32"><input type="image" src="<?=base_url()?>assets/modules/auth/admin/images/superadmin_login.gif" /></td>
        
        <td width="290"><?php echo $this->session->flashdata('login_message')?></td>
      </tr>
    </table>
    <?php echo form_close()?>
    <!-- info -->
    <div id="info">Powered by Reynex Softwares</div>
    <!-- info ends -->
    
    </div>
    <!-- wrapper ends here -->
</body>
</html>