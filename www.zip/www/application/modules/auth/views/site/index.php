<div id="content_holder">
<h1>Login</h1>

	<?php
    	echo $this->session->flashdata('message');         
		echo form_open('auth/user/login_process',array('id'=>'login'));		
	?>
	<table cellpadding="5" cellspacing="0" border="0" width="100%">
        <tr>
        	<td width="22%">Username <span class="form_error">*</span></td>
          <td width="18%"><input type="text" name="username" id="username" /></td>
          <td width="60%">&nbsp;</td>
      </tr>
        <tr>
        	<td>Password <span class="form_error">*</span></td>
            <td><input type="password" name="password" id="password" /></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
        	<td>&nbsp;</td>
            <td><input type="submit" value="Login" class="button" /></td>
            <td>&nbsp;</td>
        </tr>
    </table>
    <?=form_close('')?>

</div>

<script language="javascript">
	$(document).ready(function(){ 
	
  		$("#login").validate({	
			rules : {
				username	:	"required",
				password	:	"required"
		},	
		errorPlacement: function(error, element) {
        error.appendTo( element.parent("td").next("td") );
		},		

		messages: {			
			username	:	"The Username field is required",
			password	:	"The Password field is required"
		}
	});

		
	});
</script>