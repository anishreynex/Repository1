<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$autoload['model'] 		= array('auth_model');