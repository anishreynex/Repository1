<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {

	public $view_base_path	= 'login/login/';
	
	protected $common_view_path	= 'templates/site/';
	protected $module_view_path	= 'auth/site/';
	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function index()
	{
		$this->load->view($this->common_view_path.'header');		
		$this->load->view($this->module_view_path.'index');
		$this->load->view($this->common_view_path.'footer');
	}
	
	public function admin()
	{
		$this->load->view($this->view_base_path.'admin');	
	}
	
	public function login_process()
	{
		if($this->ion_auth->login($this->input->post('username'), $this->input->post('password')))
		{	$this->session->set_flashdata('message',success_message('Login Successfully.'));	}
		else
		{
			$this->ion_auth->set_error_delimiters('','');
			$this->session->set_flashdata('message',error_message($this->ion_auth->errors()));	
		}
		redirect('login');
	}
	
	public function logout()
	{
		if($this->ion_auth->logout())
		{	$this->session->set_flashdata('message',success_message('Logout Successfully.'));	}
		else
		{
			$this->ion_auth->set_error_delimiters('','');
			$this->session->set_flashdata('message',error_message($this->ion_auth->errors()));	
		}
		redirect('login');
	}

}
