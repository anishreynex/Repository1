<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * path to view folder
	 *
	 * @var string
	 **/
	protected $module_view_path	= 'auth/admin/';
	
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}
	
	/**
	 * function index
	 *
	 * loads the administrator login page
	 *
	 **/
	public function index()
	{
		$this->load->view($this->module_view_path.'index');	
	}
	
	/**
	 * function login_process
	 * 
	 * authenticates user
	 * @authour Abin V Paul
	 **/
	function login_process()
	{
		$username	= $this->input->post('username');
		$password	= $this->input->post('password');
		
		if ($this->ion_auth->login($username, $password))
		{
		
			if($this->auth_model->is_authorized_group())
			{
				
				redirect('admin/dashboard');
			}
			else
			{
				redirect('auth/admin/logout/'.base64_encode('Unexpected login attempt!(Error:You are not an administrator)'));
			}
			
		}
		else
		{
			$this->ion_auth->set_error_delimiters('<span class="login_error">','</span>');
			$this->session->set_flashdata('login_message', $this->ion_auth->errors());
			redirect('admin/auth');
		}
		
	}
	
	/**
	 * function logout
	 * 
	 * logout user
	 * @authour Abin V Paul
	 **/
	
	function logout($message='')
	{
		$this->ion_auth->logout();
		$this->ion_auth->set_message_delimiters('<span class="logout_success">','</span>');
		if($message)
		//$this->session->set_flashdata('login_message', $this->ion_auth->messages());
		$this->session->set_flashdata('login_message', '<span class="login_error">'.base64_decode($message).'</span>');
		else
		$this->session->set_flashdata('login_message', $this->ion_auth->messages());
		redirect('admin/auth');
	}

	public function forgot_password()
	{ 
		// setting validation rules by checking whether identity is username or email
		if($this->config->item('identity', 'ion_auth') != 'email' )
		{
		   $this->form_validation->set_rules('identity', $this->lang->line('forgot_password_identity_label'), 'required');
		}
		else
		{
		   $this->form_validation->set_rules('identity', $this->lang->line('forgot_password_validation_email_label'), 'required|valid_email');
		}


		if ($this->form_validation->run() == false)
		{
			$this->data['type'] = $this->config->item('identity','ion_auth');
			// setup the input
			$this->data['identity'] = array('name' => 'identity',
				'id' => 'identity',
			);

			if ( $this->config->item('identity', 'ion_auth') != 'email' ){
				$this->data['identity_label'] = $this->lang->line('forgot_password_identity_label');
			}
			else
			{
				$this->data['identity_label'] = $this->lang->line('forgot_password_email_identity_label');
			}

			// set any errors and display the form
			$this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');
			$this->_render_page($this->module_view_path.'forgot_password', $this->data);
			
		}
		else
		{
			$identity_column = $this->config->item('identity','ion_auth');
			$identity = $this->ion_auth->where($identity_column, $this->input->post('identity'))->users()->row();

			if(empty($identity)) {

	            		if($this->config->item('identity', 'ion_auth') != 'email')
		            	{
		            		$this->ion_auth->set_error('forgot_password_identity_not_found');
		            	}
		            	else
		            	{
		            	   $this->ion_auth->set_error('forgot_password_email_not_found');
		            	}

		                $this->session->set_flashdata('message', $this->ion_auth->errors());
                		redirect("auth/admin/forgot_password", 'refresh');
            		}

			// run the forgotten password method to email an activation code to the user
			$forgotten = $this->ion_auth->forgotten_password($identity->{$this->config->item('identity', 'ion_auth')});

			if ($forgotten)
			{
				// if there were no errors
				$this->session->set_flashdata('message', $this->ion_auth->messages());
				redirect("auth/admin/forgot_password", 'refresh'); //we should display a confirmation page here instead of the login page
			}
			else
			{
				$this->session->set_flashdata('message', $this->ion_auth->errors());
				redirect("auth/admin/forgot_password", 'refresh');
			}
		}
	}
	
	public function _render_page($view, $data=null, $returnhtml=false)//I think this makes more sense
	{

		$this->viewdata = (empty($data)) ? $this->data: $data;

		$view_html = $this->load->view($view, $this->viewdata, $returnhtml);

		if ($returnhtml) return $view_html;//This will return html on 3rd argument being true
	}
}
