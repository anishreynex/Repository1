<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * class Admin
 * Class to display dashboard
 *
 * @author Abin V Paul
 **/
class Admin extends CI_Controller {

	/**
	 * path to view folder
	 *
	 * @var string
	 **/
	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'dashboard/admin/';
	
	
	
	public function __construct()
	{
		parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	}
	
	/**
	 * function index
	 *
	 * loads the administrator dashboard page
	 *
	 **/
	public function index()
	{
		$this->load->view($this->common_view_path.'header');
		$this->load->view($this->module_view_path.'index');
		$this->load->view($this->common_view_path.'footer');
	}

}
