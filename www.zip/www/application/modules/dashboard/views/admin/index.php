
<section id="contentwrap">
  <div id="AllcontWrap">
  <div class="container">
  <!--row start-->
  
    <div class="row box-list-wrap bdr-btm">
    <div class="col-md-3 box-wrap">
  <div class="boxInner"> <a href="<?php echo base_url('admin/facility/add_facility');?>" class="boxLink"   data-toggle="tooltip"  title="Edit Facility " >
            <div class="boxInnerCont"> <img src="<?php echo base_url('assets/themes/admin/');?>images/gallery.png" alt="Home Page">
              <h3> Facility </h3>
            </div>
            </a> </div>
      
      </div>
         

      
            

            
            
            
            
            <div class="col-md-3 box-wrap">
            
            <div class="boxInner"> <a href="<?php echo base_url('admin/rooms/view_room')?>" class="boxLink"   data-toggle="tooltip"  title="Edit Rooms" >
            <div class="boxInnerCont"> <img src="<?php echo base_url('assets/themes/admin/');?>images/gallery.png" alt="gallery">
              <h3> Rooms</h3>
            </div>
            </a> </div>
            </div>
            
             <div class="col-md-3 box-wrap">
            <div class="boxInner"> <a href="<?php echo base_url('admin/contact_us/add_details')?>" class="boxLink"   data-toggle="tooltip"  title="Edit Contact Details" >
            <div class="boxInnerCont"> <img src="<?php echo base_url('assets/themes/admin/');?>images/gallery.png" alt="gallery">
              <h3>Contact Details</h3>
            </div>
            </a> </div>
      
      </div>
    
      <div class="col-md-3 box-wrap">
            <div class="boxInner"> <a href="<?php echo base_url('admin/about/add_about')?>" class="boxLink"   data-toggle="tooltip"  title="Edit About Details" >
            <div class="boxInnerCont"> <img src="<?php echo base_url('assets/themes/admin/');?>images/gallery.png" alt="gallery">
              <h3>About Us</h3>
            </div>
            </a> </div>
            
      
      
    </div>
    </div>
    
     <!--row End-->
     
     
      <!--row start-->
    
    <div class="row box-list-wrap ">
     
      <div class="col-md-3 box-wrap">
            
            <div class="boxInner"> <a href="<?php echo base_url('admin/feedback/view_feedback')?>" class="boxLink"   data-toggle="tooltip"  title="Edit Feedback" >
            <div class="boxInnerCont"> <img src="<?php echo base_url('assets/themes/admin/');?>images/gallery.png" alt="gallery">
              <h3> Feedback</h3>
            </div>
            </a> </div>
            </div>
              <div class="col-md-3 box-wrap">
            
            <div class="boxInner"> <a href="<?php echo base_url('admin/services/view_services')?>" class="boxLink"   data-toggle="tooltip"  title="Edit Services" >
            <div class="boxInnerCont"> <img src="<?php echo base_url('assets/themes/admin/');?>images/gallery.png" alt="gallery">
              <h3> Services</h3>
            </div>
            </a> </div>
            </div>
     
      
 </div>

     </div>
     
    
    
     <!--row End-->
  </div>
  </div>
</section>