<div id="content_holder">
<?=link_tag('assets/modules/promotion/admin/css/promotion.css')?>

<h1>View Onpage Settings</h1>

	<!-- box_left starts -->
    <div id="box_left_big">
    
    <?=$this->session->flashdata('message')?>
    
        <?php if($onpage_promotion): ?>
        
            <table cellpadding="5" cellspacing="0" width="100%" border="0" class="grid">
            	<?php if($this->uri->segment(4)!=''){ $slno = $this->uri->segment(4)+1; } else { $slno = 1; } ?>
                <?php foreach($onpage_promotion as $promotion): ?>
                
                <tr>
                	<td width="3%"><?=$slno?></td>
                    <td width="73%"><strong><?=$promotion->onpage_title?></strong></td>
       		  <td width="24%">
                        <span class="details_right">
                        <?php
                            echo anchor('admin/promotion/edit_onpagepromotion/'.$promotion->onpage_id.'/'.str_replace('/','-',uri_string()),'Edit',array('class'=>'small-button'));
                            echo anchor('admin/promotion/delete_onpagepromotion/'.$promotion->onpage_id,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
                        ?>
                        </span>                    </td>
           	  </tr>
                
                <tr>
                	<td>&nbsp;</td>
                    <td colspan="2"><label>URL : </label><?=$promotion->onpage_url?></td>
                </tr>
                <?php $slno++; endforeach; ?>
                
                <tr>
                    <td colspan="3" align="center"><?=$this->pagination->create_links()?></td>
                </tr>
                
            </table>
        
        <?php else : ?>
            <p><em>No data`s found in this section</em></p>
        <?php endif; ?>
        
    </div>
    <!-- box_left ends -->

    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->

</div>