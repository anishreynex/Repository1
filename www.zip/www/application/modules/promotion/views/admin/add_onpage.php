<div id="content_holder">
<?=link_tag('assets/modules/promotion/admin/css/promotion.css')?>
<h1>Add Onpage Promotion</h1>

<!-- box_left starts -->
<div id="box_left_big">
<?=$this->session->flashdata('message')?>

	<?php	echo form_open('admin/promotion/add_onpage_process',array('id'=>'onpage_promotion'));	?>

    <table cellpadding="5" cellspacing="0" border="0" width="100%" class="grid">
    
      <tr>
        <td colspan="2"><strong>Page Title <span class="form_error">*</span></strong></td>
      </tr>
      <tr>
        <td><input type="text" name="page_title" id="page_title" class="input textbox" /></td>
        <td width="38%">&nbsp;</td>
      </tr>
        
        <tr>
          <td colspan="2"><strong> Page Url </strong></td>
        </tr>
        <tr>
            <td><input type="text" name="page_url" id="page_url" class="input textbox" /></td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td colspan="2"><strong>Meta Name <span class="form_error">*</span></strong></td>
        </tr>
        <tr>
            <td><input type="text" name="meta_name[]" id="meta_name[]" class="input textbox" /></td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
          <td colspan="2"><strong>Meta Content <span class="form_error">*</span></strong></td>
        </tr>
        <tr>
            <td><input type="text" name="meta_content[]" id="meta_content[]" class="input textbox" /></td>
            <td>&nbsp;</td>
        </tr>
        
        <tr id="add_remove_tags">
        	<td>&nbsp;</td>
            <td>
				<?php
            	$add_image = array('src'=>'assets/modules/promotion/admin/images/plus-circle.png', 'id'=>'add');
				echo img($add_image);
				?>
            </td>
        </tr>
        
        <tr>
            <td><input type="submit" name="submit" value="Save" class="button" /> <?php echo anchor('admin/promotion','[ Back To List ]'); ?></td>
            <td>&nbsp;</td>
        </tr>
        
    </table>
	
    <input type="hidden" name="hidden_count" id="hidden_count" value="1" />
	<?php echo form_close(''); ?>
    
</div>
<!-- box_left ends -->

<!-- box_right starts -->
<div id="box_right_small"><?php echo $right_panel; ?></div>
<!-- box_right ends -->

</div>

<script language="javascript">
	$(document).ready(function(){
		/** Form Validation **/
		$("#onpage_promotion").validate({
			rules : {
				page_title		: "required",
				page_url		:	{
									remote:	{
												url: "<?=base_url()?>admin/promotion/check_page_url",
												type:"post"
											}
									}
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td").next("td") );
			},		
	
			messages: {
				page_title		: "The Page Title field is required",
				page_url		: { remote: "Url not available" }
			}					 
		});
		/** End Validation **/
		
		/** Add More Tags **/
		$("#add").live('click', function() {
			var count = $("#hidden_count").val();
			
					
			var fields = '<tr id="metaname_txt_'+count+'"><td colspan="2" class="meta_group"><strong>Meta Name</td></tr><tr id="metaname_val_'+count+'"><td class="meta_group"><input type="text" name="meta_name[]" id="meta_name[]" class="input textbox" /></td><td class="meta_group">&nbsp;</td></tr><tr id="metacontent_txt_'+count+'"><td class="meta_group" colspan="2"><strong>Meta Content</strong></td></tr><tr id="metacontent_val_'+count+'"><td class="meta_group"><input type="text" name="meta_content[]" id="meta_content[]" class="input textbox" /></td><td class="meta_group"><img src="<?=base_url()?>assets/modules/promotion/admin/images/minus-circle.png" class="remove" onclick="remove()" id="'+count+'" /></td></tr>';
			
			$("#add_remove_tags").after(fields);
			var new_count = parseInt(count)+parseInt(1);
			$("#hidden_count").val(new_count);
		});
		
		$(".remove").live('click', function(){
			var count = $("#hidden_count").val();
			var new_count = parseInt(count)-parseInt(1);
			$("#hidden_count").val(new_count);
			
			var id = $(this).attr("id");
			$("#metaname_txt_"+id).remove();
			$("#metaname_val_"+id).remove();
			$("#metacontent_txt_"+id).remove();
			$("#metacontent_val_"+id).remove();
		  	//$(this).parents('tr').remove();
		  });
	});
	
</script>