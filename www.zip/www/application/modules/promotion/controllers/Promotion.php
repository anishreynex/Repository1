<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class Promotion
* Class to manage promotion
*
**/
class Promotion extends CI_Controller {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function index
	 *
	 *
	 **/
	 public function index()
	 {
	 	//index
	 }
}
