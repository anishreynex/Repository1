<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* Author : Chaitra
* class Admin
* Class to manage Administrator option of promotion
*
**/
class Admin extends CI_Controller {

	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'promotion/admin/';
	
	 public function __construct()
	 {
	 	parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	 }
	 
	 /**
	  * function index
	  * loads the administrator onpage promotion list
	 **/
	 public function index()
	 {
	 	$this->load->view($this->common_view_path.'header');
		// Start Pagination
		$config['base_url'] 	= site_url().'admin/promotion/index';
		$config['total_rows'] 	= count($this->main_model->select_as_object('onpage_promotion','','onpage_id','DESC',FALSE));
		$config['per_page'] 	= 10;
		$config['uri_segment']	= 4;
		
		$this->pagination->initialize($config); 		
		// End Pagination
		$data['onpage_promotion'] = $this->main_model->select_as_object('onpage_promotion','','onpage_id','DESC',FALSE,$config['per_page'],$this->uri->segment(4));
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function add_onpage
	  * loads the add onpage promotion form.
	 **/
	 public function add_onpage()
	 {
	 	$this->load->view($this->common_view_path.'header');
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'add_onpage',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function add_onpage_process
	  * process the administrator onpage promotion action
	 **/
	 public function add_onpage_process()
	 {
	 	if($this->promotion_model->add_onpage_process())
		{	$this->session->set_flashdata('message',success_message('Onpage promotion added successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Onpage promotion insertion failed.'));	}
		redirect('admin/promotion/add_onpage');
	 }
	 
	 /**
	  * function delete_onpagepromotion
	  * process the administrator delete onpage promotion action
	 **/
	 public function delete_onpagepromotion($promotion_id)
	 {
	 	if($promotion_id)
		{
			if($this->promotion_model->delete_onpagepromotion($promotion_id))
			{	$this->session->set_flashdata('message',success_message('Onpage promotion deleted successfully.'));	}
			else
			{	$this->session->set_flashdata('message',error_message('Onpage promotion deletion failed.'));	}
			redirect('admin/promotion');
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			redirect('admin/promotion');
		}
	 }
	 
	 /**
	  * function edit_onpagepromotion
	  * loads the administrator edit onpage form
	 **/
	 public function edit_onpagepromotion($promotion_id,$redirect='')
	 {
	 	if($promotion_id)
		{
			$this->load->view($this->common_view_path.'header');
			$data['redirect']	  = $redirect;
			$data['edit']		  = $this->main_model->select_as_object('onpage_promotion',array('onpage_id'=>$promotion_id),'','',TRUE);
			$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
			$this->load->view($this->module_view_path.'edit_onpage',$data);
			$this->load->view($this->common_view_path.'footer');
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error occured! Try again.'));
			if($redirect)
			{	redirect (str_replace('-','/',$redirect));	}
			else
			{	redirect('admin/promotion');	}
		}
	 }
	 
	 /**
	  * function edit_onpagepromotion_process
	  * process the administrator edit onpage promotion action.
	 **/
	 public function edit_onpagepromotion_process()
	 {
	 	$promotion_id = $this->input->post('hidden_promotionid');
		if($this->promotion_model->edit_onpagepromotion())
		{	$this->session->set_flashdata('message',success_message('Onpage promotion updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Onpage promotion updation failed.'));	}

		redirect('admin/promotion/edit_onpagepromotion/'.$promotion_id);
	 }
	 
	 /**
	  * function username_url
	 **/
	 public function check_page_url()
	 {
	 	if($this->promotion_model->check_page_url())
		{	echo 'true';	}
		else
		{	echo 'false';	}
	 }
}
