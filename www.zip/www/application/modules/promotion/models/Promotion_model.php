<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class promotion_model
* Model Class to manage Administrator option of promotion
*
**/
class Promotion_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 
	 /**
	 * function add_onpage_process
	 * process the administrator onpage action.
	 **/
	 public function add_onpage_process()
	 {
	 	$flg = 0;
	 	$data['onpage_title'] 			= $this->input->post('page_title');
		$data['onpage_url'] 			= $this->input->post('page_url');
		$data['onpage_modified_on'] 	= time();
		
		if($this->db->insert('onpage_promotion',$data))
		{
			$last_id = $this->db->insert_id();
			$count   = $this->input->post('hidden_count');
			if($count!=0)
			{
				$datas['onpage_promotion_id']	= $last_id;
				for($i=0; $i<$count; $i++)
				{
					$meta_name 		= $this->input->post('meta_name');
					$meta_content	= $this->input->post('meta_content');
					
					$datas['onpage_meta_name']		= $meta_name[$i];
					$datas['onpage_meta_content']	= $meta_content[$i];
					
					if($this->db->insert('onpage_promotion_details',$datas))
					{	$flg++;	}
				}
				
				if($flg>0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	 }
	 
	 /**
	  * function delete_onpagepromotion
	  * process the administrator onpage data deletion action.
	 **/
	 public function delete_onpagepromotion($promotion_id)
	 {
	 	$this->db->where('onpage_promotion_id',$promotion_id);
		if($this->db->delete('onpage_promotion_details'))
		{
	 		$this->db->where('onpage_id',$promotion_id);
			if($this->db->delete('onpage_promotion'))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{
			return false;
		}
	 }
	 
	 /**
	  * function edit_onpagepromotion
	  * process the onpage promotion edit action
	 **/
	 public function edit_onpagepromotion()
	 {
	 	$data['onpage_title'] 			= $this->input->post('page_title');
		$data['onpage_url'] 			= $this->input->post('page_url');
		$data['onpage_modified_on'] 	= time();
		
		$this->db->where('onpage_id',$this->input->post('hidden_promotionid'));
		if($this->db->update('onpage_promotion',$data))
		{
			$this->db->where('onpage_promotion_id',$this->input->post('hidden_promotionid'));
			$this->db->delete('onpage_promotion_details');
			
			$flg=0;
			$count   = $this->input->post('hidden_count');
			if($count!=0)
			{
				$datas['onpage_promotion_id']	= $this->input->post('hidden_promotionid');
				
				for($i=0; $i<$count; $i++)
				{
					$meta_name 		= $this->input->post('meta_name');
					$meta_content	= $this->input->post('meta_content');
					
					if((@$meta_name[$i]!='') && (@$meta_content[$i]!=''))
					{	
						$datas['onpage_meta_name']		= $meta_name[$i];
						$datas['onpage_meta_content']	= $meta_content[$i];
					
						if($this->db->insert('onpage_promotion_details',$datas))
						{	$flg++;	}
					}
					else
					{	$flg++;	}
				}
				
				if($flg>0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	 }
	 
	 /**
	 * function page_title_check
	 * check wheather the page title exist in database.
	**/
	public function check_page_url()
	{
		$page_url = $this->input->post('page_url');	
		
		$this->db->where('onpage_url',$page_url);
		if($this->db->count_all_results('onpage_promotion')==0)
		{	return true;	}
		else
		{	return false ;	}
	}
}
