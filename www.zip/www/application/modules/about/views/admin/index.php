    <!-- content_holder starts -->
	<div id="content_holder">
		<h1>View About Us</h1>
    	<!-- box_left starts -->
        <div id="box_left_big">
        <?php echo $this->session->flashdata('message'); ?>
      
        
        <?php if($about): ?>        
        	<table cellpadding="5" cellspacing="0" align="left" width="100%" class="grid">
            	<thead>
                	<tr>
                    	<th width="6%">Sl No</th>
                      	<th width="10%">Title</th>
                      	<th width="5%">Quotes</th>
                      	<th width="5%">Image</th>
                        <th width="15%">Action</th>
                  </tr>
                </thead>
                <tbody>
                	<?php if($this->uri->segment(10)=='') { $slno = 1; } else { $slno = $this->uri->segment(10)+1; } ?>
                	<?php foreach($about as $about): ?>
                    <tr>
                    	<td><?=$slno+$count?></td>
                        <td><?=$about->title?></td>
                        <td><?=$about->quotes?></td>
                         <td>
                    	  	<img width="150" height="100" src="<?php echo base_url(); ?>uploads/about/<?php echo $about->image_name; ?>" class="" />
                    	  </td>
                       <!-- <td><?php echo$gallerye = img(array('src'=>'uploads/profiles/'.image_thumb($image->image_name),'width'=>'140')); ?></td>-->
                       
                        <td>
                        	<?php
			                    echo anchor('admin/about/edit_about/'.$about->about_id.'/'.$page,'Edit',array('class'=>'small-button')); 
								
								echo anchor('admin/about/delete_about/'.$about->about_id.'/'.$page,'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
			                ?>
                        </td>
                    </tr>
                    <?php $slno++; endforeach; ?>
                    <tr>
                    	<td colspan="6" align="center"><?=$this->pagination->create_links()?></td>
                    </tr>
                </tbody>
            </table>
        <?php else: ?>
        	<p><em>No results found!</em></p>
        <?php endif; ?>
    
    </div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
    <div id="box_right_small"><?php echo $right_panel; ?></div>
    <!-- box_right ends -->
   
</div>
<!-- content_holder ends -->
    
    <script type="text/javascript">
    $(document).ready(function(){
	$("a[rel=about]").fancybox({
		'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'services_titlePosition' 	: 'over',
		'services_titleFormat'       : function(services_title, currentArray, currentIndex, currentOpts) {
		    return '<span id="fancybox-services_title-over">Image ' +  (currentIndex + 1) + ' / ' + currentArray.length + ' ' + services_title + '</span>';
		}
	});						   
	});
    </script>
    

