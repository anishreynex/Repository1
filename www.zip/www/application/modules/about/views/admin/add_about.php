 <section id="contentwrap">
  <div id="AllcontWrap">
    <div class="container">
 <div class="pageHeadRow">
        <div class="pagetble-cell">
          <h3 data-toggle="tooltip"  title="About Us" class="page-subHead">
          	 	About Us
        </h3>
        </div>
        <div class="pagetble-cell text-right">
          <ol class="breadcrumb">
            <li> <a href="<?php echo base_url('admin/dashboard');?>" data-toggle="tooltip"  title="Go to dashboard">Home</a> </li>
           <li class="active"> About Us</li>
          </ol>
        </div>
      </div>
<?php
$post_array =$this->session->userdata('postarray');
?>
<!-- content_holder starts -->
<div id="content_holder">


<?php if($about){ $button = 'Save'; } else { $button = 'Save'; } ?>
    <!-- box_left starts -->
    <div id="box_left_big">
    <?php echo $this->session->flashdata('message'); ?>   
    
    
   
    
   <?php
		
    	echo  form_open_multipart('admin/about/add_about_process/'.$about->about_id,array('id'=>'add_about_form'));
	?>


    
        <input type="hidden" name="about_id" value="<?php if($about): echo $about->about_id; endif; ?>" />
      <input type ="hidden" name="imageupdate" value="<?php echo $about->image_name ?>"/>
       <div class="form-group">
                <label for="exampleInputPassword1"><strong>Who we are</strong> <span class="form_error">*</span><br><small></small></label>
               <textarea class="form-control" id="txt_title" cols="100" rows="5" name="txt_title" ><?php echo $about->title;?></textarea>
              </div>
    <img width="200px" height="100px" alt="" src="<?php echo base_url()?>uploads/about/<?php echo $about->image_name ?>" >
     <div class="form-group">
                <label for="exampleInputPassword1"><strong>File to upload</strong> <span class="form_error">*</span><br><small></small></label>
                <input type="file" name="userfile" id="userfile" />
	        	<p style="color: #999;">For better appearance;The image dimension is fixed to 1920px x 1080px</p>
              </div>
              <?php if(!empty($upload_error_message)) echo '<span class="form_error">'. $upload_error_message.'</span>'; ?>
   <input type="submit" name="about_submit" id="about_submit" value="<?=$button?>" class="btn btn-default" />
            	<?=anchor('admin/dashboard','[ Back To List ]')?>
   
    
    <?=form_close('')?>
	</div>
    <!-- box_left ends -->
    
    <!-- box_right starts -->
  
    <!-- box_right ends -->
</div>
<!-- content_holder ends -->
</div>
</div>
</section>


    <?php
    $this->session->unset_userdata('postarray');
    ?>
    