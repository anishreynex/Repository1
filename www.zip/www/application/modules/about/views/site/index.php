 <section class="seven-hills-about">
   <div class="seven-background"></div>
	<div class="container">
    <div class="row seven-row">
    <div class="col-md-12">
    <div class="seven-white">
    <h4 class="title-dist"><span class="span-padd"><img src="<?php echo base_url();?>assets/themes/site/images/side-logo.png"></span>About Us</h4>
    
    <div class="row">
    <div class="col-md-6">
    
	<div class="white-inner">
    <h5 class="room-terms">We Are Sevenhills</h5>
    <p><?php echo $about->title; ?></p>

    </div>

    </div>
    
    <div class="col-md-6">
    <div class="abt-img">
    <img src="<?php echo base_url()?>uploads/about/<?php echo $about->image_name?>" class="img img-responsive">
    </div>
    </div>
    
    </div>
    
    
    <div class="row test-back">
    <div class="col-md-12">
    <div  class="dfq-slide">
    
    
    <h4 class="text-center">TESTIMONIAL</h4>
    <p class="text-center testmo-p ">Here is some valuable word from our clients</p>
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
  	  	<?php $active =" active";$i=0;?>
   <?php foreach($feedback as $feedbacks):?>
    <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i; ?>" class="<?php echo $active;$active="";?>"></li>
    <?php $i++; endforeach;?>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner test-back-inner" role="listbox">

  	<?php $active =" active";?>
   <?php foreach($feedback as $feedback):?>
   	
    <div class="item<?php echo $active;$active="";?>">
      <div class="carousel-caption">
        <p><?php if($feedback){echo $feedback->description;}?></p>
        <h4>-  <?php if($feedback){echo $feedback->title;}?>  -</h4>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

 
</div>
    </div>
    
     <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <i class="fa fa-angle-left"></i>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <i class="fa fa-angle-right"></i>
    <span class="sr-only">Next</span>
  </a>
    </div>
    </div>
    
    
    </div>
    </div>
    </div>
    </div>
   </section>
   
  <div class="clearfix"></div>
  
  