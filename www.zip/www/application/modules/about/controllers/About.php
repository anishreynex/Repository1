<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class About Us
* Class to manage About Us
*
**/
class About extends MX_Controller {
	
    protected $common_view_path	= 'templates/site/';
	protected $module_view_path	= 'about/site/';

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function index
	 *
	 *
	 **/
	 public function index()
	 {
	 	$data['urlnow']='about_us';
		$data["feedback"]	=	 $this->main_model->select_as_object('feedback','','','',FALSE);
	 	$data["about"]	=	 $this->main_model->select_as_object('about',array('about_id'=>3),'','',TRUE);
	 	$this->load->view($this->common_view_path.'inner_header');
		$this->load->view($this->module_view_path.'index',$data);
		$this->load->view($this->common_view_path.'inner_footer');
	 }
	 
	}
