<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class Admin
* Class to manage Administrator option of About
*
**/
class Admin extends CI_Controller {

	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'about/admin/';

	 public function __construct()
	 {
	 	parent::__construct();
		$this -> load -> library('session');
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	 }
	 /**
	 * function index
	 *
	 *
	 **/
	 public function add_about($page='')
	 {
		$this->load->view($this->common_view_path.'header');
		$data['page_title']        ='Add About Us';
		$data['about'] = $this -> main_model -> select_as_object('about', '', 'about_id ', 'DESC',TRUE);
		
		$data['page']              =$page;
		$data['right_panel']       = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'add_about',$data);
		$this->load->view($this->common_view_path.'footer');
	}
	public function add_about_process($id='')
	 {
		$id = $this->input->post('about_id');
		if($this->upload_img())
		{
			 $image_name				=	$this->session->userdata('uploaded_file_name');
			if(!$this->image_resolution())
	    {
	    	@unlink('uploads/about/'.$image_name);
		$this->session->set_flashdata('message',error_message('<span for="txt_title" class="invalid">Image resolution error! Please upload images with width 1920px and height 1080px</span>'));
		$post_array =array(
		                  'title' => $this->input->post('txt_title'),
		                  'quotes'=>$this->input->post('txt_quotes'),
						  
						  );
		$this->session->set_userdata('postarray',$post_array);
		redirect('admin/about/add_about');				  
	    }
		
			$image_name				=	$this->session->userdata('uploaded_file_name');
			$data['title']			=	$this->input->post('txt_title');
			$data['quotes']	=	$this->input->post('txt_quotes');
			$data['image_name']		=    $image_name; 
			$data['posted_on']	    =	time();
			$images   = $this->main_model->select_as_object('about',array('about_id'=>$id),'about_id','DESC',TRUE);
			
			if($this->db->update('about',$data))
			{
				@unlink('uploads/about/'.$images->image_name);
				
				$this->session->set_flashdata('message',success_message('About Us Updated successfully'));
			
				redirect('admin/about/add_about');	
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Image uploading failed.'));	
							}
		}
		else
		{
			
			
			$data['title']			=	$this->input->post('txt_title');
			$data['quotes']	=	$this->input->post('txt_quotes');
			$data['image_name']		=    $this->input->post('imageupdate');
			$data['posted_on']	    =	time();
		
			
			if($this->db->update('about',$data))
			{
				$this->session->set_flashdata('message',success_message('About Us Updated successfully'));
			redirect('admin/about/add_about');
			}
			else
			{
				$this->session->set_flashdata('message',error_message('Image uploading failed.'));	
							}
			
			
		}
	 	
	 }

     
	 function upload_img()
	{
		$config['upload_path'] 		= './uploads/about/';
		$config['allowed_types'] 	= 'gif|jpg|png|jpeg';
		$config['max_size']			= '10240';
		$config['max_width']  		= '8000';
		$config['max_height']  		= '8000';
		$config['encrypt_name']  	= TRUE;
		
		$this->load->library('upload', $config);
	
		if ( ! $this->upload->do_upload())
		{
			$error = $this->upload->display_errors('<span>','</span>');
			
			$this->session->set_userdata('file_upload_error',$error);
			return false;
		}	
		else
		{
			$upload_data = $this->upload->data();
			
			list($width, $height) = getimagesize($upload_data['full_path']);
			
			$this->session->set_userdata('uploaded_file_name',$upload_data['file_name']);
			return true;
		}
	}

    public function image_resize($path, $width=1600, $height=900)
	{
		$config['image_library'] 	= 'gd2';
		$config['source_image'] 	= $path;
		$config['maintain_ratio'] 	= TRUE;
		$config['width'] 			= $width;
		$config['height'] 			= $height;
		
		$this->load->library('image_lib', $config);
	
		if (!$this->image_lib->resize())
		{
			echo $this->image_lib->display_errors('', '');
		}
	}
	
	public function create_thumb($image_name, $album_id='', $redirect='', $width=270, $height=180)
	{	
		$config['image_library'] 	= 'gd2';
		$config['source_image']  	= './uploads/about/'.$image_name;
		$config['create_thumb'] 	= TRUE;
		$config['maintain_ratio'] 	= TRUE;
		$config['width'] 			= $width;
		$config['height'] 			= $height;
		
		$this->load->library('image_lib', $config);
		
		if($this->image_lib->resize())
		{
			
			$this->session->unset_userdata('uploaded_file_name');
			
			$this->session->set_flashdata('message',success_message('About Us Updated successfully'));
			if($redirect)
			{	redirect(str_replace('-','/',$redirect));	}
			else
			{	redirect('admin/about/add_about');	}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Image croping failed.'));
			if($redirect)
			{	redirect(str_replace('-','/',$redirect));	}
			else
			{	redirect('admin/about/add_about');	}
		}
	}
	
	public function image_resolution()
 {
 	if(isset($_FILES['userfile']))
	{
		$image=$_FILES['userfile'];
		$image_info=@getimagesize($_FILES["userfile"]["tmp_name"]);
		$image_width=$image_info[0];
		$image_height=$image_info[1];
		if(($image_width==1920)&&($image_height==1080))
		{
			return true;
		}
		else {
			return false;
	  }
	}
	else
		{
			return false;
	 }
		
 }
 }