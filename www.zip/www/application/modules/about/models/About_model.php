<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class About Us_model
* Model Class to manage Administrator option of About Us
*
**/
class About_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function any_function
	 *
	 *
	 **/
	 
}
