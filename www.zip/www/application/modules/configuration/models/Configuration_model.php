<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class configuration_model
* Model Class to manage Administrator option of configuration
*
**/
class Configuration_model extends CI_Model {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 
	 /**
	  * funtion upload_logo_process
	  * process the administrator upload logo action.
	 **/
	 public function upload_logo_process()
	 {		
		$this->session->unset_userdata('image_success');
		$this->session->unset_userdata('image_error');
		
		// If video uploaded successfully.		
		if($this->upload_image())
		{
			$image_data = $this->session->userdata('image_success');
			
			$data['logo_path']	= $image_data['upload_image']['file_name'];
			
			//$get_old_logo = $this->main_model->select_as_object('admin_logo',array('logo_id'=>1),'','',TRUE);
			//unlink('./uploads/admin_logo/'.$get_old_logo->logo_path);
			
			$this->db->where('logo_id',1);
			if($this->db->update('admin_logo',$data))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{
			$image_error = $this->session->userdata('image_error');
			$this->session->set_flashdata('message',error_message($image_error['error']));
			redirect('admin/videos/upload_video');
		}
	 }
	 
	 /**
	  * funtion upload_image
	  * process the upload image action.
	 **/
	 private function upload_image()
	 {
	 	$config['upload_path'] 		= './uploads/admin_logo/';
		$config['allowed_types'] 	= 'jpg|gif|png';
		$config['max_size']			= '100';
		$config['max_width'] 		= '1024';
		$config['max_height'] 		= '768';
		$this->upload->initialize($config);

		if ( ! $this->upload->do_upload())
		{
			$image_error = array('error' => $this->upload->display_errors('<span>','</span>'));
			$this->session->set_userdata('image_error',$image_error);
			return false;
		}
		else
		{
			$image_data = array('upload_image' => $this->upload->data());
			$this->image_resize('uploads/admin_logo/'.$image_data['upload_image']['file_name']);
			$this->session->set_userdata('image_success',$image_data);
			return true;
		}
	 }
	 
	 /**
	  * funtion image_resize
	  * process the image resize action.
	 **/
	 private function image_resize($path, $width=324, $height=34)
	 {
		$config['image_library'] 	= 'gd2';
		$config['source_image'] 	= $path;
		$config['maintain_ratio'] 	= TRUE;
		$config['width'] 			= $width;
		$config['height'] 			= $height;
		
		$this->load->library('image_lib', $config);
		
		$this->image_lib->resize();
	 }
	 
	 /**
	  * function add_routing_process
	  * process the administrator configure routing action
	 **/
	 public function add_routing_process()
	 {
		$data['current_url'] = $this->input->post('current_url');
		$data['routing_url'] = $this->input->post('routing');
		$data['modified_on'] = time();
		
		if($this->db->insert('routing',$data))
		{	return true;	}
		else
		{	return false;	}
	 }
	 
	 /**
	  * function edit_routing_process
	  * process the edit routing action.
	 **/
	 public function edit_routing_process()
	 {
	 	if($this->input->post('hidden_id'))
		{
			$data['current_url'] = $this->input->post('current_url');
			$data['routing_url'] = $this->input->post('routing');
			$data['modified_on'] = time();
			
			$this->db->where('routing_id',$this->input->post('hidden_id'));
			if($this->db->update('routing',$data))
			{	return true;	}
			else
			{	return false;	}
		}
		else
		{
			return false;
		}
	 }
	 
	 /**
	  * function delete_routing
	  * process the administrator delete routing action.
	 **/
	 public function delete_routing($routing_id)
	 {
	 	$this->db->where('routing_id',$routing_id);
		if($this->db->delete('routing'))
		{	return true;	}
		else
		{	return false;	}
	 }
}
