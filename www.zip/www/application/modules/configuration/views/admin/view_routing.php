<div id="content_holder">
<h1>Configure Routing</h1>

	<div id="box_left_big">
	<?php echo $this->session->flashdata('message'); ?>
    
    <table cellpadding="5" cellspacing="0" border="0" width="100%" class="grid">
    	
        <thead>
        	<tr>
            	<td width="10%"><strong>Sl No</strong></td>
                <td width="39%"><strong>Current Url</strong></td>
                <td width="37%"><strong>Routing Url</strong></td>
                <td width="14%"><strong>Action</strong></td>
          </tr>
        </thead>
        
        <tbody>
        	<?php if($this->uri->segment(4)!=''): $slno = $this->uri->segment(4); else : $slno = 1; endif; ?>
        	<?php foreach($routings as $routing): ?>
            <tr>
            	<td><?=$slno?></td>
                <td><?=$routing->current_url?></td>
                <td><?=$routing->routing_url ?></td>
                <td>
                	<?php
						echo anchor('admin/configuration/edit_routing/'.$routing->routing_id,'Edit',array('class'=>'small-button'));
						echo anchor('admin/configuration/delete_routing/'.$routing->routing_id.'/'.str_replace('/','-',uri_string()),'Delete',array('class'=>'small-button confirm_link','title'=>'These item will be permanently deleted and cannot be recovered. Are you sure?'));
					?>
                </td>
            </tr>
            <?php $slno++; endforeach; ?>
            <tr>
            	<td colspan="4" align="center"><?=$this->pagination->create_links()?></td>
            </tr>
        </tbody>
        
    </table>
    
    </div>

	<div id="box_right_small"><?php echo $right_panel; ?></div>

</div>

<script language="javascript">
	$(document).ready(function(){
		$("#routing_form").validate({
			rules : {
				current_url	: "required",
				routing		: "required"
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td").next("td"));
			},
			messages: {
				current_url	: "The Currenr Url field is required",
				routing		: "The Current Routing field is required"
			}					 
		});
	});
</script>