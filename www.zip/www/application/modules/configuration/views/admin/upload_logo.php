<div id="content_holder">
<h1>Update Logo</h1>

	<div id="box_left_big">
	<?php echo $this->session->flashdata('message'); ?>
    
    <?=form_open_multipart('admin/configuration/upload_logo_process',array('id'=>'upload_logo'))?>
    
    <table cellpadding="5" cellspacing="0" border="0" width="100%" class="grid">

        <tr>
            <td width="66%"><strong>Upload Logo <span class="form_error">*</span></strong></td>
            <td width="34%">&nbsp;</td>
      </tr>
        <tr>
            <td><input type="file" name="userfile" size="20" /><br /><span class="grey_text">( Only .jpg, .gif, .png files allowed. )</span></td>
            <td>&nbsp;</td>
      </tr>
        
        <tr>
            <td><input type="submit" name="submit" class="button" value="Update" /></td>
            <td>&nbsp;</td>
        </tr>

    </table>
    
    <?=form_close('')?>
    
    </div>

	<div id="box_right_small"><?php echo $right_panel; ?></div>

</div>

<script language="javascript">
	$(document).ready(function(){
		$("#upload_logo").validate({
			rules : {
				userfile	: { required : true, accept : "png|jpg|gif"}
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td").next("td"));
			},
			messages: {
				userfile	: { required : "Please select a file to upload.", accept : "Please upload a file with a valid extension."}
			}					 
		});
	});
</script>