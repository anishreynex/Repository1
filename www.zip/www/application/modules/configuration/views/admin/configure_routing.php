<div id="content_holder">

<?php if($edit){ $page = 'Update '; $button = 'Update'; } else { $page = ''; $button = 'Save'; } ?>

<h1><?=$page?>Configure Routing</h1>

	<div id="box_left_big">
	<?php echo $this->session->flashdata('message'); ?>
    
    <?php
		if($edit)
		{	echo form_open('admin/configuration/edit_routing_process',array('id'=>'routing_form'));	}
		else
    	{	echo form_open('admin/configuration/add_routing_process',array('id'=>'routing_form'));	}
	?>
    
    <input type="hidden" name="hidden_id" id="hidden_id" value="<?php if($edit): echo $edit->routing_id; endif; ?>" />
    
    <table cellpadding="5" cellspacing="0" border="0" class="grid" width="100%">
    	
        <tr>
        	<td width="65%"><strong>Current URL <span class="form_error">*</span></strong></td>
            <td width="35%">&nbsp;</td>
        </tr>
        <tr>
        	<td><input type="text" name="current_url" id="current_url" class="input textbox" value="<?php if($edit): echo $edit->current_url; endif; ?>" /></td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
        	<td><strong>Routing <span class="form_error">*</span></strong></td>
            <td>&nbsp;</td>
        </tr>
        <tr>
        	<td><input type="text" name="routing" id="routing" class="input textbox" value="<?php if($edit): echo $edit->routing_url; endif; ?>" /></td>
            <td>&nbsp;</td>
        </tr>
        
        <tr>
        	<td><input type="submit" name="save" class="button" value="<?=$button?>" /> <?=anchor('admin/configuration/view_routing','[ Back To List ]')?></td>
            <td>&nbsp;</td>            
        </tr>
        
    </table> 
    
    <?=form_close('')?>
    
    </div>

	<div id="box_right_small"><?php echo $right_panel; ?></div>

</div>

<script language="javascript">
	$(document).ready(function(){
		$("#routing_form").validate({
			rules : {
				current_url	: "required",
				routing		: "required"
			},	
			errorPlacement: function(error, element) {
			error.appendTo( element.parent("td").next("td"));
			},
			messages: {
				current_url	: "The Currenr Url field is required",
				routing		: "The Current Routing field is required"
			}					 
		});
	});
</script>