<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* Author 	  : Chaitra
* Created On  : 10/06/2011
* Modified On : 10/06/2011
*
* class Admin
* Class to manage Administrator option of configuration
*
**/
class Admin extends CI_Controller {

	protected $common_view_path	= 'templates/admin/';
	protected $module_view_path	= 'configuration/admin/';
	
	 public function __construct()
	 {
	 	parent::__construct();
		
		if(!$this->ion_auth->logged_in())
		{
			redirect('admin/auth');	
		}
	 }
	 
	 /**
	 * function upload_logo
	 * loads the administrator upload logo page.
	 **/
	 public function upload_logo()
	 {		
	 	$this->load->view($this->common_view_path.'header');
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'upload_logo',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function upload_logo_process
	  * process the administrator upload logo action
	 **/
	 public function upload_logo_process()
	 {
	 	if($this->configuration_model->upload_logo_process())	
		{	$this->session->set_flashdata('message',success_message('Logo updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Logo updation failed.'));	}
		redirect('admin/configuration/upload_logo');
	 }
	 
	 /**
	  * function configure_routing
	  * loads the administrator configure routing interface.
	 **/
	 public function configure_routing()
	 {
	 	$this->load->view($this->common_view_path.'header');
		$data['edit']		  = '';
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'configure_routing',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function add_routing_process
	  * process the administrator add routing process.
	 **/
	 public function add_routing_process()
	 {
	 	if($this->configuration_model->add_routing_process())
		{	$this->session->set_flashdata('message',success_message('Routing configured successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Routing configuration failed. Try again.'));	}
		redirect('admin/configuration/configure_routing');
	 }
	 
	 /**
	  * function view_routing
	  * loads the administrator configure routing interface.
	 **/
	 public function view_routing()
	 {
	 	$this->load->view($this->common_view_path.'header');

		/** Start - Pagination **/
		$config['base_url'] 	= site_url().'admin/configuration/view_routing/';
		$config['total_rows'] 	= count($this->main_model->select_as_object('routing','','routing_id','DESC',FALSE));
		$config['per_page'] 	= 10;
		$config['uri_segment']	= 4;
		
		$this->pagination->initialize($config); 
		/** End - Pagination **/
		
		$data['routings'] = $this->main_model->select_as_object('routing','','routing_id','DESC',FALSE,$config['per_page'],$this->uri->segment(4));
		$data['right_panel']  = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'view_routing',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function edit_routing
	  * loads the edit routing form
	 **/
	 public function edit_routing($routing_id)
	 {
	 	$this->load->view($this->common_view_path.'header');
		$data['edit']		 = $this->main_model->select_as_object('routing',array('routing_id'=>$routing_id),'','',TRUE);
		$data['right_panel'] = $this->load->view($this->common_view_path.'right_panel','',true);
		$this->load->view($this->module_view_path.'configure_routing',$data);
		$this->load->view($this->common_view_path.'footer');
	 }
	 
	 /**
	  * function edit_routing_process
	  * process the edit routing action.
	 **/
	 public function edit_routing_process()
	 {
	 	$routing_id = $this->input->post('hidden_id');
		
	 	if($this->configuration_model->edit_routing_process())
		{	$this->session->set_flashdata('message',success_message('Routing updated successfully.'));	}
		else
		{	$this->session->set_flashdata('message',error_message('Routing updation failed.'));	}
		redirect('admin/configuration/edit_routing/'.$routing_id);
	 }
	 
	 /**
	  * function delete_routing
	  * process the administrator delete routing action.
	 **/
	 public function delete_routing($routing_id,$redirect='')
	 {
	 	if($routing_id)
		{
			if($this->configuration_model->delete_routing($routing_id))
			{	$this->session->set_flashdata('message',success_message('Routing deleted successfully.'));	}
			else
			{	$this->session->set_flashdata('message',success_message('Routing deletion failed.'));	}
			
			if($redirect)
			{	redirect(str_replace('-','/',$redirect));	}
			else
			{	redirect('admin/configuration/view_routing');	}
		}
		else
		{
			$this->session->set_flashdata('message',error_message('Error Occured! Try again.'));
			if($redirect)
			{	redirect(str_replace('-','/',$redirect));	}
			else
			{	redirect('admin/configuration/view_routing');	}
		}
	 }
}
