<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* class Configuration
* Class to manage configuration
*
**/
class Configuration extends CI_Controller {

	 public function __construct()
	 {
	 	parent::__construct();
	 }
	 /**
	 * function index
	 *
	 *
	 **/
	 public function index()
	 {
	 	//index
	 }
}
