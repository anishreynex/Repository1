<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
| Function to connect to database
| @author Chaitra RS
| @created on 11/10/2011
*/

function database_connect($host_name, $username, $password, $database)
{
	mysql_connect($host_name, $username, $password) or die(mysql_error());
	mysql_select_db($database) or die(mysql_error());
}

// Connection to database
$connect	= database_connect('localhost', 'root', '', 'seven_hills');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] 			= "master";
$route['404_override'] 					= '';

$route['admin'] 						= "auth/admin";
$route['admin/([a-zA-Z_-]+)']			= '$1/admin';
$route['admin/([a-zA-Z_-]+)/(.+)']	= '$1/admin/$2';

/**
 * Client site routing
**/

$sql	= "SELECT * FROM `routing`";
$result	= mysql_query($sql) or die(mysql_error());
	
if(mysql_num_rows($result) > 0)
{
	while($rows = mysql_fetch_array($result,MYSQL_ASSOC))
	{
		$current_url 	= $rows['current_url'];
		$routing_url	= $rows['routing_url'];

		$route[$current_url] = $routing_url;
	}
}


/* End of file routes.php */
/* Location: ./application/config/routes.php */
